# Solar Client (Fabric 1.21.11, Loader 0.18.4)

Client-only mod. No cheats/hacks - only HUD, visuals and video-option tweaks.

## Build
1. Install JDK 21.
2. Copy `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` from the official
   Fabric example mod (https://github.com/FabricMC/fabric-example-mod) into this folder
   (or run `gradle wrapper --gradle-version 9.2.1` if you have Gradle installed).
3. `./gradlew build`  ->  jar is in `build/libs/solar-client-1.0.0.jar` (not the -sources one).
4. Put the jar + Fabric API in `.minecraft/mods`.
   Dev run: `./gradlew runClient`.

## Use
* Right Shift: open / close the Solar menu (works in-game and on the title screen).
* Left click a module = on/off, right click (or +) = settings.
* "Edit HUD" button: drag every HUD element anywhere, right click = reset it.
* Config: `.minecraft/config/solarclient.json`
