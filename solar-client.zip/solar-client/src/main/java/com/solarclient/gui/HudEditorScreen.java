package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.config.ConfigManager;
import com.solarclient.hud.HudManager;
import com.solarclient.module.HudModule;
import com.solarclient.module.ModuleManager;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Drag HUD elements anywhere. Right click an element to reset it. */
public class HudEditorScreen extends Screen {
    private final Screen parent;
    private final UiInput in = new UiInput();
    private HudModule drag;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        in.sync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void close() {
        ConfigManager.save();
        client.setScreen(parent);
    }

    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        int sw = width, sh = height;

        c.fill(0, 0, sw, sh, 0x77000000);
        // center guides
        c.fill(sw / 2, 0, sw / 2 + 1, sh, 0x18FFFFFF);
        c.fill(0, sh / 2, sw, sh / 2 + 1, 0x18FFFFFF);

        List<HudModule> active = new ArrayList<>();
        for (HudModule m : ModuleManager.huds()) if (m.isEnabled()) active.add(m);

        // find hovered (topmost = last)
        HudModule hovered = null;
        for (HudModule m : active) {
            if (m.w > 0 && hit(mx, my, m.x, m.y, m.w, m.h)) hovered = m;
        }

        Runnable post = null;
        boolean overButton = false;
        // bottom buttons
        int bw = 80, bh = 20, by = sh - 34;
        int doneX = sw / 2 - bw - 4, resetX = sw / 2 + 4;
        boolean hDone = hit(mx, my, doneX, by, bw, bh), hReset = hit(mx, my, resetX, by, bw, bh);
        overButton = hDone || hReset;
        if (in.leftClick && hDone) post = this::close;
        if (in.leftClick && hReset) HudManager.resetPositions();

        if (in.leftClick && hovered != null && !overButton) {
            drag = hovered;
            offX = mx - hovered.x;
            offY = my - hovered.y;
        }
        if (in.rightClick && hovered != null) hovered.resetPosition();

        boolean snapV = false, snapH = false;
        if (drag != null) {
            if (in.left) {
                int nx = Math.max(0, Math.min(sw - drag.w, mx - offX));
                int ny = Math.max(0, Math.min(sh - drag.h, my - offY));
                if (Math.abs(nx + drag.w / 2 - sw / 2) <= 3) { nx = sw / 2 - drag.w / 2; snapV = true; }
                if (Math.abs(ny + drag.h / 2 - sh / 2) <= 3) { ny = sh / 2 - drag.h / 2; snapH = true; }
                if (nx <= 3) nx = 0;
                if (ny <= 3) ny = 0;
                if (nx >= sw - drag.w - 3) nx = sw - drag.w;
                if (ny >= sh - drag.h - 3) ny = sh - drag.h;
                drag.fx = sw - drag.w > 0 ? nx / (float) (sw - drag.w) : 0f;
                drag.fy = sh - drag.h > 0 ? ny / (float) (sh - drag.h) : 0f;
            } else {
                drag = null;
            }
        }
        if (snapV) c.fill(sw / 2, 0, sw / 2 + 1, sh, RenderUtil.withAlpha(RenderUtil.SKY, 0.8f));
        if (snapH) c.fill(0, sh / 2, sw, sh / 2 + 1, RenderUtil.withAlpha(RenderUtil.SKY, 0.8f));

        for (HudModule m : active) {
            m.render(c, client, true);
            if (m.w <= 0) continue;
            boolean sel = m == drag || (drag == null && m == hovered);
            int col = sel ? RenderUtil.SKY : RenderUtil.withAlpha(RenderUtil.SKY, 0.35f);
            RenderUtil.outline(c, m.x - 1, m.y - 1, m.x + m.w + 1, m.y + m.h + 1, col);
            if (sel) c.drawText(textRenderer, m.name, m.x, Math.max(0, m.y - 10), RenderUtil.SKY_LIGHT, true);
        }

        String hint = "Drag elements anywhere  |  Right click = reset one  |  ESC = back";
        c.drawText(textRenderer, hint, (sw - textRenderer.getWidth(hint)) / 2, 10, 0xFFB6C4D8, true);
        String hint2 = "Enable more elements from the Solar menu (Right Shift)";
        c.drawText(textRenderer, hint2, (sw - textRenderer.getWidth(hint2)) / 2, 22, 0xFF6F83A3, true);

        button(c, doneX, by, bw, bh, "Done", hDone);
        button(c, resetX, by, bw, bh, "Reset All", hReset);

        if (post != null) post.run();
    }

    private void button(DrawContext c, int x, int y, int w, int h, String label, boolean hov) {
        RenderUtil.rrect(c, x, y, x + w, y + h, 3, hov ? 0xFF1E5F8C : 0xFF121C2A);
        RenderUtil.outline(c, x, y, x + w, y + h, RenderUtil.withAlpha(RenderUtil.SKY, hov ? 0.9f : 0.4f));
        c.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF, false);
    }
}
