package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.config.ConfigManager;
import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.ModuleManager;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.module.setting.Setting;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.StarField;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;

/** Clean sky-blue / black mod menu. Fades in smoothly. Open/close with Right Shift. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF3070A12, SIDE = 0xFF090D15, ROW = 0xFF0F1521, ROW_HOVER = 0xFF161F30;
    private static final int TEXT = 0xFFE8F1FF, DIM = 0xFF7A8AA3, TRACK = 0xFF263147;
    private static final int SIDE_W = 132;

    private final Screen parent;
    private final UiInput in = new UiInput();
    private final StarField stars = new StarField(170, 7L);
    private final long startNanos = System.nanoTime();
    private long last = startNanos;

    private Category tab = Category.HUD;
    private float scroll, scrollTarget, openT, alpha;
    private NumberSetting dragging;
    private int dragX1, dragX2;
    private Runnable post;

    public ClickGuiScreen(Screen parent) {
        super(Text.literal("Solar Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        in.sync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void close() {
        ConfigManager.save();
        client.setScreen(parent);
    }

    // no @Override on purpose: if the signature matches it overrides, otherwise it is simply unused
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 28f;
        return true;
    }

    // ---------- helpers ----------
    private int a(int col) {
        return RenderUtil.withAlpha(col, alpha);
    }

    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void text(DrawContext c, String s, int x, int y, int col) {
        if (alpha < 0.05f) return;
        c.drawText(textRenderer, s, x, y, a(col), false);
    }

    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        text(c, s, cx - textRenderer.getWidth(s) / 2, y, col);
    }

    private void small(DrawContext c, String s, int x, int y, float sc, int col) {
        if (alpha < 0.05f) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(sc, sc);
        c.drawText(textRenderer, s, 0, 0, a(col), false);
        m.popMatrix();
    }

    private void toggleSwitch(DrawContext c, int x, int y, int w, int h, float t) {
        RenderUtil.rrect(c, x, y, x + w, y + h, h / 2, a(RenderUtil.lerp(TRACK, RenderUtil.SKY, t)));
        double kx = x + h / 2.0 + t * (w - h);
        RenderUtil.circle(c, kx, y + h / 2.0, h / 2.0 - 2, a(0xFFFFFFFF));
    }

    private void chevron(DrawContext c, int cx, int cy, boolean up, int col) {
        for (int i = 0; i < 3; i++) {
            int w = up ? i : 2 - i;
            c.fill(cx - 2 + w, cy + i, cx + 3 - w, cy + i + 1, a(col));
        }
    }

    private static int catColor(Category cat) {
        return switch (cat) {
            case HUD -> 0xFF38BDF8;
            case PVP -> 0xFFEF4444;
            case MUSIC -> 0xFF4ADE80;
            case VISUAL -> 0xFFA78BFA;
            case PERFORMANCE -> 0xFFFFC857;
            default -> 0xFF94A3B8;
        };
    }

    private boolean pill(DrawContext c, int mx, int my, int x, int y, int w, int h, String label, int accent) {
        boolean hov = hit(mx, my, x, y, w, h);
        RenderUtil.rrect(c, x, y, x + w, y + h, h / 2, a(hov ? RenderUtil.withAlpha(accent, 0.35f) : RenderUtil.withAlpha(accent, 0.14f)));
        RenderUtil.outline(c, x, y, x + w, y + h, a(RenderUtil.withAlpha(accent, hov ? 0.8f : 0.4f)));
        ctext(c, label, x + w / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF);
        return hov && in.leftClick;
    }

    private static int settingHeight(Setting s) {
        if (s instanceof NumberSetting) return 30;
        if (s instanceof ActionSetting || s instanceof ModeSetting) return 24;
        return 22;
    }

    private static int settingsHeight(Module m) {
        int h = 0;
        for (Setting s : m.settings) h += settingHeight(s);
        return h > 0 ? h + 8 : 0;
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        final double time = (now - startNanos) / 1e9;
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        post = null;

        openT = Math.min(1f, openT + dt / 0.3f);
        float e = 1f - (float) Math.pow(1f - openT, 3);
        alpha = e;
        int oy = Math.round((1f - e) * 22f);

        int sw = width, sh = height;
        c.fill(0, 0, sw, sh, a(0x70000000));
        stars.render(c, sw, sh, time, alpha);

        int ww = Math.min(620, sw - 24), wh = Math.min(370, sh - 24);
        int wx = (sw - ww) / 2, wy = (sh - wh) / 2 + oy;

        // window: soft glow, border, body, header glow
        RenderUtil.rrect(c, wx - 3, wy - 3, wx + ww + 3, wy + wh + 3, 9, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.10f)));
        RenderUtil.rrect(c, wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 7, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.40f)));
        RenderUtil.rrect(c, wx, wy, wx + ww, wy + wh, 6, a(BG));
        for (int i = 0; i < 12; i++) {
            c.fill(wx + 3, wy + 2 + i * 4, wx + ww - 3, wy + 2 + (i + 1) * 4,
                    a(RenderUtil.withAlpha(RenderUtil.SKY, 0.07f * (1f - i / 12f))));
        }
        c.fill(wx + SIDE_W, wy + 41, wx + SIDE_W + 1, wy + wh - 1, a(0x16FFFFFF));
        c.fill(wx + 1, wy + 40, wx + ww - 1, wy + 41, a(0x16FFFFFF));

        // header: little planet + title
        RenderUtil.circle(c, wx + 22, wy + 21, 8, a(0xFF123A6B));
        RenderUtil.circle(c, wx + 20, wy + 19, 6.5, a(0xFF38A0E8));
        for (int k = 0; k < 28; k++) {
            double ang = k * Math.PI * 2 / 28;
            int rx = (int) Math.round(wx + 22 + Math.cos(ang) * 13), ry = (int) Math.round(wy + 21 + Math.sin(ang) * 4 - 1);
            c.fill(rx, ry, rx + 1, ry + 1, a(0xAABFE3FF));
        }
        if (alpha >= 0.05f) {
            RenderUtil.gradientText(c, textRenderer, "SOLAR CLIENT", wx + 42, wy + 13, 1.4f, false,
                    f -> a(RenderUtil.skyGradient(f, time)));
        }
        small(c, "v" + SolarClient.VERSION, wx + 42 + (int) (textRenderer.getWidth("SOLAR CLIENT") * 1.4f) + 6, wy + 17, 0.75f, DIM);

        // header actions (right aligned)
        int py = wy + 10, ph = 20;
        int x = wx + ww - 12;
        x -= 54;
        if (pill(c, mx, my, x, py, 54, ph, "Exit", 0xFFEF4444)) post = this::close;
        x -= 8 + 72;
        if (pill(c, mx, my, x, py, 72, ph, "Music", 0xFF4ADE80)) post = () -> client.setScreen(new MusicScreen(this));
        x -= 8 + 72;
        if (pill(c, mx, my, x, py, 72, ph, "Edit HUD", RenderUtil.SKY)) post = () -> client.setScreen(new HudEditorScreen(this));

        // sidebar
        int ty = wy + 50;
        for (Category cat : Category.values()) {
            boolean sel = cat == tab;
            boolean hov = hit(mx, my, wx + 8, ty, SIDE_W - 16, 24);
            int col = catColor(cat);
            if (sel) RenderUtil.rrect(c, wx + 8, ty, wx + SIDE_W - 8, ty + 24, 5, a(RenderUtil.withAlpha(col, 0.16f)));
            else if (hov) RenderUtil.rrect(c, wx + 8, ty, wx + SIDE_W - 8, ty + 24, 5, a(0x12FFFFFF));
            if (sel) c.fill(wx + 8, ty + 5, wx + 10, ty + 19, a(col));
            RenderUtil.circle(c, wx + 22, ty + 12, 3, a(sel || hov ? col : RenderUtil.withAlpha(col, 0.6f)));
            text(c, cat.label, wx + 32, ty + 8, sel ? 0xFFFFFFFF : 0xFFB6C4D8);
            List<Module> ml = ModuleManager.byCategory(cat);
            int on = 0, tot = 0;
            for (Module m : ml) if (m.toggleable) { tot++; if (m.isEnabled()) on++; }
            if (tot > 0) {
                String cnt = on + "/" + tot;
                text(c, cnt, wx + SIDE_W - 14 - textRenderer.getWidth(cnt), ty + 8, sel ? col : DIM);
            }
            if (hov && in.leftClick && !sel) {
                tab = cat;
                scroll = 0;
                scrollTarget = 0;
            }
            ty += 28;
        }
        small(c, "RIGHT SHIFT to close", wx + 14, wy + wh - 14, 0.75f, 0xFF4B5B75);

        // content header
        List<Module> mods = ModuleManager.byCategory(tab);
        int lx1 = wx + SIDE_W + 14, lx2 = wx + ww - 16;
        int on = 0, tot = 0;
        for (Module m : mods) if (m.toggleable) { tot++; if (m.isEnabled()) on++; }
        if (alpha >= 0.05f) {
            var hm = c.getMatrices();
            hm.pushMatrix();
            hm.translate(lx1, wy + 49);
            hm.scale(1.25f, 1.25f);
            c.drawText(textRenderer, tab.label, 0, 0, a(0xFFFFFFFF), false);
            hm.popMatrix();
        }
        small(c, tot > 0 ? tot + " modules  -  " + on + " enabled" : "Appearance options", lx1, wy + 63, 0.8f, DIM);

        int listTop = wy + 76, listBottom = wy + wh - 10;
        if (dragging != null) {
            if (in.left) dragging.setFromFraction((mx - dragX1) / (double) Math.max(1, dragX2 - dragX1));
            else dragging = null;
        }
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
        boolean inList = my >= listTop && my < listBottom;

        c.enableScissor(lx1 - 2, listTop, lx2 + 4, listBottom);
        int y = listTop - Math.round(scroll);
        int startY = y;
        for (Module m : mods) {
            y = drawModule(c, m, lx1, lx2, y, mx, my, inList, dt);
            y += 7;
        }
        c.disableScissor();

        int contentH = y - startY;
        int viewH = listBottom - listTop;
        float maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        if (maxScroll > 0) {
            int thumbH = Math.max(18, (int) (viewH * (viewH / (float) contentH)));
            int thumbY = listTop + (int) ((viewH - thumbH) * (scroll / maxScroll));
            RenderUtil.rrect(c, lx2 + 6, thumbY, lx2 + 8, thumbY + thumbH, 1, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.6f)));
        }

        if (post != null) post.run();
    }

    private int drawModule(DrawContext c, Module m, int x1, int x2, int y, int mx, int my, boolean inList, float dt) {
        final int rowH = 34;
        boolean hasSettings = !m.settings.isEmpty();
        boolean hover = inList && hit(mx, my, x1, y, x2 - x1, rowH);

        m.toggleAnim += ((m.isEnabled() ? 1f : 0f) - m.toggleAnim) * Math.min(1f, dt * 16f);
        float targetExp = (m.expanded || !m.toggleable) ? 1f : 0f;
        m.expandAnim += (targetExp - m.expandAnim) * Math.min(1f, dt * 14f);
        int sh = Math.round(settingsHeight(m) * m.expandAnim);
        int accent = catColor(m.category);

        // card
        RenderUtil.rrect(c, x1, y, x2, y + rowH + sh, 6, a(hover ? ROW_HOVER : ROW));
        if (m.toggleable && m.toggleAnim > 0.02f) {
            RenderUtil.rrect(c, x1, y, x2, y + rowH, 6, a(RenderUtil.withAlpha(accent, 0.07f * m.toggleAnim)));
            c.fill(x1, y + 7, x1 + 3, y + rowH - 7, a(RenderUtil.withAlpha(accent, m.toggleAnim)));
        }
        text(c, m.name, x1 + 14, y + 7, m.toggleable && m.isEnabled() ? 0xFFFFFFFF : TEXT);
        small(c, m.description, x1 + 14, y + 21, 0.75f, DIM);

        int expX = x2 - 78;
        if (m.toggleable) {
            toggleSwitch(c, x2 - 46, y + 10, 32, 14, m.toggleAnim);
            if (hasSettings) {
                boolean eh = inList && hit(mx, my, expX, y + 7, 20, 20);
                RenderUtil.rrect(c, expX, y + 7, expX + 20, y + 27, 5, a(eh ? 0x30FFFFFF : 0x12FFFFFF));
                chevron(c, expX + 10, y + 15, m.expanded, 0xFFB6C4D8);
            }
        }

        if (hover) {
            boolean onExp = m.toggleable && hasSettings && mx >= expX && mx < expX + 22;
            if (in.leftClick) {
                if (onExp) m.expanded = !m.expanded;
                else if (m.toggleable) m.toggle();
            }
            if (in.rightClick && hasSettings && m.toggleable) m.expanded = !m.expanded;
        }

        // settings panel
        if (sh > 1) {
            int areaTop = y + rowH, areaBot = y + rowH + sh;
            c.enableScissor(x1, areaTop, x2, areaBot);
            c.fill(x1 + 1, areaTop, x2 - 1, areaBot - 1, a(0x38000000));
            c.fill(x1 + 10, areaTop + 4, x1 + 11, areaBot - 6, a(RenderUtil.withAlpha(accent, 0.45f)));
            int sx1 = x1 + 24, sx2 = x2 - 14;
            int sy = areaTop + 4;
            for (Setting s : m.settings) {
                int h = settingHeight(s);
                boolean hv = inList && my < areaBot && hit(mx, my, sx1, sy, sx2 - sx1, h);
                if (s instanceof BoolSetting b) {
                    text(c, b.name, sx1, sy + 7, 0xFFC9D6EA);
                    toggleSwitch(c, sx2 - 28, sy + 4, 28, 13, b.get() ? 1f : 0f);
                    if (hv && in.leftClick) b.toggle();
                } else if (s instanceof ModeSetting ms) {
                    text(c, ms.name, sx1, sy + 8, 0xFFC9D6EA);
                    int mw = 92;
                    RenderUtil.rrect(c, sx2 - mw, sy + 2, sx2, sy + 20, 5, a(hv ? 0xFF223049 : 0xFF19222F));
                    RenderUtil.outline(c, sx2 - mw, sy + 2, sx2, sy + 20, a(RenderUtil.withAlpha(accent, hv ? 0.6f : 0.25f)));
                    ctext(c, ms.get(), sx2 - mw / 2, sy + 7, 0xFFFFFFFF);
                    if (hv && in.leftClick) ms.next();
                    if (hv && in.rightClick) ms.prev();
                } else if (s instanceof NumberSetting ns) {
                    text(c, ns.name, sx1, sy + 3, 0xFFC9D6EA);
                    String val = ns.name.equals("Max FPS") && ns.getInt() >= 260 ? "Unlimited"
                            : (ns.step >= 1 ? String.valueOf(ns.getInt()) : String.format(Locale.ROOT, "%.1f", ns.get()));
                    text(c, val, sx2 - textRenderer.getWidth(val), sy + 3, 0xFFFFFFFF);
                    int ty = sy + 19;
                    float f = (float) ns.fraction();
                    RenderUtil.rrect(c, sx1, ty, sx2, ty + 4, 2, a(TRACK));
                    int fw = Math.round((sx2 - sx1) * f);
                    if (fw > 0) RenderUtil.rrect(c, sx1, ty, sx1 + Math.max(4, fw), ty + 4, 2, a(accent));
                    RenderUtil.circle(c, sx1 + (sx2 - sx1) * f, ty + 2, 5, a(RenderUtil.withAlpha(accent, 0.45f)));
                    RenderUtil.circle(c, sx1 + (sx2 - sx1) * f, ty + 2, 3.5, a(0xFFFFFFFF));
                    if (hv && in.leftClick && my >= sy + 12) {
                        dragging = ns;
                        dragX1 = sx1;
                        dragX2 = sx2;
                    }
                } else if (s instanceof ActionSetting as) {
                    RenderUtil.rrect(c, sx1, sy + 2, sx2, sy + 20, 5, a(hv ? RenderUtil.withAlpha(accent, 0.45f) : RenderUtil.withAlpha(accent, 0.18f)));
                    RenderUtil.outline(c, sx1, sy + 2, sx2, sy + 20, a(RenderUtil.withAlpha(accent, hv ? 0.9f : 0.4f)));
                    ctext(c, as.name, (sx1 + sx2) / 2, sy + 7, 0xFFFFFFFF);
                    if (hv && in.leftClick) as.run();
                }
                sy += h;
            }
            c.disableScissor();
        }
        return y + rowH + sh;
    }
}
