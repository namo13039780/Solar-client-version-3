package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.config.ConfigManager;
import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.ModuleManager;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.module.setting.Setting;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.StarField;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;

/** Sky-blue / black mod menu. Opens with a smooth fade + slide. Open/close with Right Shift. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF2080B11, SIDE = 0xFF0B0F16, ROW = 0xFF121822, ROW_HOVER = 0xFF18202D;
    private static final int TEXT = 0xFFE8F1FF, DIM = 0xFF7A8AA3, TRACK = 0xFF283142;
    private static final int SIDE_W = 116;

    private final Screen parent;
    private final UiInput in = new UiInput();
    private final StarField stars = new StarField(90, 7L);
    private final long startNanos = System.nanoTime();
    private long last = startNanos;

    private Category tab = Category.HUD;
    private float scroll, scrollTarget, openT, alpha;
    private NumberSetting dragging;
    private int dragX1, dragX2;
    private Runnable post;

    public ClickGuiScreen(Screen parent) {
        super(Text.literal("Solar Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        in.sync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void close() {
        ConfigManager.save();
        client.setScreen(parent);
    }

    // no @Override on purpose: if the signature matches it overrides, otherwise it is simply unused
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 28f;
        return true;
    }

    // ---------- helpers ----------
    private int a(int col) {
        return RenderUtil.withAlpha(col, alpha);
    }

    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void text(DrawContext c, String s, int x, int y, int col) {
        if (alpha < 0.05f) return;
        c.drawText(textRenderer, s, x, y, a(col), false);
    }

    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        text(c, s, cx - textRenderer.getWidth(s) / 2, y, col);
    }

    private void small(DrawContext c, String s, int x, int y, float sc, int col) {
        if (alpha < 0.05f) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(sc, sc);
        c.drawText(textRenderer, s, 0, 0, a(col), false);
        m.popMatrix();
    }

    private void toggleSwitch(DrawContext c, int x, int y, int w, int h, float t) {
        RenderUtil.rrect(c, x, y, x + w, y + h, h / 2, a(RenderUtil.lerp(TRACK, RenderUtil.SKY, t)));
        double kx = x + h / 2.0 + t * (w - h);
        RenderUtil.circle(c, kx, y + h / 2.0, h / 2.0 - 2, a(0xFFFFFFFF));
    }

    private static int settingHeight(Setting s) {
        if (s instanceof NumberSetting) return 28;
        if (s instanceof ActionSetting) return 22;
        return 20;
    }

    private static int settingsHeight(Module m) {
        int h = 0;
        for (Setting s : m.settings) h += settingHeight(s);
        return h > 0 ? h + 6 : 0;
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        final double time = (now - startNanos) / 1e9;
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        post = null;

        openT = Math.min(1f, openT + dt / 0.28f);
        float e = 1f - (float) Math.pow(1f - openT, 3);
        alpha = e;
        int oy = Math.round((1f - e) * 20f);

        int sw = width, sh = height;
        c.fill(0, 0, sw, sh, a(0xA8000000));
        stars.render(c, sw, sh, time, alpha * 0.8f);

        int ww = Math.min(580, sw - 24), wh = Math.min(350, sh - 24);
        int wx = (sw - ww) / 2, wy = (sh - wh) / 2 + oy;

        // window + border
        RenderUtil.rrect(c, wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 6, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.45f)));
        RenderUtil.rrect(c, wx, wy, wx + ww, wy + wh, 6, a(BG));
        for (int i = 0; i < ww; i += 4) {
            c.fill(wx + i, wy, wx + Math.min(ww, i + 4), wy + 2, a(RenderUtil.skyGradient(i / (float) ww, time)));
        }
        c.fill(wx + 1, wy + 33, wx + SIDE_W, wy + wh - 1, a(SIDE));
        c.fill(wx + 1, wy + 33, wx + ww - 1, wy + 34, a(0x22FFFFFF));

        // header
        if (alpha >= 0.05f) {
            RenderUtil.gradientText(c, textRenderer, "SOLAR CLIENT", wx + 14, wy + 11, 1.4f, false,
                    f -> a(RenderUtil.skyGradient(f, time)));
        }
        small(c, "v" + SolarClient.VERSION, wx + 14 + (int) (textRenderer.getWidth("SOLAR CLIENT") * 1.4f) + 8, wy + 14, 0.8f, DIM);

        // exit button (top right)
        int bx = wx + ww - 68, by = wy + 8, bw = 58, bh = 18;
        boolean exitHover = hit(mx, my, bx, by, bw, bh);
        RenderUtil.rrect(c, bx, by, bx + bw, by + bh, 4, a(exitHover ? 0xFFDC3545 : 0x553A1018));
        RenderUtil.outline(c, bx, by, bx + bw, by + bh, a(exitHover ? 0xFFFF6B7A : 0x66EF4444));
        ctext(c, "Exit", bx + bw / 2, by + 5, 0xFFFFFFFF);
        if (exitHover && in.leftClick) post = this::close;

        // sidebar tabs
        int ty = wy + 44;
        for (Category cat : Category.values()) {
            boolean sel = cat == tab;
            boolean hov = hit(mx, my, wx + 8, ty, SIDE_W - 16, 22);
            if (sel) RenderUtil.rrect(c, wx + 8, ty, wx + SIDE_W - 8, ty + 22, 4, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.18f)));
            else if (hov) RenderUtil.rrect(c, wx + 8, ty, wx + SIDE_W - 8, ty + 22, 4, a(0x14FFFFFF));
            if (sel) c.fill(wx + 8, ty + 4, wx + 10, ty + 18, a(RenderUtil.SKY));
            text(c, cat.label, wx + 18, ty + 7, sel ? RenderUtil.SKY_LIGHT : 0xFFB6C4D8);
            if (hov && in.leftClick && !sel) {
                tab = cat;
                scroll = 0;
                scrollTarget = 0;
            }
            ty += 26;
        }

        // Edit HUD button (bottom of sidebar)
        int ex = wx + 8, ey = wy + wh - 34, ew = SIDE_W - 16, eh = 22;
        boolean eh_ = hit(mx, my, ex, ey, ew, eh);
        RenderUtil.rrect(c, ex, ey, ex + ew, ey + eh, 4, a(eh_ ? 0xFF1E5F8C : 0xFF121C2A));
        RenderUtil.outline(c, ex, ey, ex + ew, ey + eh, a(RenderUtil.withAlpha(RenderUtil.SKY, eh_ ? 0.9f : 0.45f)));
        ctext(c, "Edit HUD", ex + ew / 2, ey + 7, 0xFFFFFFFF);
        if (eh_ && in.leftClick) post = () -> client.setScreen(new HudEditorScreen(this));

        // content
        List<Module> mods = ModuleManager.byCategory(tab);
        int lx1 = wx + SIDE_W + 10, lx2 = wx + ww - 14;
        int listTop = wy + 58, listBottom = wy + wh - 10;
        text(c, tab.label.toUpperCase(Locale.ROOT) + "  -  " + mods.size() + (mods.size() == 1 ? " item" : " items"), lx1, wy + 42, DIM);

        if (dragging != null) {
            if (in.left) dragging.setFromFraction((mx - dragX1) / (double) Math.max(1, dragX2 - dragX1));
            else dragging = null;
        }

        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
        boolean inList = my >= listTop && my < listBottom;

        c.enableScissor(lx1 - 2, listTop, lx2 + 2, listBottom);
        int y = listTop - Math.round(scroll);
        int startY = y;
        for (Module m : mods) {
            y = drawModule(c, m, lx1, lx2, y, mx, my, inList, dt);
            y += 6;
        }
        c.disableScissor();

        int contentH = y - startY;
        int viewH = listBottom - listTop;
        float maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        if (maxScroll > 0) {
            int trackH = viewH;
            int thumbH = Math.max(18, (int) (trackH * (viewH / (float) contentH)));
            int thumbY = listTop + (int) ((trackH - thumbH) * (scroll / maxScroll));
            c.fill(lx2 + 5, thumbY, lx2 + 7, thumbY + thumbH, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.6f)));
        }

        // footer hint
        small(c, "RIGHT SHIFT = open / close   |   Right click a module to show its settings", wx + SIDE_W + 10, wy + wh - 8, 0.7f, 0xFF4B5B75);

        if (post != null) post.run();
    }

    private int drawModule(DrawContext c, Module m, int x1, int x2, int y, int mx, int my, boolean inList, float dt) {
        final int rowH = 28;
        boolean hasSettings = !m.settings.isEmpty();
        boolean hover = inList && hit(mx, my, x1, y, x2 - x1, rowH);

        m.toggleAnim += ((m.isEnabled() ? 1f : 0f) - m.toggleAnim) * Math.min(1f, dt * 16f);
        float targetExp = (m.expanded || !m.toggleable) ? 1f : 0f;
        m.expandAnim += (targetExp - m.expandAnim) * Math.min(1f, dt * 14f);
        int fullH = settingsHeight(m);
        int sh = Math.round(fullH * m.expandAnim);

        // card
        RenderUtil.rrect(c, x1, y, x2, y + rowH + sh, 4, a(hover ? ROW_HOVER : ROW));
        if (m.toggleable && m.toggleAnim > 0.02f) {
            c.fill(x1, y + 5, x1 + 2, y + rowH - 5, a(RenderUtil.withAlpha(RenderUtil.SKY, m.toggleAnim)));
        }
        text(c, m.name, x1 + 10, y + 6, TEXT);
        small(c, m.description, x1 + 10, y + 18, 0.78f, DIM);

        int expX = x2 - 62;
        if (m.toggleable) {
            toggleSwitch(c, x2 - 38, y + 8, 28, 12, m.toggleAnim);
            if (hasSettings) {
                boolean eh = inList && hit(mx, my, expX, y + 6, 16, 16);
                RenderUtil.rrect(c, expX, y + 6, expX + 16, y + 22, 3, a(eh ? 0x33FFFFFF : 0x14FFFFFF));
                ctext(c, m.expanded ? "-" : "+", expX + 8, y + 10, 0xFFB6C4D8);
            }
        }

        if (hover) {
            boolean onExp = m.toggleable && hasSettings && mx >= expX && mx < expX + 18;
            if (in.leftClick) {
                if (onExp) m.expanded = !m.expanded;
                else if (m.toggleable) m.toggle();
            }
            if (in.rightClick && hasSettings && m.toggleable) m.expanded = !m.expanded;
        }

        // settings
        if (sh > 1) {
            int areaTop = y + rowH, areaBot = y + rowH + sh;
            c.enableScissor(x1, areaTop, x2, areaBot);
            int sx1 = x1 + 12, sx2 = x2 - 12;
            int sy = areaTop + 3;
            for (Setting s : m.settings) {
                int h = settingHeight(s);
                boolean hv = inList && my < areaBot && hit(mx, my, sx1, sy, sx2 - sx1, h);
                if (s instanceof BoolSetting b) {
                    text(c, b.name, sx1, sy + 6, 0xFFC9D6EA);
                    toggleSwitch(c, sx2 - 24, sy + 4, 24, 11, b.get() ? 1f : 0f);
                    if (hv && in.leftClick) b.toggle();
                } else if (s instanceof ModeSetting ms) {
                    text(c, ms.name, sx1, sy + 6, 0xFFC9D6EA);
                    int mw = 76;
                    RenderUtil.rrect(c, sx2 - mw, sy + 2, sx2, sy + 18, 3, a(hv ? 0xFF223049 : 0xFF1A2434));
                    ctext(c, ms.get(), sx2 - mw / 2, sy + 6, RenderUtil.SKY_LIGHT);
                    if (hv && in.leftClick) ms.next();
                    if (hv && in.rightClick) ms.prev();
                } else if (s instanceof NumberSetting ns) {
                    text(c, ns.name, sx1, sy + 3, 0xFFC9D6EA);
                    String val = ns.name.equals("Max FPS") && ns.getInt() >= 260 ? "Unlimited"
                            : (ns.step >= 1 ? String.valueOf(ns.getInt()) : String.format(Locale.ROOT, "%.1f", ns.get()));
                    text(c, val, sx2 - textRenderer.getWidth(val), sy + 3, RenderUtil.SKY_LIGHT);
                    int ty = sy + 18;
                    float f = (float) ns.fraction();
                    c.fill(sx1, ty, sx2, ty + 3, a(TRACK));
                    c.fill(sx1, ty, sx1 + Math.round((sx2 - sx1) * f), ty + 3, a(RenderUtil.SKY));
                    RenderUtil.circle(c, sx1 + (sx2 - sx1) * f, ty + 1.5, 4, a(0xFFFFFFFF));
                    if (hv && in.leftClick && my >= sy + 12) {
                        dragging = ns;
                        dragX1 = sx1;
                        dragX2 = sx2;
                    }
                } else if (s instanceof ActionSetting as) {
                    RenderUtil.rrect(c, sx1, sy + 2, sx2, sy + 20, 3, a(hv ? 0xFF1E5F8C : 0xFF1A2434));
                    ctext(c, as.name, (sx1 + sx2) / 2, sy + 7, 0xFFFFFFFF);
                    if (hv && in.leftClick) as.run();
                }
                sy += h;
            }
            c.disableScissor();
        }
        return y + rowH + sh;
    }
}
