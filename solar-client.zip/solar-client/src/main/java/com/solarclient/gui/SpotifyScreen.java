package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.module.impl.MusicModule;
import com.solarclient.music.SpotifyClient;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.StarField;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Log in to Spotify, search songs and control playback of the Spotify app. */
public class SpotifyScreen extends Screen {
    private static final int BG = 0xF2080B11, ROW = 0xFF121822, ROW_HOVER = 0xFF1A2333, TEXT = 0xFFE8F1FF, DIM = 0xFF7A8AA3;
    private static final int GREEN = 0xFF1ED760;

    private final Screen parent;
    private final UiInput in = new UiInput();
    private final StarField stars = new StarField(120, 21L);
    private final long startNanos = System.nanoTime();
    private long last = startNanos;
    private float openT, alpha, scroll, scrollTarget;
    private boolean editId;
    private Runnable post;
    private TextFieldWidget idField, searchField;

    public SpotifyScreen(Screen parent) {
        super(Text.literal("Spotify"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        in.sync();
        idField = new TextFieldWidget(textRenderer, 0, 0, 200, 18, Text.literal("Client ID"));
        idField.setMaxLength(100);
        idField.setPlaceholder(Text.literal("Paste Spotify Client ID"));
        searchField = new TextFieldWidget(textRenderer, 0, 0, 200, 18, Text.literal("Search"));
        searchField.setMaxLength(100);
        searchField.setPlaceholder(Text.literal("Search a song or artist"));
        addDrawableChild(idField);
        addDrawableChild(searchField);
        idField.visible = false;
        idField.active = false;
        searchField.visible = false;
        searchField.active = false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    // no @Override on purpose (signature differs between versions)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 24f;
        return true;
    }

    private int a(int col) {
        return RenderUtil.withAlpha(col, alpha);
    }

    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void text(DrawContext c, String s, int x, int y, int col) {
        if (alpha < 0.05f) return;
        c.drawText(textRenderer, s, x, y, a(col), false);
    }

    private boolean button(DrawContext c, int mx, int my, int x, int y, int w, int h, String label, int accent) {
        boolean hov = hit(mx, my, x, y, w, h);
        RenderUtil.rrect(c, x, y, x + w, y + h, 5, a(RenderUtil.withAlpha(accent, hov ? 0.4f : 0.16f)));
        RenderUtil.outline(c, x, y, x + w, y + h, a(RenderUtil.withAlpha(accent, hov ? 0.9f : 0.45f)));
        if (alpha >= 0.05f) {
            c.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2 + 1, a(0xFFFFFFFF), false);
        }
        return hov && in.leftClick;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        final double time = (now - startNanos) / 1e9;
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        post = null;
        SpotifyClient sp = SpotifyClient.I;

        openT = Math.min(1f, openT + dt / 0.28f);
        alpha = 1f - (float) Math.pow(1f - openT, 3);
        int oy = Math.round((1f - alpha) * 20f);

        int sw = width, sh = height;
        c.fill(0, 0, sw, sh, a(0xB0000000));
        stars.render(c, sw, sh, time, alpha);

        int ww = Math.min(520, sw - 24), wh = Math.min(300, sh - 24);
        int wx = (sw - ww) / 2, wy = (sh - wh) / 2 + oy;
        RenderUtil.rrect(c, wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 6, a(RenderUtil.withAlpha(GREEN, 0.45f)));
        RenderUtil.rrect(c, wx, wy, wx + ww, wy + wh, 6, a(BG));
        for (int i = 0; i < ww; i += 4) {
            c.fill(wx + i, wy, wx + Math.min(ww, i + 4), wy + 2, a(RenderUtil.lerp(GREEN, RenderUtil.SKY, i / (float) ww)));
        }
        text(c, "SPOTIFY", wx + 14, wy + 12, GREEN);
        if (button(c, mx, my, wx + ww - 68, wy + 8, 58, 18, "Exit", 0xFFEF4444)) post = this::close;

        int x1 = wx + 14, x2 = wx + ww - 14;
        int y = wy + 36;
        boolean needId = !sp.hasClientId() || editId;

        idField.visible = needId;
        idField.active = needId;
        searchField.visible = false;
        searchField.active = false;

        text(c, textRenderer.trimToWidth(sp.status, x2 - x1), x1, y, sp.connected ? GREEN : 0xFFFFC857);
        y += 16;

        if (needId) {
            text(c, "1) developer.spotify.com/dashboard -> Create app (free)", x1, y, DIM);
            text(c, "2) Redirect URI: http://127.0.0.1:8888/callback  (type exactly)", x1, y + 11, DIM);
            text(c, "3) Tick \"Web API\", Save, then copy the Client ID and paste it here", x1, y + 22, DIM);
            y += 40;
            idField.setX(x1);
            idField.setY(y);
            idField.setWidth(x2 - x1 - 70);
            idField.render(c, mx, my, delta);
            if (button(c, mx, my, x2 - 64, y, 64, 18, "Save", GREEN)) {
                String id = idField.getText().trim();
                if (!id.isEmpty()) {
                    sp.setClientId(id);
                    editId = false;
                }
            }
            if (sp.hasClientId() && button(c, mx, my, x1, y + 26, 90, 18, "Cancel", 0xFF94A3B8)) editId = false;
        } else if (!sp.connected) {
            text(c, "Press Login: the link is copied. Paste it in your phone browser", x1, y, DIM);
            text(c, "and approve. Then come back to Minecraft.", x1, y + 11, DIM);
            y += 30;
            if (button(c, mx, my, x1, y, 110, 22, "Login", GREEN)) sp.login(client);
            if (button(c, mx, my, x1 + 120, y, 130, 22, "Change Client ID", 0xFF94A3B8)) {
                editId = true;
                idField.setText(sp.clientId());
            }
        } else {
            // now playing
            String now0 = sp.title.isEmpty() ? "Nothing playing - start a song in the Spotify app" : sp.title + " - " + sp.artist;
            text(c, textRenderer.trimToWidth(now0, x2 - x1), x1, y, TEXT);
            y += 14;
            // controls
            if (button(c, mx, my, x1, y, 34, 20, "|<", 0xFF94A3B8)) sp.prev();
            if (button(c, mx, my, x1 + 38, y, 58, 20, sp.playing ? "Pause" : "Play", GREEN)) sp.togglePlay();
            if (button(c, mx, my, x1 + 100, y, 34, 20, ">|", 0xFF94A3B8)) sp.next();
            String lyr = "Lyrics: " + (sp.lyricsStatus.isEmpty() ? "-" : sp.lyricsStatus);
            text(c, lyr, x1 + 146, y + 6, DIM);
            if (button(c, mx, my, x2 - 60, y, 60, 20, "Logout", 0xFFEF4444)) sp.logout();
            y += 30;

            // search
            searchField.visible = true;
            searchField.active = true;
            searchField.setX(x1);
            searchField.setY(y);
            searchField.setWidth(x2 - x1 - 70);
            searchField.render(c, mx, my, delta);
            if (button(c, mx, my, x2 - 64, y, 64, 18, "Search", GREEN)) sp.search(searchField.getText());
            y += 26;

            // results
            List<SpotifyClient.Result> res = sp.results;
            int ly1 = y, ly2 = wy + wh - 10, rowH = 22;
            float maxScroll = Math.max(0, res.size() * rowH - (ly2 - ly1));
            scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
            scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
            if (res.isEmpty()) {
                text(c, "Search a song, then click it to play in Spotify.", x1, ly1 + 4, DIM);
            } else {
                c.enableScissor(x1, ly1, x2 + 2, ly2);
                boolean inList = my >= ly1 && my < ly2;
                for (int i = 0; i < res.size(); i++) {
                    int ry = ly1 + i * rowH - Math.round(scroll);
                    if (ry + rowH < ly1 || ry > ly2) continue;
                    boolean hov = inList && hit(mx, my, x1, ry, x2 - x1, rowH - 2);
                    RenderUtil.rrect(c, x1, ry, x2, ry + rowH - 2, 4, a(hov ? ROW_HOVER : ROW));
                    SpotifyClient.Result r = res.get(i);
                    text(c, textRenderer.trimToWidth(r.name + "  -  " + r.artist, x2 - x1 - 16), x1 + 8, ry + 7, TEXT);
                    if (hov && in.leftClick) sp.playUri(r.uri);
                }
                c.disableScissor();
            }
        }
        if (post != null) post.run();
    }
}
