package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.SolarSystemRenderer;
import com.solarclient.util.StarField;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Black space background, white stars, 3D-ish solar system, menu on the left. */
public class SolarTitleScreen extends Screen {
    private static final StarField STARS = new StarField(420, 42L);

    private final UiInput in = new UiInput();
    private final long start = System.nanoTime();
    private long last = start;
    private float fade;
    private final List<Btn> buttons = new ArrayList<>();

    private static final class Btn {
        final String label;
        final Runnable action;
        float hover;

        Btn(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
    }

    public SolarTitleScreen() {
        super(Text.literal("Solar Client"));
    }

    @Override
    protected void init() {
        in.sync();
        buttons.clear();
        buttons.add(new Btn("Singleplayer", () -> client.setScreen(new SelectWorldScreen(this))));
        buttons.add(new Btn("Multiplayer", () -> client.setScreen(new MultiplayerScreen(this))));
        buttons.add(new Btn("Solar Client", () -> client.setScreen(new ClickGuiScreen(this))));
        buttons.add(new Btn("Options", () -> client.setScreen(new OptionsScreen(this, client.options))));
        buttons.add(new Btn("Quit Game", () -> client.scheduleStop()));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
        // we paint our own background in render()
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        double t = (now - start) / 1e9;
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        fade = Math.min(1f, fade + dt / 0.9f);

        int sw = width, sh = height;
        c.fill(0, 0, sw, sh, 0xFF000000);
        STARS.render(c, sw, sh, t, 1f);

        int R = (int) Math.min(sw * 0.36f, sh * 0.95f);
        SolarSystemRenderer.render(c, (int) (sw * 0.66f), (int) (sh * 0.52f), R, t);

        // soft shadow on the left so the menu stays readable
        int strips = 28;
        int panelW = (int) (sw * 0.40f);
        for (int i = 0; i < strips; i++) {
            float k = 1f - i / (float) strips;
            int x1 = panelW * i / strips, x2 = panelW * (i + 1) / strips;
            c.fill(x1, 0, x2, sh, RenderUtil.withAlpha(0xFF000000, k * 0.6f));
        }

        // Title
        String title = "Solar Client";
        int tw = textRenderer.getWidth(title);
        float sc = Math.max(1.5f, Math.min(4f, sw * 0.36f / tw));
        int tx = Math.max(16, (int) (sw * 0.05f));
        int ty = (int) (sh * 0.15f);
        RenderUtil.gradientText(c, textRenderer, title, tx, ty, sc, false, f -> RenderUtil.skyGradient(f, t));
        int lineW = (int) (tw * sc);
        int lineY = ty + (int) (9 * sc) + 5;
        for (int i = 0; i < lineW; i += 3) {
            c.fill(tx + i, lineY, tx + Math.min(lineW, i + 3), lineY + 2, RenderUtil.skyGradient(i / (float) lineW, t));
        }
        c.drawText(textRenderer, "Minecraft 1.21.11  -  Fabric", tx, lineY + 8, 0xFF6F83A3, false);

        // Buttons
        int bw = Math.min(200, (int) (sw * 0.3f)), bh = 22, gap = 5;
        int by = lineY + 30;
        Runnable post = null;
        for (Btn b : buttons) {
            boolean hov = mx >= tx && mx < tx + bw && my >= by && my < by + bh;
            b.hover += ((hov ? 1f : 0f) - b.hover) * Math.min(1f, dt * 14f);
            int bg = RenderUtil.lerp(0x66101826, 0xAA16405F, b.hover);
            RenderUtil.rrect(c, tx, by, tx + bw, by + bh, 3, bg);
            c.fill(tx, by + 3, tx + 2 + Math.round(b.hover), by + bh - 3, RenderUtil.withAlpha(RenderUtil.SKY, 0.35f + 0.65f * b.hover));
            int tc = RenderUtil.lerp(0xFFB6C4D8, 0xFFFFFFFF, b.hover);
            c.drawText(textRenderer, b.label, tx + 12 + Math.round(b.hover * 4), by + (bh - 8) / 2 + 1, tc, false);
            if (hov && in.leftClick) post = b.action;
            by += bh + gap;
        }

        c.drawText(textRenderer, "Press RIGHT SHIFT to open the Solar menu", 8, sh - 14, 0xFF55657F, false);
        String ver = "Solar Client v" + SolarClient.VERSION;
        c.drawText(textRenderer, ver, sw - textRenderer.getWidth(ver) - 8, sh - 14, 0xFF55657F, false);

        if (fade < 1f) c.fill(0, 0, sw, sh, RenderUtil.withAlpha(0xFF000000, 1f - fade));
        if (post != null) post.run();
    }
}
