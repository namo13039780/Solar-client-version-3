package com.solarclient.gui;

import org.lwjgl.glfw.GLFW;

/** Polls the mouse/keyboard directly through GLFW so the GUI never depends on changing Screen input signatures. */
public final class UiInput {
    private boolean pl, pr;
    public boolean left, right, leftClick, rightClick;

    private static boolean prevKey;

    public UiInput() {
        sync();
    }

    public void sync() {
        long w = GLFW.glfwGetCurrentContext();
        pl = down(w, GLFW.GLFW_MOUSE_BUTTON_LEFT);
        pr = down(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        left = pl;
        right = pr;
        leftClick = false;
        rightClick = false;
    }

    public void update() {
        long w = GLFW.glfwGetCurrentContext();
        left = down(w, GLFW.GLFW_MOUSE_BUTTON_LEFT);
        right = down(w, GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        leftClick = left && !pl;
        rightClick = right && !pr;
        pl = left;
        pr = right;
    }

    private static boolean down(long w, int b) {
        return w != 0 && GLFW.glfwGetMouseButton(w, b) == GLFW.GLFW_PRESS;
    }

    /** True once per Right Shift press. */
    public static boolean pollToggleKey() {
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0) return false;
        boolean d = GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean edge = d && !prevKey;
        prevKey = d;
        return edge;
    }
}
