package com.solarclient.gui;

import com.solarclient.SolarClient;
import com.solarclient.module.impl.MusicModule;
import com.solarclient.music.MusicPlayer;
import com.solarclient.music.Track;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.StarField;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/** Track list + controls for the built-in music player. */
public class MusicScreen extends Screen {
    private static final int BG = 0xF2080B11, ROW = 0xFF121822, ROW_HOVER = 0xFF1A2333, TEXT = 0xFFE8F1FF, DIM = 0xFF7A8AA3;

    private final Screen parent;
    private final UiInput in = new UiInput();
    private final StarField stars = new StarField(140, 11L);
    private final long startNanos = System.nanoTime();
    private long last = startNanos;
    private float scroll, scrollTarget, openT, alpha, seekPreview;
    private boolean dragVol, dragSeek;
    private Runnable post;

    public MusicScreen(Screen parent) {
        super(Text.literal("Solar Music"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        in.sync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    // no @Override on purpose (signature differs between versions)
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 30f;
        return true;
    }

    private int a(int col) {
        return RenderUtil.withAlpha(col, alpha);
    }

    private boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void text(DrawContext c, String s, int x, int y, int col) {
        if (alpha < 0.05f) return;
        c.drawText(textRenderer, s, x, y, a(col), false);
    }

    private void ctext(DrawContext c, String s, int cx, int y, int col) {
        text(c, s, cx - textRenderer.getWidth(s) / 2, y, col);
    }

    private boolean button(DrawContext c, int mx, int my, int x, int y, int w, int h, String label, boolean active) {
        boolean hov = hit(mx, my, x, y, w, h);
        int bg = active ? 0xFF1E5F8C : (hov ? 0xFF223049 : 0xFF161F2E);
        RenderUtil.rrect(c, x, y, x + w, y + h, 4, a(bg));
        RenderUtil.outline(c, x, y, x + w, y + h, a(RenderUtil.withAlpha(RenderUtil.SKY, active || hov ? 0.8f : 0.35f)));
        ctext(c, label, x + w / 2, y + (h - 8) / 2 + 1, 0xFFFFFFFF);
        return hov && in.leftClick;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1_000_000_000f);
        last = now;
        final double time = (now - startNanos) / 1e9;
        in.update();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        post = null;
        MusicPlayer mp = MusicPlayer.I;
        MusicModule mm = MusicModule.I;

        openT = Math.min(1f, openT + dt / 0.28f);
        float e = 1f - (float) Math.pow(1f - openT, 3);
        alpha = e;
        int oy = Math.round((1f - e) * 20f);

        int sw = width, sh = height;
        c.fill(0, 0, sw, sh, a(0xB0000000));
        stars.render(c, sw, sh, time, alpha);

        int ww = Math.min(560, sw - 24), wh = Math.min(330, sh - 24);
        int wx = (sw - ww) / 2, wy = (sh - wh) / 2 + oy;
        RenderUtil.rrect(c, wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 6, a(RenderUtil.withAlpha(RenderUtil.SKY, 0.45f)));
        RenderUtil.rrect(c, wx, wy, wx + ww, wy + wh, 6, a(BG));
        for (int i = 0; i < ww; i += 4) {
            c.fill(wx + i, wy, wx + Math.min(ww, i + 4), wy + 2, a(RenderUtil.skyGradient(i / (float) ww, time)));
        }
        if (alpha >= 0.05f) {
            RenderUtil.gradientText(c, textRenderer, "SOLAR MUSIC", wx + 14, wy + 11, 1.4f, false,
                    f -> a(RenderUtil.skyGradient(f, time)));
        }

        // header buttons
        if (button(c, mx, my, wx + ww - 68, wy + 8, 58, 18, "Exit", false)) post = this::close;
        if (button(c, mx, my, wx + ww - 136, wy + 8, 62, 18, "Rescan", false)) mp.rescan();

        // list
        int lx1 = wx + 12, lx2 = wx + ww - 12, ly1 = wy + 38, ly2 = wy + wh - 82;
        List<Track> tracks = mp.tracks;
        int rowH = 22;
        float maxScroll = Math.max(0, tracks.size() * rowH - (ly2 - ly1));
        scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);

        if (tracks.isEmpty()) {
            text(c, "No music found.", lx1, ly1 + 6, TEXT);
            text(c, "Put .mp3 / .ogg files in one of these folders, then press Rescan:", lx1, ly1 + 20, DIM);
            int fy = ly1 + 32;
            for (java.nio.file.Path d : MusicPlayer.dirs()) {
                text(c, textRenderer.trimToWidth(d.toString(), lx2 - lx1), lx1, fy, RenderUtil.SKY_LIGHT);
                fy += 12;
            }
            text(c, "Direct links: playlist.txt  (Title | https://...mp3).  YouTube links are not supported.", lx1, fy + 4, DIM);
        } else {
            c.enableScissor(lx1, ly1, lx2 + 2, ly2);
            boolean inList = my >= ly1 && my < ly2;
            for (int i = 0; i < tracks.size(); i++) {
                int ry = ly1 + i * rowH - Math.round(scroll);
                if (ry + rowH < ly1 || ry > ly2) continue;
                boolean cur = i == mp.index;
                boolean hov = inList && hit(mx, my, lx1, ry, lx2 - lx1, rowH - 2);
                RenderUtil.rrect(c, lx1, ry, lx2, ry + rowH - 2, 4, a(cur ? 0xFF14344F : (hov ? ROW_HOVER : ROW)));
                if (cur) c.fill(lx1, ry + 4, lx1 + 2, ry + rowH - 6, a(RenderUtil.SKY));
                text(c, String.valueOf(i + 1), lx1 + 8, ry + 7, DIM);
                String name = textRenderer.trimToWidth(tracks.get(i).display(), lx2 - lx1 - 60);
                text(c, name, lx1 + 30, ry + 7, cur ? RenderUtil.SKY_LIGHT : TEXT);
                if (cur) {
                    String st = mp.state == MusicPlayer.State.PLAYING ? "Playing" : mp.state == MusicPlayer.State.PAUSED ? "Paused"
                            : mp.state == MusicPlayer.State.LOADING ? "Loading" : "";
                    text(c, st, lx2 - 8 - textRenderer.getWidth(st), ry + 7, 0xFF4ADE80);
                }
                if (hov && in.leftClick) mp.play(i);
            }
            c.disableScissor();
        }

        // controls panel
        int py = wy + wh - 76;
        c.fill(wx + 1, py - 4, wx + ww - 1, py - 3, a(0x22FFFFFF));
        Track ct = mp.current();
        String now0 = ct == null ? "Nothing playing" : ct.display();
        if (!mp.status.isEmpty()) now0 = mp.status;
        text(c, textRenderer.trimToWidth(now0, ww - 120), lx1, py + 2, mp.status.isEmpty() ? TEXT : 0xFFFF7A7A);
        String times = MusicPlayer.fmt(mp.position) + " / " + MusicPlayer.fmt(mp.duration);
        text(c, times, lx2 - textRenderer.getWidth(times), py + 2, DIM);

        // seek bar
        int sy = py + 18;
        boolean seekHov = hit(mx, my, lx1, sy - 5, lx2 - lx1, 14);
        if (seekHov && in.leftClick && mp.duration > 0) dragSeek = true;
        float frac = mp.duration > 0 ? (float) Math.min(1, mp.position / mp.duration) : 0f;
        if (dragSeek) {
            seekPreview = Math.max(0f, Math.min(1f, (mx - lx1) / (float) (lx2 - lx1)));
            frac = seekPreview;
            if (!in.left) {
                dragSeek = false;
                mp.seekFraction(seekPreview);
            }
        }
        c.fill(lx1, sy, lx2, sy + 4, a(0xFF26324A));
        c.fill(lx1, sy, lx1 + Math.round((lx2 - lx1) * frac), sy + 4, a(RenderUtil.SKY));
        RenderUtil.circle(c, lx1 + (lx2 - lx1) * frac, sy + 2, 4, a(0xFFFFFFFF));

        // buttons
        int by = py + 34, bh = 20, x = lx1;
        if (button(c, mx, my, x, by, 34, bh, "|<", false)) mp.prev();
        x += 38;
        boolean playing = mp.state == MusicPlayer.State.PLAYING;
        if (button(c, mx, my, x, by, 54, bh, playing ? "Pause" : "Play", playing)) mp.togglePause();
        x += 58;
        if (button(c, mx, my, x, by, 34, bh, ">|", false)) mp.next();
        x += 38;
        if (mm != null) {
            if (button(c, mx, my, x, by, 58, bh, "Shuffle", mm.shuffle.get())) mm.shuffle.toggle();
            x += 62;
            if (button(c, mx, my, x, by, 78, bh, "Repeat: " + mm.repeat.get(), !mm.repeat.is("Off"))) mm.repeat.next();
        }

        // volume
        if (mm != null) {
            int vx1 = lx2 - 110, vx2 = lx2 - 10, vy = by + 8;
            text(c, "Vol", vx1 - 22, by + 6, DIM);
            boolean vh = hit(mx, my, vx1 - 4, vy - 6, vx2 - vx1 + 8, 18);
            if (vh && in.leftClick) dragVol = true;
            if (dragVol) {
                if (in.left) mm.volume.setFromFraction((mx - vx1) / (double) (vx2 - vx1));
                else dragVol = false;
            }
            float vf = (float) mm.volume.fraction();
            c.fill(vx1, vy, vx2, vy + 4, a(0xFF26324A));
            c.fill(vx1, vy, vx1 + Math.round((vx2 - vx1) * vf), vy + 4, a(RenderUtil.SKY));
            RenderUtil.circle(c, vx1 + (vx2 - vx1) * vf, vy + 2, 4, a(0xFFFFFFFF));
        }

        if (post != null) post.run();
    }
}
