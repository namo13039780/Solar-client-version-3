package com.solarclient.hud;

import com.solarclient.SolarClient;
import com.solarclient.gui.HudEditorScreen;
import com.solarclient.gui.UiInput;
import com.solarclient.module.HudModule;
import com.solarclient.module.ModuleManager;
import com.solarclient.module.impl.GalaxySkyModule;
import com.solarclient.module.impl.MaceImpactModule;
import com.solarclient.module.impl.PlayerGlowModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class HudManager {
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (UiInput.pollToggleKey()) SolarClient.pendingToggle = true;
        if (mc.player == null || mc.currentScreen instanceof HudEditorScreen) return;
        if (GalaxySkyModule.I != null) GalaxySkyModule.I.renderFx(ctx, mc);
        if (PlayerGlowModule.I != null) PlayerGlowModule.I.renderFx(ctx, mc);
        for (HudModule m : ModuleManager.huds()) {
            if (m.isEnabled()) m.render(ctx, mc, false);
        }
        if (MaceImpactModule.I != null && MaceImpactModule.I.isEnabled()) MaceImpactModule.I.renderFx(ctx, mc);
    }

    public static void resetPositions() {
        for (HudModule m : ModuleManager.huds()) m.resetPosition();
    }

    private HudManager() { }
}
