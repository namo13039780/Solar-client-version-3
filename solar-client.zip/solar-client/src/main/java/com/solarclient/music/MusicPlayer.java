package com.solarclient.music;

import com.solarclient.SolarClient;
import com.solarclient.module.impl.MusicModule;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALCCapabilities;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.libc.LibCStdlib;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays mp3/ogg files through the game's OpenAL context.
 * Everything that touches OpenAL runs on one worker thread.
 */
public final class MusicPlayer {
    public enum State { IDLE, LOADING, PLAYING, PAUSED }

    public static final MusicPlayer I = new MusicPlayer();

    public final List<Track> tracks = new CopyOnWriteArrayList<>();
    public volatile int index = -1;
    public volatile State state = State.IDLE;
    public volatile String status = "";
    public volatile double position, duration;
    public volatile int underruns, bufferedSec;

    private static final class Decoded {
        final short[] pcm;
        final int channels, rate;
        final long frames;

        Decoded(short[] pcm, int channels, int rate) {
            this.pcm = pcm;
            this.channels = channels;
            this.rate = rate;
            this.frames = pcm.length / Math.max(1, channels);
        }
    }

    private final ConcurrentLinkedQueue<Runnable> cmds = new ConcurrentLinkedQueue<>();
    private final ExecutorService decodeExec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SolarMusic-decode");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });
    private final Random random = new Random();
    private Thread worker;

    // OpenAL state (worker thread only)
    private boolean alReady, alFailed;
    private long alContext;
    private int src;
    private final int[] bufs = new int[8];
    private final Map<Integer, Integer> bufFrames = new HashMap<>();
    private Decoded cur;
    private long cursor, baseFrame, playedFrames;
    private int loadToken;

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("solar_music");
    }

    public synchronized void start() {
        if (worker != null) return;
        worker = new Thread(this::run, "SolarMusic");
        worker.setDaemon(true);
        worker.setPriority(Thread.MAX_PRIORITY);
        worker.start();
        rescan();
    }

    // ---------------- public controls (any thread) ----------------
    public void rescan() { cmds.add(this::scan); }
    public void play(int i) { cmds.add(() -> doPlay(i)); }
    public void stop() { cmds.add(this::doStop); }
    public void next() { cmds.add(() -> doPlay(nextIndex(true))); }

    public void prev() {
        cmds.add(() -> {
            if (position > 3 && cur != null) restartAt(0);
            else if (!tracks.isEmpty()) doPlay(index <= 0 ? tracks.size() - 1 : index - 1);
        });
    }

    public void togglePause() {
        cmds.add(() -> {
            if (state == State.PLAYING && alReady) {
                AL10.alSourcePause(src);
                state = State.PAUSED;
            } else if (state == State.PAUSED && alReady) {
                AL10.alSourcePlay(src);
                state = State.PLAYING;
            } else if (!tracks.isEmpty()) {
                doPlay(index >= 0 && index < tracks.size() ? index : 0);
            }
        });
    }

    public void seekFraction(double f) {
        cmds.add(() -> {
            if (cur != null && alReady) restartAt((long) (Math.max(0, Math.min(0.999, f)) * cur.frames));
        });
    }

    public Track current() {
        int i = index;
        List<Track> l = tracks;
        return i >= 0 && i < l.size() ? l.get(i) : null;
    }

    public static String fmt(double sec) {
        int s = (int) Math.max(0, sec);
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    // ---------------- worker ----------------
    private void run() {
        while (true) {
            try {
                Runnable r;
                while ((r = cmds.poll()) != null) {
                    try {
                        r.run();
                    } catch (Throwable t) {
                        SolarClient.LOGGER.warn("Music command failed", t);
                    }
                }
                update();
                Thread.sleep(60);
            } catch (InterruptedException e) {
                return;
            } catch (Throwable t) {
                SolarClient.LOGGER.warn("Music loop error", t);
            }
        }
    }

    private boolean initAl() {
        if (alFailed) return false;
        try {
            long ctx = ALC10.alcGetCurrentContext();
            if (ctx == 0) return false; // game sound engine not ready yet
            if (alReady && ctx == alContext) return true;
            long dev = ALC10.alcGetContextsDevice(ctx);
            ALCCapabilities caps = ALC.createCapabilities(dev);
            AL.createCapabilities(caps);
            src = AL10.alGenSources();
            for (int i = 0; i < bufs.length; i++) bufs[i] = AL10.alGenBuffers();
            AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSource3f(src, AL10.AL_POSITION, 0f, 0f, 0f);
            alContext = ctx;
            alReady = true;
            return true;
        } catch (Throwable t) {
            alFailed = true;
            status = "Audio init failed";
            SolarClient.LOGGER.warn("OpenAL init failed", t);
            return false;
        }
    }

    private float volume() {
        return MusicModule.I == null ? 0.6f : (float) MusicModule.I.volume.get() / 100f;
    }

    /** Folders that are scanned for music (the extra ones are easy to reach with a phone file manager). */
    public static List<Path> dirs() {
        List<Path> l = new ArrayList<>();
        l.add(dir());
        l.add(Path.of("/storage/emulated/0/Music/solar_music"));
        l.add(Path.of("/storage/emulated/0/Download/solar_music"));
        return l;
    }

    private void scan() {
        List<Track> list = new ArrayList<>();
        for (Path d : dirs()) {
            try {
                Files.createDirectories(d);
            } catch (Exception ignored) { }
            try (var s = Files.list(d)) {
                s.filter(p -> {
                    String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".mp3") || n.endsWith(".ogg");
                }).sorted().forEach(p -> list.add(Track.ofFile(p)));
            } catch (Exception ignored) { }
            try {
                Path pl = d.resolve("playlist.txt");
                if (!Files.exists(pl)) continue;
                for (String line : Files.readAllLines(pl)) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    String title = null, url = line;
                    int bar = line.indexOf('|');
                    if (bar > 0) {
                        title = line.substring(0, bar).trim();
                        url = line.substring(bar + 1).trim();
                    }
                    String low = url.toLowerCase(Locale.ROOT);
                    if (low.contains("youtube.com") || low.contains("youtu.be")) {
                        status = "YouTube links are not supported";
                        continue;
                    }
                    if (low.startsWith("http")) list.add(Track.ofUrl(title, url));
                }
            } catch (Exception ignored) { }
        }
        tracks.clear();
        tracks.addAll(list);
        if (index >= tracks.size()) index = -1;
    }

    private int nextIndex(boolean manual) {
        int n = tracks.size();
        if (n == 0) return -1;
        if (MusicModule.I != null && MusicModule.I.shuffle.get() && n > 1) {
            int r;
            do { r = random.nextInt(n); } while (r == index);
            return r;
        }
        int i = index + 1;
        if (i >= n) {
            if (manual || (MusicModule.I == null || !MusicModule.I.repeat.is("Off"))) return 0;
            return -1;
        }
        return i;
    }

    private void doStop() {
        loadToken++;
        stopSource();
        cur = null;
        state = State.IDLE;
        position = 0;
        duration = 0;
    }

    private void doPlay(int i) {
        if (i < 0 || i >= tracks.size()) {
            doStop();
            return;
        }
        stopSource();
        cur = null;
        index = i;
        state = State.LOADING;
        status = "";
        underruns = 0;
        position = 0;
        duration = 0;
        final Track t = tracks.get(i);
        final int token = ++loadToken;
        decodeExec.submit(() -> {
            try {
                Path f = t.file != null ? t.file : download(t.url);
                Decoded d = decode(f);
                cmds.add(() -> { if (token == loadToken) startDecoded(d); });
            } catch (Throwable e) {
                String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                cmds.add(() -> {
                    if (token == loadToken) {
                        state = State.IDLE;
                        status = "Cannot play: " + msg;
                    }
                });
            }
        });
    }

    private void startDecoded(Decoded d) {
        if (!initAl()) {
            state = State.IDLE;
            if (status.isEmpty()) status = "Sound system not ready";
            return;
        }
        cur = d;
        duration = d.frames / (double) d.rate;
        state = State.PLAYING;
        restartAt(0);
    }

    private void stopSource() {
        if (!alReady) return;
        try {
            AL10.alSourceStop(src);
            int q = AL10.alGetSourcei(src, AL10.AL_BUFFERS_QUEUED);
            while (q-- > 0) AL10.alSourceUnqueueBuffers(src);
            AL10.alSourcei(src, AL10.AL_BUFFER, 0);
        } catch (Throwable ignored) { }
    }

    private void restartAt(long frame) {
        if (cur == null || !alReady) return;
        stopSource();
        bufFrames.clear();
        baseFrame = frame;
        playedFrames = 0;
        cursor = frame;
        for (int b : bufs) {
            if (!fill(b)) break;
            AL10.alSourceQueueBuffers(src, b);
        }
        AL10.alSourcef(src, AL10.AL_GAIN, volume());
        if (state != State.PAUSED) AL10.alSourcePlay(src);
    }

    private boolean fill(int b) {
        Decoded d = cur;
        if (d == null || cursor >= d.frames) return false;
        int n = (int) Math.min(d.rate, d.frames - cursor);
        ShortBuffer sb = MemoryUtil.memAllocShort(n * d.channels);
        try {
            sb.put(d.pcm, (int) (cursor * d.channels), n * d.channels).flip();
            AL10.alBufferData(b, d.channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, sb, d.rate);
        } finally {
            MemoryUtil.memFree(sb);
        }
        bufFrames.put(b, n);
        cursor += n;
        return true;
    }

    private void update() {
        if (cur == null || (state != State.PLAYING && state != State.PAUSED)) return;
        if (!alReady || ALC10.alcGetCurrentContext() != alContext) {
            alReady = false;
            if (!initAl()) return;
            restartAt(baseFrame + playedFrames);
            return;
        }
        int processed = AL10.alGetSourcei(src, AL10.AL_BUFFERS_PROCESSED);
        while (processed-- > 0) {
            int b = AL10.alSourceUnqueueBuffers(src);
            Integer fr = bufFrames.get(b);
            if (fr != null) playedFrames += fr;
            if (fill(b)) AL10.alSourceQueueBuffers(src, b);
        }
        AL10.alSourcef(src, AL10.AL_GAIN, volume());
        int queued = AL10.alGetSourcei(src, AL10.AL_BUFFERS_QUEUED);
        int st = AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE);
        position = (baseFrame + playedFrames + AL10.alGetSourcei(src, 0x1025)) / (double) cur.rate;
        bufferedSec = queued;
        if (state == State.PLAYING && st != AL10.AL_PLAYING) {
            if (queued > 0) {
                underruns++;
                AL10.alSourcePlay(src);
            } else {
                onTrackEnd();
            }
        }
    }

    private void onTrackEnd() {
        if (MusicModule.I != null && MusicModule.I.repeat.is("One")) {
            doPlay(index);
        } else {
            int n = nextIndex(false);
            if (n < 0) doStop(); else doPlay(n);
        }
    }

    // ---------------- decoding ----------------
    private static Path download(String url) throws IOException {
        Path cache = dir().resolve("cache");
        Files.createDirectories(cache);
        Path out = cache.resolve(Integer.toHexString(url.hashCode()) + ".bin");
        if (Files.exists(out) && Files.size(out) > 0) return out;
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "SolarClient/1.0");
        if (c.getResponseCode() / 100 != 2) throw new IOException("HTTP " + c.getResponseCode());
        Path tmp = cache.resolve(out.getFileName() + ".part");
        try (InputStream in = c.getInputStream()) {
            Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
        }
        Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        return out;
    }

    private static Decoded decode(Path f) throws Exception {
        byte[] head = new byte[4];
        try (InputStream in = Files.newInputStream(f)) {
            int ignored = in.read(head);
        }
        boolean ogg = head[0] == 'O' && head[1] == 'g' && head[2] == 'g' && head[3] == 'S';
        return ogg ? decodeOgg(f) : decodeMp3(f);
    }

    private static Decoded decodeOgg(Path f) throws IOException {
        byte[] data = Files.readAllBytes(f);
        ByteBuffer bb = MemoryUtil.memAlloc(data.length);
        try (MemoryStack st = MemoryStack.stackPush()) {
            bb.put(data).flip();
            IntBuffer ch = st.mallocInt(1), rate = st.mallocInt(1);
            ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(bb, ch, rate);
            if (pcm == null) throw new IOException("Bad ogg file");
            short[] arr = new short[pcm.remaining()];
            pcm.get(arr);
            LibCStdlib.free(pcm);
            return new Decoded(arr, Math.min(2, ch.get(0)), rate.get(0));
        } finally {
            MemoryUtil.memFree(bb);
        }
    }

    private static Decoded decodeMp3(Path f) throws Exception {
        short[] all = new short[1 << 20];
        int size = 0, ch = 2, rate = 44100;
        boolean first = true;
        int frameCount = 0;
        try (InputStream in = new BufferedInputStream(Files.newInputStream(f))) {
            javazoom.jl.decoder.Bitstream bs = new javazoom.jl.decoder.Bitstream(in);
            javazoom.jl.decoder.Decoder dec = new javazoom.jl.decoder.Decoder();
            javazoom.jl.decoder.Header h;
            while ((h = bs.readFrame()) != null) {
                javazoom.jl.decoder.SampleBuffer sb = (javazoom.jl.decoder.SampleBuffer) dec.decodeFrame(h, bs);
                if (first) {
                    ch = sb.getChannelCount();
                    rate = sb.getSampleFrequency();
                    first = false;
                }
                int len = sb.getBufferLength();
                if (size + len > all.length) all = java.util.Arrays.copyOf(all, Math.max(all.length * 2, size + len));
                System.arraycopy(sb.getBuffer(), 0, all, size, len);
                size += len;
                bs.closeFrame();
                if ((++frameCount & 15) == 0) Thread.sleep(3); // be gentle with the CPU
            }
            bs.close();
        }
        if (size == 0) throw new IOException("Empty or unsupported mp3");
        return new Decoded(java.util.Arrays.copyOf(all, size), Math.min(2, ch), rate);
    }

    private MusicPlayer() { }
}
