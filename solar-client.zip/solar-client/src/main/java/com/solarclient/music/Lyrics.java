package com.solarclient.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Time-synced lyrics (LRC, with optional word timing). Nothing is bundled; files come from the user or LRCLIB. */
public final class Lyrics {
    public static final class Word {
        public final double t;
        public final String s;

        Word(double t, String s) {
            this.t = t;
            this.s = s;
        }
    }

    public static final class Line {
        public final double t;
        public final List<Word> words = new ArrayList<>();
        public double end;
        public boolean spaced = true;

        Line(double t) {
            this.t = t;
        }
    }

    private static final class Raw {
        final double t;
        final String body;

        Raw(double t, String body) {
            this.t = t;
            this.body = body;
        }
    }

    private static final Pattern STAMP = Pattern.compile("^(\\d+):(\\d+(?:\\.\\d+)?)$");
    private static final Pattern WTAG = Pattern.compile("<(\\d+:\\d+(?:\\.\\d+)?)>");

    public final List<Line> lines;

    private Lyrics(List<Line> lines) {
        this.lines = lines;
    }

    public int indexAt(double t) {
        int r = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).t <= t) r = i; else break;
        }
        return r;
    }

    private static Double time(String tag) {
        Matcher m = STAMP.matcher(tag.trim());
        if (!m.matches()) return null;
        return Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2));
    }

    public static Lyrics parse(String text) {
        List<Raw> raws = new ArrayList<>();
        for (String rawLine : text.split("\\R")) {
            String line = rawLine.trim();
            if (line.isEmpty()) continue;
            List<Double> stamps = new ArrayList<>();
            int pos = 0;
            while (pos < line.length() && line.charAt(pos) == '[') {
                int close = line.indexOf(']', pos);
                if (close < 0) break;
                Double ts = time(line.substring(pos + 1, close));
                if (ts == null) break;
                stamps.add(ts);
                pos = close + 1;
            }
            if (stamps.isEmpty()) continue;
            String body = line.substring(pos).trim();
            for (double ts : stamps) raws.add(new Raw(ts, body));
        }
        raws.sort(Comparator.comparingDouble(r -> r.t));

        List<Line> out = new ArrayList<>();
        for (int i = 0; i < raws.size(); i++) {
            Raw r = raws.get(i);
            double next = i + 1 < raws.size() ? raws.get(i + 1).t : r.t + 6;
            Line L = new Line(r.t);
            Matcher m = WTAG.matcher(r.body);
            if (m.find()) {
                m.reset();
                int last = 0;
                double cur = r.t;
                while (m.find()) {
                    String seg = r.body.substring(last, m.start()).trim();
                    if (!seg.isEmpty()) L.words.add(new Word(cur, seg));
                    cur = time(m.group(1));
                    last = m.end();
                }
                String seg = r.body.substring(last).trim();
                if (!seg.isEmpty()) L.words.add(new Word(cur, seg));
                L.end = Math.min(next, cur + 1.5);
            } else {
                String clean = r.body.trim();
                List<String> toks = new ArrayList<>();
                if (!clean.isEmpty()) {
                    String[] parts = clean.split("\\s+");
                    if (parts.length == 1 && parts[0].codePointCount(0, parts[0].length()) > 8) {
                        toks = chunk(parts[0]);
                        L.spaced = false;
                    } else {
                        for (String p : parts) toks.add(p);
                    }
                }
                int total = 0;
                for (String s : toks) total += s.length();
                double d = Math.min(next - r.t, Math.max(1.4, total * 0.2));
                int cum = 0;
                for (String s : toks) {
                    L.words.add(new Word(r.t + d * 0.9 * cum / Math.max(1, total), s));
                    cum += s.length();
                }
                L.end = r.t + d;
            }
            out.add(L);
        }
        return new Lyrics(out);
    }

    private static boolean combining(int cp) {
        return cp == 0x0E31 || (cp >= 0x0E34 && cp <= 0x0E3A) || (cp >= 0x0E47 && cp <= 0x0E4E);
    }

    private static List<String> chunk(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int[] cps = s.codePoints().toArray();
        int n = 0;
        for (int i = 0; i < cps.length; i++) {
            sb.appendCodePoint(cps[i]);
            n++;
            boolean nextComb = i + 1 < cps.length && combining(cps[i + 1]);
            boolean leadVowel = cps[i] >= 0x0E40 && cps[i] <= 0x0E44;
            if (n >= 4 && !nextComb && !leadVowel) {
                out.add(sb.toString());
                sb.setLength(0);
                n = 0;
            }
        }
        if (sb.length() > 0) out.add(sb.toString());
        return out;
    }

    // ---------------- loading ----------------
    public static Lyrics loadFor(Track tr, boolean online) throws Exception {
        String base = tr.file != null ? stripExt(tr.file.getFileName().toString()) : tr.title;
        List<Path> cands = new ArrayList<>();
        if (tr.file != null) {
            cands.add(tr.file.resolveSibling(base + ".lrc"));
            cands.add(tr.file.resolveSibling("lyrics").resolve(base + ".lrc"));
        }
        for (Path d : MusicPlayer.dirs()) cands.add(d.resolve("lyrics").resolve(base + ".lrc"));
        for (Path p : cands) {
            try {
                if (Files.isRegularFile(p)) {
                    Lyrics l = parse(Files.readString(p));
                    if (!l.lines.isEmpty()) return l;
                }
            } catch (Exception ignored) { }
        }
        if (!online) return null;

        Path cache = MusicPlayer.dir().resolve("cache").resolve("lyrics");
        Files.createDirectories(cache);
        Path cf = cache.resolve(Integer.toHexString((tr.artist + "|" + tr.title).hashCode()) + ".lrc");
        if (Files.exists(cf)) {
            String s = Files.readString(cf);
            if (s.isEmpty()) return null;
            Lyrics l = parse(s);
            return l.lines.isEmpty() ? null : l;
        }
        String lrc = fetch(tr);
        Files.writeString(cf, lrc == null ? "" : lrc);
        if (lrc == null) return null;
        Lyrics l = parse(lrc);
        return l.lines.isEmpty() ? null : l;
    }

    private static String stripExt(String n) {
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static String fetch(Track tr) {
        String artist = "Online".equals(tr.artist) ? "" : tr.artist;
        String synced = null;
        if (!artist.isEmpty()) {
            String dur = tr.durationSec > 0 ? "&duration=" + Math.round(tr.durationSec) : "";
            synced = extract(http("https://lrclib.net/api/get?artist_name=" + enc(artist) + "&track_name=" + enc(tr.title) + dur));
        }
        if (synced == null) {
            synced = extract(http("https://lrclib.net/api/search?q=" + enc((artist + " " + tr.title).trim())));
        }
        return synced;
    }

    private static String extract(String json) {
        if (json == null) return null;
        try {
            JsonElement e = JsonParser.parseString(json);
            if (e.isJsonObject()) return synced(e.getAsJsonObject());
            if (e.isJsonArray()) {
                JsonArray a = e.getAsJsonArray();
                for (JsonElement x : a) {
                    if (x.isJsonObject()) {
                        String s = synced(x.getAsJsonObject());
                        if (s != null) return s;
                    }
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static String synced(JsonObject o) {
        JsonElement s = o.get("syncedLyrics");
        if (s != null && s.isJsonPrimitive() && !s.getAsString().isBlank()) return s.getAsString();
        return null;
    }

    private static String http(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "SolarClient/1.0 (Minecraft mod)");
            if (c.getResponseCode() != 200) return null;
            try (InputStream in = c.getInputStream()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        }
    }
}
