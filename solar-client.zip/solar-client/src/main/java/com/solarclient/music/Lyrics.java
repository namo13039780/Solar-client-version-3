package com.solarclient.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Time-synced lyrics (LRC, with optional word timing). Nothing is bundled; files come from the user or LRCLIB. */
public final class Lyrics {
    public static final class Word {
        public final double t;
        public final String s;

        Word(double t, String s) {
            this.t = t;
            this.s = s;
        }
    }

    public static final class Line {
        public final double t;
        public final List<Word> words = new ArrayList<>();
        public double end;
        public boolean spaced = true;

        Line(double t) {
            this.t = t;
        }
    }

    private static final class Raw {
        final double t;
        final String body;

        Raw(double t, String body) {
            this.t = t;
            this.body = body;
        }
    }

    private static final Pattern STAMP = Pattern.compile("^(\\d+):(\\d+(?:\\.\\d+)?)$");
    private static final Pattern WTAG = Pattern.compile("<(\\d+:\\d+(?:\\.\\d+)?)>");

    public final List<Line> lines;
    /** Original text when the lyrics had no timestamps (timing is estimated over the song length). */
    public final String rawUnsynced;

    private Lyrics(List<Line> lines) {
        this(lines, null);
    }

    private Lyrics(List<Line> lines, String raw) {
        this.lines = lines;
        this.rawUnsynced = raw;
    }

    public int indexAt(double t) {
        int r = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).t <= t) r = i; else break;
        }
        return r;
    }

    private static Double time(String tag) {
        Matcher m = STAMP.matcher(tag.trim());
        if (!m.matches()) return null;
        return Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2));
    }

    public static Lyrics parse(String text) {
        List<Raw> raws = new ArrayList<>();
        for (String rawLine : text.split("\\R")) {
            String line = rawLine.trim();
            if (line.isEmpty()) continue;
            List<Double> stamps = new ArrayList<>();
            int pos = 0;
            while (pos < line.length() && line.charAt(pos) == '[') {
                int close = line.indexOf(']', pos);
                if (close < 0) break;
                Double ts = time(line.substring(pos + 1, close));
                if (ts == null) break;
                stamps.add(ts);
                pos = close + 1;
            }
            if (stamps.isEmpty()) continue;
            String body = line.substring(pos).trim();
            for (double ts : stamps) raws.add(new Raw(ts, body));
        }
        raws.sort(Comparator.comparingDouble(r -> r.t));

        List<Line> out = new ArrayList<>();
        for (int i = 0; i < raws.size(); i++) {
            Raw r = raws.get(i);
            double next = i + 1 < raws.size() ? raws.get(i + 1).t : r.t + 6;
            Line L = new Line(r.t);
            Matcher m = WTAG.matcher(r.body);
            if (m.find()) {
                m.reset();
                int last = 0;
                double cur = r.t;
                while (m.find()) {
                    String seg = r.body.substring(last, m.start()).trim();
                    if (!seg.isEmpty()) L.words.add(new Word(cur, seg));
                    cur = time(m.group(1));
                    last = m.end();
                }
                String seg = r.body.substring(last).trim();
                if (!seg.isEmpty()) L.words.add(new Word(cur, seg));
                L.end = Math.min(next, cur + 1.5);
            } else {
                String clean = r.body.trim();
                List<String> toks = new ArrayList<>();
                if (!clean.isEmpty()) {
                    String[] parts = clean.split("\\s+");
                    if (parts.length == 1 && parts[0].codePointCount(0, parts[0].length()) > 8) {
                        toks = chunk(parts[0]);
                        L.spaced = false;
                    } else {
                        for (String p : parts) toks.add(p);
                    }
                }
                double totalW = 0;
                double[] ws = new double[toks.size()];
                for (int q = 0; q < ws.length; q++) {
                    ws[q] = weight(toks.get(q));
                    totalW += ws[q];
                }
                // slow song = long gap between lines = words spread out; fast song = short gap = words quick
                double d = Math.min((next - r.t) * 0.92, Math.max(1.4, totalW * 0.75));
                double cum = 0;
                for (int q = 0; q < ws.length; q++) {
                    L.words.add(new Word(r.t + d * cum / Math.max(0.01, totalW), toks.get(q)));
                    cum += ws[q];
                }
                L.end = r.t + d;
            }
            out.add(L);
        }
        return new Lyrics(out);
    }

    /** Rough "how long does this word take to sing": syllables for Latin text, length for other scripts, plus a pause after punctuation. */
    private static double weight(String s) {
        String low = s.toLowerCase(Locale.ROOT);
        boolean latin = false;
        for (int i = 0; i < low.length(); i++) {
            char c = low.charAt(i);
            if (c >= 'a' && c <= 'z') {
                latin = true;
                break;
            }
        }
        double w;
        if (latin) {
            int syl = 0;
            boolean prev = false;
            for (int i = 0; i < low.length(); i++) {
                boolean v = "aeiouy".indexOf(low.charAt(i)) >= 0;
                if (v && !prev) syl++;
                prev = v;
            }
            if (low.endsWith("e") && syl > 1 && !low.endsWith("le")) syl--;
            w = Math.max(1, syl);
        } else {
            w = Math.max(1, s.codePointCount(0, s.length()) / 2.5);
        }
        if (s.matches(".*[,.;:!?\u2026]$")) w += 0.7;
        return w;
    }

    /** Same lyrics with every time multiplied (for a sped-up / slowed version of the song). */
    public Lyrics scaled(double r) {
        List<Line> out = new ArrayList<>();
        for (Line L : lines) {
            Line n = new Line(L.t * r);
            n.end = L.end * r;
            n.spaced = L.spaced;
            for (Word w : L.words) n.words.add(new Word(w.t * r, w.s));
            out.add(n);
        }
        return new Lyrics(out, rawUnsynced);
    }

    private static boolean combining(int cp) {
        return cp == 0x0E31 || (cp >= 0x0E34 && cp <= 0x0E3A) || (cp >= 0x0E47 && cp <= 0x0E4E);
    }

    private static List<String> chunk(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int[] cps = s.codePoints().toArray();
        int n = 0;
        for (int i = 0; i < cps.length; i++) {
            sb.appendCodePoint(cps[i]);
            n++;
            boolean nextComb = i + 1 < cps.length && combining(cps[i + 1]);
            boolean leadVowel = cps[i] >= 0x0E40 && cps[i] <= 0x0E44;
            if (n >= 4 && !nextComb && !leadVowel) {
                out.add(sb.toString());
                sb.setLength(0);
                n = 0;
            }
        }
        if (sb.length() > 0) out.add(sb.toString());
        return out;
    }

    // ---------------- loading ----------------
    public static Lyrics loadFor(Track tr, boolean online) throws Exception {
        String base = tr.file != null ? stripExt(tr.file.getFileName().toString()) : tr.title;
        List<Path> cands = new ArrayList<>();
        if (tr.file != null) {
            cands.add(tr.file.resolveSibling(base + ".lrc"));
            cands.add(tr.file.resolveSibling("lyrics").resolve(base + ".lrc"));
        }
        for (Path d : MusicPlayer.dirs()) cands.add(d.resolve("lyrics").resolve(base + ".lrc"));
        for (Path p : cands) {
            Lyrics l = readFile(p, tr);
            if (l != null) return l;
        }
        Lyrics fz = fuzzy(tr, base);
        if (fz != null) return fz;
        if (!online) return null;

        Path cache = MusicPlayer.dir().resolve("cache").resolve("lyrics");
        Files.createDirectories(cache);
        Path cf = cache.resolve(Integer.toHexString((tr.artist + "|" + tr.title).hashCode()) + ".lrc");
        String lrc;
        double srcDur = 0;
        if (Files.exists(cf)) {
            lrc = Files.readString(cf);
            if (lrc.isEmpty()) return null;
            Matcher dm = Pattern.compile("^\\[x-dur:([0-9.]+)\\]").matcher(lrc);
            if (dm.find()) srcDur = Double.parseDouble(dm.group(1));
        } else {
            Fetched f = fetch(tr);
            if (f == null) {
                Files.writeString(cf, "");
                return null;
            }
            lrc = f.lrc;
            srcDur = f.dur;
            Files.writeString(cf, (srcDur > 0 ? "[x-dur:" + srcDur + "]\n" : "") + lrc);
        }
        Lyrics l = parse(lrc);
        if (l.lines.isEmpty()) return null;
        if (srcDur > 0 && tr.durationSec > 0) {
            double ratio = tr.durationSec / srcDur;
            if (Math.abs(ratio - 1) > 0.015 && ratio > 0.6 && ratio < 1.7) l = l.scaled(ratio);
        }
        return l;
    }

    // ---------------- lyrics without timestamps + loose file matching ----------------
    private static String stamp(double t) {
        return "[" + (int) (t / 60) + ":" + String.format(Locale.ROOT, "%05.2f", t % 60) + "]";
    }

    /** Plain lyrics (no [mm:ss] tags): spread the lines evenly over the song. */
    public static Lyrics unsynced(String text, double dur) {
        List<String> ls = new ArrayList<>();
        for (String raw : text.split("\\R")) {
            String t = raw.trim();
            if (t.isEmpty()) continue;
            if (t.matches("^\\[[A-Za-z]+:.*\\]$")) continue;   // [ar:..] [ti:..] metadata
            ls.add(t);
        }
        if (ls.isEmpty()) return new Lyrics(new ArrayList<>(), null);
        double d = dur > 0 ? dur : 200;
        double intro = Math.min(8, d * 0.05), usable = Math.max(10, d - intro - d * 0.05);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ls.size(); i++) sb.append(stamp(intro + usable * i / ls.size())).append(ls.get(i)).append('\n');
        return new Lyrics(parse(sb.toString()).lines, text);
    }

    /** Re-spread plain lyrics once the real song length is known. */
    public Lyrics retime(double dur) {
        return rawUnsynced == null || dur <= 0 ? this : unsynced(rawUnsynced, dur);
    }

    private static Lyrics readFile(Path p, Track tr) {
        try {
            if (!Files.isRegularFile(p)) return null;
            String text = Files.readString(p);
            Lyrics l = parse(text);
            if (l.lines.isEmpty()) l = unsynced(text, tr.durationSec);
            return l.lines.isEmpty() ? null : l;
        } catch (Exception e) {
            return null;
        }
    }

    private static String norm(String s) {
        StringBuilder sb = new StringBuilder();
        s.codePoints().forEach(cp -> {
            if (Character.isLetterOrDigit(cp)) sb.appendCodePoint(Character.toLowerCase(cp));
        });
        return sb.toString();
    }

    /** Finds a .lrc/.txt whose name looks like the song (any case, spaces, symbols ignored). */
    private static Lyrics fuzzy(Track tr, String base) {
        String nb = norm(base), nt = norm(tr.title);
        List<Path> dirs = new ArrayList<>();
        for (Path d : MusicPlayer.dirs()) {
            dirs.add(d);
            dirs.add(d.resolve("lyrics"));
        }
        for (Path d : dirs) {
            try (var st = Files.list(d)) {
                for (Path p : (Iterable<Path>) st::iterator) {
                    String n = p.getFileName().toString();
                    String low = n.toLowerCase(Locale.ROOT);
                    if (!low.endsWith(".lrc") && !low.endsWith(".txt")) continue;
                    String fb = norm(stripExt(n));
                    if (fb.length() < 2) continue;
                    boolean ok = fb.equals(nb) || (nt.length() >= 3 && fb.contains(nt)) || (fb.length() >= 3 && nb.contains(fb));
                    if (!ok) continue;
                    Lyrics l = readFile(p, tr);
                    if (l != null) return l;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String stripExt(String n) {
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static final class Fetched {
        final String lrc;
        final double dur;

        Fetched(String lrc, double dur) {
            this.lrc = lrc;
            this.dur = dur;
        }
    }

    private static Fetched fetch(Track tr) {
        String artist = "Online".equals(tr.artist) ? "" : tr.artist;
        Fetched f = null;
        if (!artist.isEmpty()) {
            String dur = tr.durationSec > 0 ? "&duration=" + Math.round(tr.durationSec) : "";
            f = extract(http("https://lrclib.net/api/get?artist_name=" + enc(artist) + "&track_name=" + enc(tr.title) + dur), tr.durationSec);
        }
        if (f == null) {
            f = extract(http("https://lrclib.net/api/search?q=" + enc((artist + " " + tr.title).trim())), tr.durationSec);
        }
        return f;
    }

    private static Fetched fromObj(JsonObject o) {
        String s = synced(o);
        if (s == null) return null;
        double d = o.has("duration") && o.get("duration").isJsonPrimitive() ? o.get("duration").getAsDouble() : 0;
        return new Fetched(s, d);
    }

    /** Picks the result whose length is closest to the song's real length. */
    private static Fetched extract(String json, double target) {
        if (json == null) return null;
        try {
            JsonElement e = JsonParser.parseString(json);
            if (e.isJsonObject()) return fromObj(e.getAsJsonObject());
            if (e.isJsonArray()) {
                Fetched best = null;
                double bestDiff = 1e9;
                for (JsonElement x : e.getAsJsonArray()) {
                    if (!x.isJsonObject()) continue;
                    Fetched f = fromObj(x.getAsJsonObject());
                    if (f == null) continue;
                    double diff = target > 0 && f.dur > 0 ? Math.abs(f.dur - target) : 0;
                    if (best == null || diff < bestDiff) {
                        best = f;
                        bestDiff = diff;
                    }
                }
                return best;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static String synced(JsonObject o) {
        JsonElement s = o.get("syncedLyrics");
        if (s != null && s.isJsonPrimitive() && !s.getAsString().isBlank()) return s.getAsString();
        return null;
    }

    private static String http(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "SolarClient/1.0 (Minecraft mod)");
            if (c.getResponseCode() != 200) return null;
            try (InputStream in = c.getInputStream()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        }
    }
}
