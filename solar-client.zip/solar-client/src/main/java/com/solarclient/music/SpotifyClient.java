package com.solarclient.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.solarclient.SolarClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Remote control + "now playing" for the Spotify app through the official Web API (PKCE login, no secret).
 * Audio keeps playing inside the Spotify app; this only reads state, controls it and fetches lyrics.
 * Control needs Spotify Premium and an active Spotify device (e.g. the Spotify app on this phone).
 */
public final class SpotifyClient {
    public static final SpotifyClient I = new SpotifyClient();
    private static final String REDIRECT = "http://127.0.0.1:8888/callback";
    private static final String SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing";

    public static final class Result {
        public final String name, artist, uri;

        Result(String name, String artist, String uri) {
            this.name = name;
            this.artist = artist;
            this.uri = uri;
        }
    }

    public volatile String status = "Not connected";
    public volatile boolean connected, playing;
    public volatile String title = "", artist = "", trackId = "", coverUrl = "";
    public volatile double duration, base;
    public volatile long stamp, lastPoll;
    public volatile Lyrics lyrics;
    public volatile String lyricsStatus = "";
    public final List<Result> results = new CopyOnWriteArrayList<>();

    private volatile String clientId = "", access = "", refresh = "";
    private volatile long expiresAt;
    private String verifier;
    private Thread poller;
    private volatile boolean loginRunning;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SolarSpotify-io");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("solarclient_spotify.json");
    }

    public String clientId() { return clientId; }
    public boolean hasClientId() { return !clientId.isEmpty(); }

    public boolean active() {
        return connected && !title.isEmpty() && System.currentTimeMillis() - lastPoll < 8000;
    }

    public double smoothPosition() {
        double p = base;
        if (playing) p += Math.min(3.0, (System.nanoTime() - stamp) / 1e9);
        return Math.min(p, duration > 0 ? duration : p);
    }

    public synchronized void start() {
        if (poller != null) return;
        try {
            if (Files.exists(file())) {
                JsonObject o = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
                if (o.has("clientId")) clientId = o.get("clientId").getAsString();
                if (o.has("refresh")) refresh = o.get("refresh").getAsString();
            }
        } catch (Exception ignored) { }
        if (!clientId.isEmpty() && !refresh.isEmpty()) {
            connected = true;
            status = "Connecting...";
        }
        poller = new Thread(this::pollLoop, "SolarSpotify-poll");
        poller.setDaemon(true);
        poller.setPriority(Thread.MIN_PRIORITY);
        poller.start();
    }

    private void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("clientId", clientId);
            o.addProperty("refresh", refresh);
            Files.createDirectories(file().getParent());
            Files.writeString(file(), o.toString());
        } catch (Exception ignored) { }
    }

    public void setClientId(String id) {
        clientId = id == null ? "" : id.trim();
        save();
        status = clientId.isEmpty() ? "Not connected" : "Client ID saved. Press Login.";
    }

    public void logout() {
        connected = false;
        playing = false;
        access = "";
        refresh = "";
        title = "";
        trackId = "";
        lyrics = null;
        save();
        status = "Logged out";
    }

    // ---------------- login (PKCE, local redirect) ----------------
    public void login(MinecraftClient mc) {
        if (clientId.isEmpty()) {
            status = "Enter your Client ID first";
            return;
        }
        if (loginRunning) {
            status = "Waiting for browser login...";
        }
        try {
            SecureRandom rnd = new SecureRandom();
            String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 64; i++) sb.append(chars.charAt(rnd.nextInt(chars.length())));
            verifier = sb.toString();
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
            String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
            String url = "https://accounts.spotify.com/authorize?client_id=" + enc(clientId)
                    + "&response_type=code&redirect_uri=" + enc(REDIRECT)
                    + "&scope=" + enc(SCOPES)
                    + "&code_challenge_method=S256&code_challenge=" + challenge;
            mc.execute(() -> mc.keyboard.setClipboard(url));
            status = "Login link copied! Paste it in your phone browser, then log in.";
            if (!loginRunning) {
                loginRunning = true;
                io.submit(this::waitForCallback);
            }
        } catch (Exception e) {
            status = "Login failed: " + e.getClass().getSimpleName();
        }
    }

    private void waitForCallback() {
        try (ServerSocket ss = new ServerSocket(8888, 1, InetAddress.getByName("127.0.0.1"))) {
            ss.setSoTimeout(300_000);
            try (Socket s = ss.accept()) {
                BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String req = r.readLine();
                String code = null;
                if (req != null) {
                    int q = req.indexOf("code=");
                    if (q > 0) {
                        int e = req.indexOf('&', q);
                        int sp = req.indexOf(' ', q);
                        int end = e > 0 ? Math.min(e, sp > 0 ? sp : e) : sp;
                        code = req.substring(q + 5, end > 0 ? end : req.length());
                    }
                }
                String body = code != null
                        ? "<html><body style='font-family:sans-serif;text-align:center;margin-top:20vh'><h2>Connected to Solar Client</h2><p>You can go back to Minecraft.</p></body></html>"
                        : "<html><body><h2>Login failed or cancelled</h2></body></html>";
                OutputStream out = s.getOutputStream();
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                out.write(b);
                out.flush();
                if (code == null) {
                    status = "Login cancelled";
                } else {
                    exchange(code);
                }
            }
        } catch (Exception e) {
            status = "Login timed out or port 8888 is busy";
        } finally {
            loginRunning = false;
        }
    }

    private void exchange(String code) throws Exception {
        String body = "grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT)
                + "&client_id=" + enc(clientId) + "&code_verifier=" + enc(verifier);
        JsonObject o = tokenRequest(body);
        if (o == null || !o.has("access_token")) {
            status = "Login failed (check Client ID and Redirect URI)";
            return;
        }
        applyToken(o);
        connected = true;
        save();
        status = "Connected";
    }

    private void applyToken(JsonObject o) {
        access = o.get("access_token").getAsString();
        expiresAt = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000L;
        if (o.has("refresh_token")) refresh = o.get("refresh_token").getAsString();
    }

    private JsonObject tokenRequest(String form) {
        try {
            HttpURLConnection c = (HttpURLConnection) URI.create("https://accounts.spotify.com/api/token").toURL().openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            try (OutputStream out = c.getOutputStream()) {
                out.write(form.getBytes(StandardCharsets.UTF_8));
            }
            InputStream in = c.getResponseCode() / 100 == 2 ? c.getInputStream() : c.getErrorStream();
            if (in == null) return null;
            return JsonParser.parseString(new String(in.readAllBytes(), StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean ensureToken() {
        if (!connected || clientId.isEmpty() || refresh.isEmpty()) return false;
        if (!access.isEmpty() && System.currentTimeMillis() < expiresAt - 30_000) return true;
        JsonObject o = tokenRequest("grant_type=refresh_token&refresh_token=" + enc(refresh) + "&client_id=" + enc(clientId));
        if (o != null && o.has("access_token")) {
            applyToken(o);
            save();
            return true;
        }
        if (o != null && o.has("error")) {
            connected = false;
            status = "Login expired. Press Login again.";
        }
        return false;
    }

    // ---------------- API ----------------
    private static final class Resp {
        final int code;
        final String body;

        Resp(int code, String body) {
            this.code = code;
            this.body = body;
        }
    }

    private Resp api(String method, String path, String json) {
        try {
            if (!ensureToken()) return new Resp(-1, "");
            HttpURLConnection c = (HttpURLConnection) URI.create("https://api.spotify.com" + path).toURL().openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("Authorization", "Bearer " + access);
            if (!method.equals("GET")) {
                c.setDoOutput(true);
                if (json != null) c.setRequestProperty("Content-Type", "application/json");
                try (OutputStream out = c.getOutputStream()) {
                    if (json != null) out.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }
            int code = c.getResponseCode();
            InputStream in = code / 100 == 2 ? c.getInputStream() : c.getErrorStream();
            String body = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
            return new Resp(code, body);
        } catch (Exception e) {
            return new Resp(-2, "");
        }
    }

    private void pollLoop() {
        while (true) {
            try {
                Thread.sleep(1300);
                if (!connected) continue;
                long t0 = System.nanoTime();
                Resp r = api("GET", "/v1/me/player", null);
                if (r.code == 200 && !r.body.isEmpty()) {
                    parseState(JsonParser.parseString(r.body).getAsJsonObject(), t0);
                    lastPoll = System.currentTimeMillis();
                    if (!status.startsWith("Connected")) status = "Connected";
                } else if (r.code == 204) {
                    playing = false;
                    lastPoll = System.currentTimeMillis();
                    status = "Connected - open Spotify and start a song";
                } else if (r.code == 429) {
                    Thread.sleep(4000);
                } else if (r.code == 401 || r.code == 403) {
                    status = "Spotify refused (Premium needed for control)";
                }
            } catch (InterruptedException e) {
                return;
            } catch (Throwable t) {
                SolarClient.LOGGER.warn("Spotify poll error", t);
            }
        }
    }

    private void parseState(JsonObject o, long t0) {
        JsonElement item = o.get("item");
        playing = o.has("is_playing") && o.get("is_playing").getAsBoolean();
        if (item == null || !item.isJsonObject()) return;
        JsonObject it = item.getAsJsonObject();
        String id = it.has("id") && !it.get("id").isJsonNull() ? it.get("id").getAsString() : "";
        long progress = o.has("progress_ms") && !o.get("progress_ms").isJsonNull() ? o.get("progress_ms").getAsLong() : 0;
        base = progress / 1000.0;
        stamp = t0 + (System.nanoTime() - t0) / 2; // progress was measured about half a round trip ago
        duration = it.has("duration_ms") ? it.get("duration_ms").getAsLong() / 1000.0 : 0;
        if (!id.equals(trackId)) {
            trackId = id;
            title = it.has("name") ? it.get("name").getAsString() : "";
            StringBuilder names = new StringBuilder();
            String first = "";
            if (it.has("artists") && it.get("artists").isJsonArray()) {
                JsonArray arr = it.getAsJsonArray("artists");
                for (JsonElement a : arr) {
                    String n = a.getAsJsonObject().get("name").getAsString();
                    if (first.isEmpty()) first = n;
                    if (names.length() > 0) names.append(", ");
                    names.append(n);
                }
            }
            artist = names.toString();
            String cu = "";
            try {
                JsonArray imgs = it.getAsJsonObject("album").getAsJsonArray("images");
                int bestW = Integer.MAX_VALUE;
                for (JsonElement im : imgs) {
                    JsonObject o2 = im.getAsJsonObject();
                    int wv = o2.has("width") && !o2.get("width").isJsonNull() ? o2.get("width").getAsInt() : 0;
                    if (wv >= 64 && wv < bestW) {
                        bestW = wv;
                        cu = o2.get("url").getAsString();
                    }
                }
                if (cu.isEmpty() && imgs.size() > 0) cu = imgs.get(imgs.size() - 1).getAsJsonObject().get("url").getAsString();
            } catch (Exception ignored) { }
            coverUrl = cu;
            lyrics = null;
            lyricsStatus = "loading";
            final String fTitle = title, fFirst = first, fId = id;
            final double fDur = duration;
            io.submit(() -> {
                Lyrics ly = null;
                try {
                    ly = Lyrics.loadFor(Track.ofMeta(fTitle, fFirst, fDur), true);
                } catch (Throwable ignored) { }
                if (fId.equals(trackId)) {
                    lyrics = ly;
                    lyricsStatus = ly == null ? "none" : ly.lines.size() + " lines";
                }
            });
        }
    }

    private void quickPoll() {
        io.submit(() -> {
            try {
                Thread.sleep(350);
                long t0 = System.nanoTime();
                Resp r = api("GET", "/v1/me/player", null);
                if (r.code == 200 && !r.body.isEmpty()) {
                    parseState(JsonParser.parseString(r.body).getAsJsonObject(), t0);
                    lastPoll = System.currentTimeMillis();
                }
            } catch (Throwable ignored) { }
        });
    }

    private void control(String method, String path, String json) {
        io.submit(() -> {
            Resp r = api(method, path, json);
            if (r.code == 404) status = "No active device: open the Spotify app and play something once";
            else if (r.code == 403) status = "Spotify Premium is needed to control playback";
            else if (r.code / 100 == 2) status = "Connected";
            quickPoll();
        });
    }

    public void togglePlay() { control("PUT", playing ? "/v1/me/player/pause" : "/v1/me/player/play", null); }
    public void next() { control("POST", "/v1/me/player/next", null); }
    public void prev() { control("POST", "/v1/me/player/previous", null); }
    public void seek(double sec) { control("PUT", "/v1/me/player/seek?position_ms=" + (long) (sec * 1000), null); }
    public void volume(int pct) { control("PUT", "/v1/me/player/volume?volume_percent=" + Math.max(0, Math.min(100, pct)), null); }
    public void playUri(String uri) { control("PUT", "/v1/me/player/play", "{\"uris\":[\"" + uri + "\"]}"); }

    public void search(String q) {
        if (q == null || q.isBlank()) return;
        io.submit(() -> {
            Resp r = api("GET", "/v1/search?type=track&limit=12&q=" + enc(q.trim()), null);
            results.clear();
            if (r.code != 200) {
                status = "Search failed (" + r.code + ")";
                return;
            }
            try {
                JsonArray items = JsonParser.parseString(r.body).getAsJsonObject().getAsJsonObject("tracks").getAsJsonArray("items");
                for (JsonElement e : items) {
                    JsonObject t = e.getAsJsonObject();
                    String artistName = t.getAsJsonArray("artists").size() > 0
                            ? t.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString() : "";
                    results.add(new Result(t.get("name").getAsString(), artistName, t.get("uri").getAsString()));
                }
                if (results.isEmpty()) status = "No songs found";
            } catch (Exception ex) {
                status = "Search failed";
            }
        });
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private SpotifyClient() { }
}
