package com.solarclient.music;

import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Album cover as a small pixel picture (N x N). Key = http(s) link (Spotify) or "file:<path of the song>"
 * (looks for cover.jpg / song-name.jpg next to the song, then the picture embedded in the mp3).
 */
public final class CoverArt {
    public static final int N = 32;

    private static final Map<String, int[]> CACHE = new ConcurrentHashMap<>();
    private static final Set<String> LOADING = ConcurrentHashMap.newKeySet();
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SolarCover");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });

    /** Returns the pixels (N*N ARGB) or null if there is none (yet). Loading happens in the background. */
    public static int[] get(String key) {
        if (key == null || key.isEmpty()) return null;
        int[] c = CACHE.get(key);
        if (c != null) return c.length == 0 ? null : c;
        if (LOADING.add(key)) {
            IO.submit(() -> {
                int[] r = new int[0];
                try {
                    byte[] data = key.startsWith("file:") ? localBytes(key.substring(5)) : download(key);
                    int[] px = data == null ? null : decode(data);
                    if (px != null) r = px;
                } catch (Throwable ignored) { }
                CACHE.put(key, r);
                LOADING.remove(key);
            });
        }
        return null;
    }

    private static byte[] download(String url) throws Exception {
        Path cache = FabricLoader.getInstance().getGameDir().resolve("solar_music").resolve("cache");
        Files.createDirectories(cache);
        Path f = cache.resolve("cover_" + Integer.toHexString(url.hashCode()) + ".img");
        if (Files.exists(f) && Files.size(f) > 0) return Files.readAllBytes(f);
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "SolarClient/1.0");
        if (c.getResponseCode() / 100 != 2) return null;
        byte[] data;
        try (InputStream in = c.getInputStream()) {
            data = in.readAllBytes();
        }
        Files.write(f, data);
        return data;
    }

    private static byte[] localBytes(String path) throws Exception {
        Path song = Path.of(path);
        Path dir = song.getParent();
        String n = song.getFileName().toString();
        int dot = n.lastIndexOf('.');
        String base = dot > 0 ? n.substring(0, dot) : n;
        if (dir != null) {
            for (String ext : new String[]{".png", ".jpg", ".jpeg"}) {
                for (String nm : new String[]{base, "cover", "folder", "album"}) {
                    Path p = dir.resolve(nm + ext);
                    if (Files.isRegularFile(p)) return Files.readAllBytes(p);
                }
            }
        }
        return id3Picture(song);
    }

    // ---- picture embedded in an mp3 (ID3v2.3 / v2.4 "APIC" frame) ----
    private static int synchsafe(byte[] b, int o) {
        return ((b[o] & 0x7F) << 21) | ((b[o + 1] & 0x7F) << 14) | ((b[o + 2] & 0x7F) << 7) | (b[o + 3] & 0x7F);
    }

    private static int be32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    private static byte[] id3Picture(Path mp3) throws Exception {
        try (InputStream in = Files.newInputStream(mp3)) {
            byte[] h = in.readNBytes(10);
            if (h.length < 10 || h[0] != 'I' || h[1] != 'D' || h[2] != '3') return null;
            int ver = h[3];
            if (ver < 3) return null;
            int size = Math.min(synchsafe(h, 6), 12_000_000);
            byte[] tag = in.readNBytes(size);
            int pos = 0;
            if ((h[5] & 0x40) != 0 && tag.length > 6) pos += ver == 4 ? synchsafe(tag, 0) : be32(tag, 0) + 4;
            while (pos + 10 <= tag.length) {
                String id = new String(tag, pos, 4, StandardCharsets.ISO_8859_1);
                if (id.charAt(0) == 0) break;
                int fsz = ver == 4 ? synchsafe(tag, pos + 4) : be32(tag, pos + 4);
                int start = pos + 10;
                if (fsz <= 0 || start + fsz > tag.length) break;
                if (id.equals("APIC")) {
                    int end = start + fsz, p = start;
                    int enc = tag[p++];
                    while (p < end && tag[p] != 0) p++;   // MIME type
                    p += 2;                                // its terminator + picture type
                    if (enc == 0 || enc == 3) {
                        while (p < end && tag[p] != 0) p++;
                        p++;
                    } else {
                        while (p + 1 < end && !(tag[p] == 0 && tag[p + 1] == 0)) p += 2;
                        p += 2;
                    }
                    return p >= end ? null : Arrays.copyOfRange(tag, p, end);
                }
                pos = start + fsz;
            }
        }
        return null;
    }

    /** Decodes any png/jpg, crops to a centred square and shrinks it to N x N by averaging. */
    private static int[] decode(byte[] data) {
        ByteBuffer buf = MemoryUtil.memAlloc(data.length);
        try (MemoryStack st = MemoryStack.stackPush()) {
            buf.put(data).flip();
            IntBuffer w = st.mallocInt(1), h = st.mallocInt(1), c = st.mallocInt(1);
            ByteBuffer img = STBImage.stbi_load_from_memory(buf, w, h, c, 4);
            if (img == null) return null;
            int iw = w.get(0), ih = h.get(0), side = Math.min(iw, ih), ox = (iw - side) / 2, oy = (ih - side) / 2;
            int[] out = new int[N * N];
            for (int ty = 0; ty < N; ty++) {
                for (int tx = 0; tx < N; tx++) {
                    int x0 = ox + tx * side / N, x1 = Math.max(x0 + 1, ox + (tx + 1) * side / N);
                    int y0 = oy + ty * side / N, y1 = Math.max(y0 + 1, oy + (ty + 1) * side / N);
                    int sx = Math.max(1, (x1 - x0) / 4), sy = Math.max(1, (y1 - y0) / 4);
                    long r = 0, g = 0, b = 0;
                    int n = 0;
                    for (int yy = y0; yy < y1; yy += sy) {
                        for (int xx = x0; xx < x1; xx += sx) {
                            int i = (yy * iw + xx) * 4;
                            r += img.get(i) & 0xFF;
                            g += img.get(i + 1) & 0xFF;
                            b += img.get(i + 2) & 0xFF;
                            n++;
                        }
                    }
                    out[ty * N + tx] = 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
                }
            }
            STBImage.stbi_image_free(img);
            return out;
        } finally {
            MemoryUtil.memFree(buf);
        }
    }

    private CoverArt() { }
}
