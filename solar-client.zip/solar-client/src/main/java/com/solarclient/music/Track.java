package com.solarclient.music;

import java.nio.file.Path;

public final class Track {
    public final String title, artist, url;
    public final Path file;

    private Track(String title, String artist, Path file, String url) {
        this.title = title;
        this.artist = artist;
        this.file = file;
        this.url = url;
    }

    public static Track ofFile(Path p) {
        String n = p.getFileName().toString();
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        String artist = "", title = n;
        int i = n.indexOf(" - ");
        if (i > 0) {
            artist = n.substring(0, i).trim();
            title = n.substring(i + 3).trim();
        }
        return new Track(title, artist, p, null);
    }

    public static Track ofUrl(String title, String url) {
        String t = title;
        if (t == null || t.isEmpty()) {
            t = url;
            int q = t.indexOf('?');
            if (q > 0) t = t.substring(0, q);
            int s = t.lastIndexOf('/');
            if (s >= 0 && s < t.length() - 1) t = t.substring(s + 1);
        }
        return new Track(t, "Online", null, url);
    }

    public String display() {
        return artist.isEmpty() ? title : artist + " - " + title;
    }
}
