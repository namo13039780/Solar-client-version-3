package com.solarclient.mixin;

import com.solarclient.gui.ClickGuiScreen;
import com.solarclient.gui.HudEditorScreen;
import com.solarclient.gui.SolarTitleScreen;
import com.solarclient.util.SpaceBackground;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void solar$background(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        Screen self = (Screen) (Object) this;
        if (self instanceof SolarTitleScreen || self instanceof ClickGuiScreen || self instanceof HudEditorScreen) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        // menus outside a world (singleplayer list, multiplayer, options...) and the ESC pause menu
        if (mc.world == null || self instanceof GameMenuScreen) {
            SpaceBackground.draw(context, self.width, self.height, 0.35f);
            ci.cancel();
        }
    }
}
