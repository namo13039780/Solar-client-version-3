package com.solarclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.solarclient.SolarClient;
import com.solarclient.module.Module;
import com.solarclient.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("solarclient.json");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (Module m : ModuleManager.all()) {
                JsonElement e = root.get(m.name);
                if (e != null && e.isJsonObject()) {
                    try {
                        m.load(e.getAsJsonObject());
                    } catch (Exception ex) {
                        SolarClient.LOGGER.warn("Bad config for {}", m.name);
                    }
                }
            }
        } catch (Exception ex) {
            SolarClient.LOGGER.warn("Could not read config", ex);
        }
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.all()) root.add(m.name, m.save());
            Path f = file();
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f)) {
                GSON.toJson(root, w);
            }
        } catch (Exception ex) {
            SolarClient.LOGGER.warn("Could not save config", ex);
        }
    }
}
