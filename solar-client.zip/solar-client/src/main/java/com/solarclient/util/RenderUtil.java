package com.solarclient.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class RenderUtil {
    public static final int SKY = 0xFF38BDF8;
    public static final int SKY_LIGHT = 0xFF7DD3FC;
    public static final int NAVY = 0xFF0F2A66;

    public interface Gradient {
        int at(float t);
    }

    private static final String[] HEART = {" XX XX ", "XXXXXXX", "XXXXXXX", " XXXXX ", "  XXX  ", "   X   "};

    public static int withAlpha(int color, float alpha) {
        float al = Math.max(0f, Math.min(1f, alpha));
        int a = (int) (((color >>> 24) & 0xFF) * al);
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 0xFF) * (1 - t) + ((c2 >>> 24) & 0xFF) * t);
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Sky blue -> deep blue/black sweep that slowly moves with time. */
    public static int skyGradient(float t, double time) {
        float u = (float) (0.5 + 0.5 * Math.sin(Math.PI * 2 * (t * 0.8 - time * 0.22)));
        return u < 0.5f ? lerp(SKY_LIGHT, SKY, u * 2f) : lerp(SKY, NAVY, (u - 0.5f) * 2f);
    }

    public static void rrect(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        int w = x2 - x1, h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x1, y1, x2, y2, color);
            return;
        }
        c.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color);
        c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
        c.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    public static void circle(DrawContext c, double cx, double cy, double r, int color) {
        int icx = (int) Math.round(cx), icy = (int) Math.round(cy);
        int ir = (int) Math.ceil(r);
        for (int dy = -ir; dy <= ir; dy++) {
            double d = r * r - dy * dy;
            if (d < 0) continue;
            int half = (int) Math.round(Math.sqrt(d));
            c.fill(icx - half, icy + dy, icx + half + 1, icy + dy + 1, color);
        }
    }

    public static void gradientText(DrawContext c, TextRenderer tr, String s, float x, float y, float scale,
                                    boolean shadow, Gradient g) {
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        int cx = 0;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            String ch = String.valueOf(s.charAt(i));
            c.drawText(tr, ch, cx, 0, g.at(n <= 1 ? 0f : (float) i / (n - 1)), shadow);
            cx += tr.getWidth(ch);
        }
        m.popMatrix();
    }

    public static void heart(DrawContext c, int x, int y, float fill, int on, int off) {
        int cut = Math.round(7 * fill);
        for (int r = 0; r < 6; r++) {
            for (int col = 0; col < 7; col++) {
                if (HEART[r].charAt(col) == 'X') c.fill(x + col, y + r, x + col + 1, y + r + 1, col < cut ? on : off);
            }
        }
    }

    private RenderUtil() { }
}
