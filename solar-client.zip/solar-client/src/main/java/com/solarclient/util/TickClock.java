package com.solarclient.util;

/** Lets overlay code interpolate between client ticks without touching version-specific tick APIs. */
public final class TickClock {
    private static long lastTick = System.nanoTime();

    public static void mark() { lastTick = System.nanoTime(); }

    public static float progress() {
        return Math.max(0f, Math.min(1f, (System.nanoTime() - lastTick) / 50_000_000f));
    }

    private TickClock() { }
}
