package com.solarclient.util;

import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Twinkling, slowly drifting white stars. Time based, so it stays smooth at any FPS. */
public final class StarField {
    private final int n;
    private final float[] x, y, phase, speed, layer;

    public StarField(int n, long seed) {
        this.n = n;
        x = new float[n];
        y = new float[n];
        phase = new float[n];
        speed = new float[n];
        layer = new float[n];
        Random r = new Random(seed);
        for (int i = 0; i < n; i++) {
            x[i] = r.nextFloat();
            y[i] = r.nextFloat();
            phase[i] = r.nextFloat() * 6.28f;
            speed[i] = 0.8f + r.nextFloat() * 2.2f;
            layer[i] = r.nextFloat();
        }
    }

    public void render(DrawContext c, int w, int h, double t, float alpha) {
        for (int i = 0; i < n; i++) {
            float lx = (float) ((x[i] + t * 0.0025 * (0.4 + layer[i])) % 1.0);
            int px = (int) (lx * w);
            int py = (int) (y[i] * h);
            float tw = 0.55f + 0.45f * (float) Math.sin(t * speed[i] + phase[i]);
            int size = layer[i] > 0.8f ? 2 : 1;
            float a = tw * alpha * (0.45f + 0.55f * layer[i]);
            int col = RenderUtil.withAlpha(0xFFFFFFFF, a);
            c.fill(px, py, px + size, py + size, col);
            if (layer[i] > 0.96f) {
                int g = RenderUtil.withAlpha(0xFFFFFFFF, a * 0.45f);
                c.fill(px - 2, py, px, py + size, g);
                c.fill(px + size, py, px + size + 2, py + size, g);
                c.fill(px, py - 2, px + size, py, g);
                c.fill(px, py + size, px + size, py + size + 2, g);
            }
        }
    }
}
