package com.solarclient.util;

import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Bright, crisp twinkling stars that drift slowly. Time based, so it stays smooth at any FPS. */
public final class StarField {
    private static final int[] TINTS = {0xFFFFFFFF, 0xFFFFFFFF, 0xFFCFE8FF, 0xFFFFEBCB};
    private final int n;
    private final float[] x, y, phase, speed, layer;
    private final int[] tint;

    public StarField(int n, long seed) {
        this.n = n;
        x = new float[n];
        y = new float[n];
        phase = new float[n];
        speed = new float[n];
        layer = new float[n];
        tint = new int[n];
        Random r = new Random(seed);
        for (int i = 0; i < n; i++) {
            x[i] = r.nextFloat();
            y[i] = r.nextFloat();
            phase[i] = r.nextFloat() * 6.28f;
            speed[i] = 0.8f + r.nextFloat() * 2.0f;
            layer[i] = r.nextFloat();
            tint[i] = TINTS[r.nextInt(TINTS.length)];
        }
    }

    public void render(DrawContext c, int w, int h, double t, float alpha) {
        for (int i = 0; i < n; i++) {
            float lx = (float) ((x[i] + t * 0.0025 * (0.4 + layer[i])) % 1.0);
            int px = (int) (lx * w);
            int py = (int) (y[i] * h);
            float tw = 0.78f + 0.22f * (float) Math.sin(t * speed[i] + phase[i]);
            float l = layer[i];
            int size = l > 0.85f ? 3 : (l > 0.45f ? 2 : 1);
            float a = Math.min(1f, tw * alpha * (0.70f + 0.30f * l));
            int col = RenderUtil.withAlpha(tint[i], a);
            c.fill(px, py, px + size, py + size, col);
            if (l > 0.85f) {
                // soft halo + cross glint for the brightest stars
                int halo = RenderUtil.withAlpha(tint[i], a * 0.22f);
                c.fill(px - 1, py - 1, px + size + 1, py + size + 1, halo);
                int g = RenderUtil.withAlpha(tint[i], a * 0.6f);
                int len = l > 0.95f ? 4 : 2;
                c.fill(px - len, py + size / 2, px, py + size / 2 + 1, g);
                c.fill(px + size, py + size / 2, px + size + len, py + size / 2 + 1, g);
                c.fill(px + size / 2, py - len, px + size / 2 + 1, py, g);
                c.fill(px + size / 2, py + size, px + size / 2 + 1, py + size + len, g);
            }
        }
    }
}
