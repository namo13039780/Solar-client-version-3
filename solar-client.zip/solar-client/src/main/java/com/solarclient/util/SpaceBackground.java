package com.solarclient.util;

import net.minecraft.client.gui.DrawContext;

/** Shared black space background (stars + solar system) for every menu screen. */
public final class SpaceBackground {
    private static final StarField STARS = new StarField(340, 99L);
    private static final long START = System.nanoTime();

    public static void draw(DrawContext c, int w, int h, float dim) {
        double t = (System.nanoTime() - START) / 1e9;
        c.fill(0, 0, w, h, 0xFF000000);
        STARS.render(c, w, h, t, 1f);
        int R = (int) Math.min(w * 0.36f, h * 0.95f);
        SolarSystemRenderer.render(c, (int) (w * 0.66f), (int) (h * 0.52f), R, t);
        if (dim > 0f) c.fill(0, 0, w, h, RenderUtil.withAlpha(0xFF000000, dim));
    }

    private SpaceBackground() { }
}
