package com.solarclient.util;

import net.minecraft.client.gui.DrawContext;

/** Animated tilted solar system, driven purely by wall-clock time. */
public final class SolarSystemRenderer {
    private static final float[] ORBIT = {0.15f, 0.22f, 0.30f, 0.38f, 0.52f, 0.65f, 0.77f, 0.88f};
    private static final float[] SIZE = {2.0f, 3.2f, 3.5f, 2.6f, 7.0f, 6.0f, 4.5f, 4.5f};
    private static final double[] PERIOD = {7, 12, 18, 26, 55, 80, 120, 160};
    private static final int[] COLOR = {
            0xFFB5B5B5, 0xFFE8C07A, 0xFF3B82F6, 0xFFE2603B,
            0xFFD9A066, 0xFFE9D8A6, 0xFF7DE3F4, 0xFF3B5BDB};

    public static void render(DrawContext c, int cx, int cy, int R, double t) {
        double tilt = -0.32;
        double ct = Math.cos(tilt), st = Math.sin(tilt);
        float sf = Math.max(0.7f, Math.min(1.8f, R / 300f));
        double sunR = Math.max(12.0, R * 0.075) * (1.0 + 0.025 * Math.sin(t * 1.7));

        // orbit rings (dotted)
        for (int i = 0; i < 8; i++) {
            double a = ORBIT[i] * R, b = a * 0.30;
            int pts = (int) Math.max(90, a * 1.1);
            for (int k = 0; k < pts; k++) {
                double th = k * 2 * Math.PI / pts;
                double ex = a * Math.cos(th), ey = b * Math.sin(th);
                int px = (int) Math.round(cx + ex * ct - ey * st);
                int py = (int) Math.round(cy + ex * st + ey * ct);
                c.fill(px, py, px + 1, py + 1, 0x26FFFFFF);
            }
        }

        double[] px = new double[8], py = new double[8];
        boolean[] near = new boolean[8];
        for (int i = 0; i < 8; i++) {
            double a = ORBIT[i] * R, b = a * 0.30;
            double th = t * 2 * Math.PI / PERIOD[i] + i * 0.9;
            double ex = a * Math.cos(th), ey = b * Math.sin(th);
            px[i] = cx + ex * ct - ey * st;
            py[i] = cy + ex * st + ey * ct;
            near[i] = Math.sin(th) > 0;
        }

        for (int i = 0; i < 8; i++) if (!near[i]) planet(c, i, px[i], py[i], cx, cy, sf, t);

        // sun glow + core
        for (int i = 0; i < 7; i++) {
            RenderUtil.circle(c, cx, cy, sunR * (1.0 + 0.42 * (7 - i)), 0x0CFFA726);
        }
        RenderUtil.circle(c, cx, cy, sunR, 0xFFFF9800);
        RenderUtil.circle(c, cx, cy, sunR * 0.86, 0xFFFFB300);
        RenderUtil.circle(c, cx, cy, sunR * 0.62, 0xFFFFD54F);
        RenderUtil.circle(c, cx, cy, sunR * 0.35, 0xFFFFF3B0);

        for (int i = 0; i < 8; i++) if (near[i]) planet(c, i, px[i], py[i], cx, cy, sf, t);
    }

    private static void ring(DrawContext c, double px, double py, double r, boolean back) {
        for (int k = 0; k < 72; k++) {
            double ang = k * 2 * Math.PI / 72;
            boolean isBack = Math.sin(ang) < 0;
            if (isBack != back) continue;
            for (int layer = 0; layer < 2; layer++) {
                double rr = layer == 0 ? 2.0 : 1.7;
                int x = (int) Math.round(px + Math.cos(ang) * r * rr);
                int y = (int) Math.round(py + Math.sin(ang) * r * rr * 0.32);
                c.fill(x, y, x + 1, y + 1, layer == 0 ? 0xCCE9D8A6 : 0x99B8A675);
            }
        }
    }

    private static void planet(DrawContext c, int i, double px, double py, double sx, double sy, float sf, double t) {
        double r = SIZE[i] * sf;
        if (i == 5) ring(c, px, py, r, true);
        int base = COLOR[i];
        RenderUtil.circle(c, px, py, r, RenderUtil.lerp(base, 0xFF000000, 0.55f));
        double dx = sx - px, dy = sy - py;
        double len = Math.max(1e-6, Math.hypot(dx, dy));
        RenderUtil.circle(c, px + dx / len * r * 0.22, py + dy / len * r * 0.22, r * 0.86, base);
        if (i == 5) ring(c, px, py, r, false);
        if (i == 2) {
            double th = t * 2 * Math.PI / 3.0;
            int mx = (int) Math.round(px + Math.cos(th) * (r + 5 * sf));
            int my = (int) Math.round(py + Math.sin(th) * (r + 5 * sf) * 0.5);
            c.fill(mx, my, mx + 1, my + 1, 0xFFDDDDDD);
        }
    }

    private SolarSystemRenderer() { }
}
