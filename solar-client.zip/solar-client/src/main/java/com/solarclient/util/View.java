package com.solarclient.util;

import net.minecraft.client.MinecraftClient;

/** Simple camera basis + perspective projection for 2D overlays (first person). */
public final class View {
    public double fx, fy, fz, rx, ry, rz, ux, uy, uz, f, aspect;

    public static View of(MinecraftClient mc, float tp, int sw, int sh) {
        View v = new View();
        double yaw = Math.toRadians(mc.player.getYaw(tp)), pitch = Math.toRadians(mc.player.getPitch(tp));
        double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        v.fx = -sy * cp;
        v.fy = -sp;
        v.fz = cy * cp;
        v.rx = -cy;
        v.ry = 0;
        v.rz = -sy;
        v.ux = v.ry * v.fz - v.rz * v.fy;
        v.uy = v.rz * v.fx - v.rx * v.fz;
        v.uz = v.rx * v.fy - v.ry * v.fx;
        double fov = mc.options.getFov().getValue();
        if (mc.player.isSprinting()) fov *= 1.1;
        v.f = 1.0 / Math.tan(Math.toRadians(fov) / 2.0);
        v.aspect = sw / (double) sh;
        return v;
    }

    /** Projects a camera-relative world vector. Returns {screenX, screenY, depth} or null if behind the camera. */
    public double[] project(double dx, double dy, double dz, int sw, int sh) {
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.2) return null;
        double xc = dx * rx + dy * ry + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double nx = xc / zc * f / aspect, ny = yc / zc * f;
        return new double[]{sw / 2.0 * (1 + nx), sh / 2.0 * (1 - ny), zc};
    }

    private View() { }
}
