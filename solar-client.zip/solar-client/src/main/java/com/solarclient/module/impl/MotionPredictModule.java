package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Motion predictor for TESTING: draws an arrow showing where a player / mob is about to go.
 * Restricted to singleplayer or to operators (the server only sends op commands to operators), so it cannot be
 * used as a PvP advantage on servers where you are a normal player.
 */
public class MotionPredictModule extends Module {
    public static MotionPredictModule I;

    private final ModeSetting targets = add(new ModeSetting("Targets", "Players + Mobs", "Players", "Players + Mobs"));
    private final NumberSetting horizon = add(new NumberSetting("Arrow Length (ticks)", 20, 6, 40, 2));
    private final NumberSetting maxDist = add(new NumberSetting("Max Distance", 40, 8, 80, 4));
    private final NumberSetting arrowSize = add(new NumberSetting("Arrow Size", 100, 50, 200, 10));
    private final ModeSetting color = add(new ModeSetting("Color", "Threat", "Threat", "Sky", "White", "Pink", "Rainbow"));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 100, 20, 100, 5));
    private final BoolSetting labels = add(new BoolSetting("Show Labels", true));
    private final BoolSetting chevrons = add(new BoolSetting("Moving Chevrons", true));

    private static final class Track {
        final ArrayDeque<Vec3d> hist = new ArrayDeque<>();
        double groundY;
    }

    private final Map<UUID, Track> tracks = new HashMap<>();
    private boolean allowed, warned;
    private long lastCheck;

    public MotionPredictModule() {
        super("Motion Predictor", "Arrow showing where players/mobs will move (singleplayer or operators only)", Category.PVP, false);
        I = this;
    }

    @Override
    protected void onDisable() {
        tracks.clear();
        warned = false;
    }

    private boolean allowedNow(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        if (now - lastCheck < 1000) return allowed;
        lastCheck = now;
        boolean ok = false;
        try {
            if (mc.isInSingleplayer()) {
                ok = true;
            } else if (mc.getNetworkHandler() != null) {
                var root = mc.getNetworkHandler().getCommandDispatcher().getRoot();
                ok = root.getChild("gamemode") != null || root.getChild("op") != null;
            }
        } catch (Throwable ignored) { }
        allowed = ok;
        return ok;
    }

    private boolean isTarget(Entity e, MinecraftClient mc) {
        if (e == mc.player || !(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return true;
        return targets.is("Players + Mobs") && e instanceof MobEntity;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        if (!allowedNow(mc)) {
            tracks.clear();
            if (!warned) {
                warned = true;
                mc.player.sendMessage(Text.literal("Motion Predictor: only works in singleplayer or when you are an operator"), true);
            }
            return;
        }
        Set<UUID> seen = new HashSet<>();
        double maxSq = maxDist.get() * maxDist.get();
        for (Entity e : mc.world.getEntities()) {
            if (!isTarget(e, mc) || mc.player.squaredDistanceTo(e) > maxSq) continue;
            Track t = tracks.computeIfAbsent(e.getUuid(), k -> new Track());
            seen.add(e.getUuid());
            t.hist.addLast(new Vec3d(e.getX(), e.getY(), e.getZ()));
            while (t.hist.size() > 10) t.hist.removeFirst();
            if (e.isOnGround()) t.groundY = e.getY();
        }
        tracks.keySet().retainAll(seen);
    }

    // ---------------- drawing ----------------
    private static float smooth(double x) {
        float t = (float) Math.max(0, Math.min(1, x));
        return t * t * (3 - 2 * t);
    }

    private static void line(DrawContext c, double x1, double y1, double x2, double y2, int th, int col) {
        double dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy);
        int steps = (int) Math.max(1, len / Math.max(1, th * 0.6));
        for (int s = 0; s <= steps; s++) {
            int x = (int) Math.round(x1 + dx * s / steps - th / 2.0), y = (int) Math.round(y1 + dy * s / steps - th / 2.0);
            c.fill(x, y, x + th, y + th, col);
        }
    }

    private static void triangle(DrawContext c, double ax, double ay, double bx, double by, double cx, double cy, int col) {
        int y0 = (int) Math.floor(Math.min(ay, Math.min(by, cy))), y1 = (int) Math.ceil(Math.max(ay, Math.max(by, cy)));
        double[][] p = {{ax, ay}, {bx, by}, {cx, cy}};
        for (int y = y0; y <= y1; y++) {
            double minX = 1e9, maxX = -1e9;
            double yy = y + 0.5;
            for (int i = 0; i < 3; i++) {
                double[] a = p[i], b = p[(i + 1) % 3];
                if ((a[1] <= yy && b[1] > yy) || (b[1] <= yy && a[1] > yy)) {
                    double x = a[0] + (yy - a[1]) / (b[1] - a[1]) * (b[0] - a[0]);
                    minX = Math.min(minX, x);
                    maxX = Math.max(maxX, x);
                }
            }
            if (maxX >= minX) c.fill((int) Math.round(minX), y, (int) Math.round(maxX) + 1, y + 1, col);
        }
    }

    private static void arrowHead(DrawContext c, double x, double y, double ux, double uy, double size, int col) {
        double px = -uy, py = ux;
        triangle(c, x + ux * size * 0.5, y + uy * size * 0.5,
                x - ux * size * 0.7 + px * size * 0.6, y - uy * size * 0.7 + py * size * 0.6,
                x - ux * size * 0.7 - px * size * 0.6, y - uy * size * 0.7 - py * size * 0.6, col);
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.world == null || mc.player == null || !allowedNow(mc)) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float tp = TickClock.progress();
        View v = View.of(mc, tp, sw, sh);
        PlayerEntity me = mc.player;
        Vec3d cam = me.getLerpedPos(tp).add(0, me.getEyeHeight(me.getPose()), 0);
        double time = System.nanoTime() / 1e9;
        TextRenderer tr = mc.textRenderer;
        float op = (float) opacity.get() / 100f;
        double sz = arrowSize.get() / 100.0;
        int n = horizon.getInt();
        double yawR = Math.toRadians(me.getYaw());
        double rX = -Math.cos(yawR), rZ = -Math.sin(yawR);

        List<Entity> list = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) if (tracks.containsKey(e.getUuid())) list.add(e);
        list.sort((a, b) -> Double.compare(me.squaredDistanceTo(a), me.squaredDistanceTo(b)));
        int shown = 0;
        for (Entity e : list) {
            if (shown >= 8) break;
            Track t = tracks.get(e.getUuid());
            if (t == null || t.hist.size() < 4) continue;
            Vec3d[] h = t.hist.toArray(new Vec3d[0]);
            int k = Math.min(5, h.length - 1);
            Vec3d vel = h[h.length - 1].subtract(h[h.length - 1 - k]).multiply(1.0 / k);   // blocks per tick
            double hv = Math.hypot(vel.x, vel.z) * 20;
            boolean air = !e.isOnGround();
            if (hv < 0.8 && !air) continue;                                                   // standing still: no arrow

            // predict the path (friction + gravity)
            Vec3d p = e.getLerpedPos(tp);
            double vx = vel.x, vz = vel.z, vy = vel.y, gy = t.groundY;
            List<Vec3d> path = new ArrayList<>();
            path.add(p);
            for (int i = 1; i <= n; i++) {
                vx *= 0.985;
                vz *= 0.985;
                if (air || p.y > gy + 0.05) vy = (vy - 0.08) * 0.98; else vy = 0;
                p = p.add(vx, vy, vz);
                if (p.y < gy) {
                    p = new Vec3d(p.x, gy, p.z);
                    vy = 0;
                }
                if (i % 2 == 0 || i == n) path.add(p);
            }

            // classify what it is doing relative to me
            double dxm = me.getX() - e.getX(), dzm = me.getZ() - e.getZ(), dm = Math.max(0.01, Math.hypot(dxm, dzm));
            double vl = Math.max(1e-6, Math.hypot(vel.x, vel.z));
            double dot = (vel.x * dxm + vel.z * dzm) / (vl * dm);
            double side = (vel.x * rX + vel.z * rZ) / vl;
            String act;
            int threat;
            if (hv < 0.8) {
                act = "";
                threat = 0;
            } else if (dot > 0.6) {
                act = "CHARGE";
                threat = 2;
            } else if (dot < -0.6) {
                act = "RETREAT";
                threat = 1;
            } else {
                act = side > 0 ? "STRAFE >" : "< STRAFE";
                threat = 0;
            }
            String extra = air && vel.y > 0.15 ? "JUMP" : air && vel.y < -0.3 ? "FALL" : "";
            String label = (e.isSprinting() ? "SPRINT " : "") + (act.isEmpty() ? extra : act + (extra.isEmpty() ? "" : " " + extra));
            if (label.isBlank()) label = "MOVING";

            int base;
            switch (color.get()) {
                case "Sky": base = 0x38BDF8; break;
                case "White": base = 0xFFFFFF; break;
                case "Pink": base = 0xFF7AC8; break;
                case "Rainbow": base = java.awt.Color.HSBtoRGB((float) ((time * 0.2 + shown * 0.15) % 1.0), 0.6f, 1f) & 0xFFFFFF; break;
                default: base = threat == 2 ? 0xFF4D4D : threat == 1 ? 0x4DFF88 : 0xFFD24D;
            }

            // project the path (aim at the middle of the body)
            double half = e.getHeight() * 0.5;
            List<double[]> pts = new ArrayList<>();
            for (Vec3d q : path) {
                double[] s = v.project(q.x - cam.x, q.y + half - cam.y, q.z - cam.z, sw, sh);
                if (s == null) break;
                pts.add(s);
            }
            if (pts.size() < 2) continue;
            shown++;
            int m = pts.size() - 1;
            int th = Math.max(2, (int) Math.round(2.5 * sz));
            for (int i = 0; i < m; i++) {
                double[] a = pts.get(i), b = pts.get(i + 1);
                float fade = (float) (0.95 - 0.5 * i / (double) m) * op;
                line(ctx, a[0], a[1], b[0], b[1], th + 3, RenderUtil.withAlpha(0xFF000000 | base, fade * 0.22f));
                line(ctx, a[0], a[1], b[0], b[1], th, RenderUtil.withAlpha(0xFF000000 | base, fade));
                if (chevrons.get()) {
                    double dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy);
                    if (l > 4) {
                        double pulse = 0.5 + 0.5 * Math.sin(time * 7 - i * 0.9);
                        arrowHead(ctx, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, dx / l, dy / l, 5 * sz,
                                RenderUtil.withAlpha(0xFFFFFFFF, (float) (0.25 + 0.6 * pulse) * fade));
                    }
                }
            }
            double[] a = pts.get(m - 1), b = pts.get(m);
            double dx = b[0] - a[0], dy = b[1] - a[1], l = Math.max(1e-6, Math.hypot(dx, dy));
            double ux = dx / l, uy = dy / l;
            double size = Math.max(8, 13 * sz * Math.min(1.5, 10.0 / Math.max(3.0, b[2] / 2.0)));
            arrowHead(ctx, b[0] + ux * 1.5, b[1] + uy * 1.5, ux, uy, size + 5, RenderUtil.withAlpha(0xFF000000 | base, 0.30f * op));
            arrowHead(ctx, b[0], b[1], ux, uy, size, RenderUtil.withAlpha(0xFF000000 | base, op));
            if (labels.get() && op > 0.25f) {
                String txt = label + String.format(Locale.ROOT, "  %.1f b/s", hv);
                int tw = tr.getWidth(txt);
                int lx = (int) Math.round(b[0] - tw / 2.0), ly = (int) Math.round(b[1] - size - 14);
                ctx.fill(lx - 3, ly - 2, lx + tw + 3, ly + 10, RenderUtil.withAlpha(0xFF0B0F18, 0.6f * op));
                ctx.drawText(tr, txt, lx, ly, RenderUtil.withAlpha(0xFF000000 | base, Math.max(0.2f, op)), false);
            }
        }
    }
}
