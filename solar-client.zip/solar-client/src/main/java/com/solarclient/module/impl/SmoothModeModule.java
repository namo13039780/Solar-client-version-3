package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

/** Applies video options that favour smoothness. Restores your old values when disabled. */
public class SmoothModeModule extends Module {
    private final NumberSetting maxFps = add(new NumberSetting("Max FPS", 260, 60, 260, 10));
    private final BoolSetting noVsync = add(new BoolSetting("Disable VSync", true));
    private final BoolSetting noShadows = add(new BoolSetting("No Entity Shadows", true));

    private Integer origFps;
    private Boolean origVsync, origShadows;

    public SmoothModeModule() {
        super("Smooth Mode", "Higher FPS cap, no VSync, fewer shadows = smoother", Category.PERFORMANCE, false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (o == null) return;
        if (origFps == null) {
            origFps = o.getMaxFps().getValue();
            origVsync = o.getEnableVsync().getValue();
            origShadows = o.getEntityShadows().getValue();
        }
        int target = maxFps.getInt();
        if (o.getMaxFps().getValue() != target) o.getMaxFps().setValue(target);
        if (noVsync.get() && o.getEnableVsync().getValue()) o.getEnableVsync().setValue(false);
        if (noShadows.get() && o.getEntityShadows().getValue()) o.getEntityShadows().setValue(false);
    }

    @Override
    protected void onDisable() {
        if (origFps == null) return;
        GameOptions o = MinecraftClient.getInstance().options;
        o.getMaxFps().setValue(origFps);
        o.getEnableVsync().setValue(origVsync);
        o.getEntityShadows().setValue(origShadows);
        origFps = null;
        origVsync = null;
        origShadows = null;
    }
}
