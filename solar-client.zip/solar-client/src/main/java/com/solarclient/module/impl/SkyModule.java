package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;

/** Client-side custom sky (overworld only). Purely visual. */
public class SkyModule extends Module {
    public static SkyModule I;

    private final ModeSetting preset = add(new ModeSetting("Preset", "Custom", "Custom", "Rainbow", "Aurora", "Sunset", "Galaxy", "Midnight", "Candy"));
    private final NumberSetting red = add(new NumberSetting("Red", 90, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Green", 160, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));
    private final NumberSetting brightness = add(new NumberSetting("Brightness", 100, 20, 150, 5));
    private final NumberSetting speed = add(new NumberSetting("Cycle Speed", 4, 1, 10, 1));
    private final BoolSetting customStars = add(new BoolSetting("Custom Stars", false));
    private final NumberSetting stars = add(new NumberSetting("Star Brightness", 100, 0, 100, 5));
    private final ModeSetting glow = add(new ModeSetting("Sunset Glow", "Default", "Default", "Off", "Match Sky"));
    private final BoolSetting clear = add(new BoolSetting("Clear Sky", false));

    public SkyModule() {
        super("Custom Sky", "Change sky color, stars and sunset glow (client only)", Category.VISUAL, false);
        I = this;
    }

    private int color() {
        double t = System.nanoTime() / 1e9 * speed.get() * 0.15;
        float s = (float) (0.5 + 0.5 * Math.sin(t));
        float s2 = (float) (0.5 + 0.5 * Math.sin(t * 0.7 + 1.3));
        int c;
        switch (preset.get()) {
            case "Rainbow" -> c = java.awt.Color.HSBtoRGB((float) ((t * 0.12) % 1.0), 0.55f, 1f);
            case "Aurora" -> c = RenderUtil.lerp(RenderUtil.lerp(0xFF00FFC8, 0xFF9B30FF, s), 0xFF30FF70, s2 * 0.6f);
            case "Sunset" -> c = RenderUtil.lerp(RenderUtil.lerp(0xFFFF8C42, 0xFFFF4F81, s), 0xFF6A3FA0, s2 * 0.7f);
            case "Galaxy" -> c = RenderUtil.lerp(0xFF1B0B3A, 0xFF3B1F7A, s);
            case "Midnight" -> c = 0xFF050818;
            case "Candy" -> c = RenderUtil.lerp(0xFFFF9ACB, 0xFF8FD3FF, s);
            default -> c = (red.getInt() << 16) | (green.getInt() << 8) | blue.getInt();
        }
        float b = (float) brightness.get() / 100f;
        int r = Math.min(255, Math.round(((c >> 16) & 0xFF) * b));
        int g = Math.min(255, Math.round(((c >> 8) & 0xFF) * b));
        int bl = Math.min(255, Math.round((c & 0xFF) * b));
        return (r << 16) | (g << 8) | bl;
    }

    public static void apply(ClientWorld world, SkyRenderState s) {
        SkyModule m = I;
        if (m == null || !m.isEnabled() || world == null || s == null) return;
        if (world.getRegistryKey() != World.OVERWORLD) return;
        int rgb = m.color();
        s.skyColor = 0xFF000000 | rgb;
        if (m.customStars.get()) s.starBrightness = (float) m.stars.get() / 100f;
        if (m.glow.is("Off")) s.sunriseAndSunsetColor = 0;
        else if (m.glow.is("Match Sky")) s.sunriseAndSunsetColor = 0xB0000000 | rgb;
        if (m.clear.get()) s.rainGradient = 0f;
    }
}
