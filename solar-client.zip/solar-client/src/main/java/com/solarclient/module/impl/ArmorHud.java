package com.solarclient.module.impl;

import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

public class ArmorHud extends HudModule {
    private final ModeSetting layoutMode = add(new ModeSetting("Layout", "Vertical", "Vertical", "Horizontal"));
    private final BoolSetting durability = add(new BoolSetting("Durability", true));
    private final BoolSetting heldItem = add(new BoolSetting("Held Item", false));

    private List<ItemStack> stacks = new ArrayList<>();
    private int textW;

    public ArmorHud() {
        super("Armor HUD", "Shows your armor and its durability", 0.99f, 0.62f, true);
    }

    private List<ItemStack> collect(MinecraftClient mc, boolean editing) {
        List<ItemStack> list = new ArrayList<>();
        PlayerEntity p = mc.player;
        if (p != null) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot s : slots) {
                ItemStack st = p.getEquippedStack(s);
                if (!st.isEmpty()) list.add(st);
            }
            if (heldItem.get() && !p.getMainHandStack().isEmpty()) list.add(p.getMainHandStack());
        }
        if (list.isEmpty() && editing) {
            list.add(new ItemStack(Items.DIAMOND_HELMET));
            list.add(new ItemStack(Items.DIAMOND_CHESTPLATE));
            list.add(new ItemStack(Items.DIAMOND_LEGGINGS));
            list.add(new ItemStack(Items.DIAMOND_BOOTS));
        }
        return list;
    }

    private static String durText(ItemStack s) {
        return s.isDamageable() ? String.valueOf(s.getMaxDamage() - s.getDamage()) : "";
    }

    private static int durColor(ItemStack s) {
        if (!s.isDamageable()) return 0xFFFFFFFF;
        float f = 1f - (float) s.getDamage() / Math.max(1, s.getMaxDamage());
        return f > 0.5f ? RenderUtil.lerp(0xFFFFD54F, 0xFF4ADE80, (f - 0.5f) * 2f) : RenderUtil.lerp(0xFFEF4444, 0xFFFFD54F, f * 2f);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        stacks = collect(mc, editing);
        if (stacks.isEmpty()) {
            w = h = 0;
            return;
        }
        TextRenderer tr = mc.textRenderer;
        textW = 0;
        for (ItemStack s : stacks) textW = Math.max(textW, tr.getWidth(durText(s)));
        boolean dur = durability.get();
        if (layoutMode.is("Vertical")) {
            w = 3 + 16 + (dur ? 4 + textW : 0) + 4;
            h = stacks.size() * 18 + 4;
        } else {
            int cell = dur ? Math.max(20, textW + 4) : 20;
            w = stacks.size() * cell + 4;
            h = 20 + (dur ? 10 : 0);
        }
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        panel(ctx, x, y, w, h);
        boolean dur = durability.get();
        boolean sh = StyleModule.shadow();
        if (layoutMode.is("Vertical")) {
            int cy = y + 2;
            for (ItemStack s : stacks) {
                ctx.drawItem(s, x + 3, cy);
                if (dur) ctx.drawText(tr, durText(s), x + 3 + 16 + 4, cy + 4, durColor(s), sh);
                cy += 18;
            }
        } else {
            int cell = dur ? Math.max(20, textW + 4) : 20;
            int cx = x + 2;
            for (ItemStack s : stacks) {
                ctx.drawItem(s, cx + (cell - 16) / 2, y + 2);
                if (dur) {
                    String t = durText(s);
                    ctx.drawText(tr, t, cx + (cell - tr.getWidth(t)) / 2, y + 20, durColor(s), sh);
                }
                cx += cell;
            }
        }
    }
}
