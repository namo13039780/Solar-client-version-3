package com.solarclient.module.impl;

import com.solarclient.SolarClient;
import com.solarclient.module.HudModule;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class WatermarkHud extends HudModule {
    private static final String TEXT = "Solar Client";

    public WatermarkHud() {
        super("Watermark", "Solar Client logo on screen", 0.008f, 0.012f, true);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        w = mc.textRenderer.getWidth(TEXT) + 8 + mc.textRenderer.getWidth("v" + SolarClient.VERSION) + 6;
        h = 15;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        panel(ctx, x, y, w, h);
        double t = System.currentTimeMillis() / 1000.0;
        RenderUtil.gradientText(ctx, mc.textRenderer, TEXT, x + 4, y + 4, 1f, true,
                f -> RenderUtil.lerp(RenderUtil.SKY_LIGHT, 0xFF2563EB, (float) (0.5 + 0.5 * Math.sin(f * 3.0 - t * 1.5))));
        ctx.drawText(mc.textRenderer, "v" + SolarClient.VERSION, x + 4 + mc.textRenderer.getWidth(TEXT) + 6, y + 4, 0xFF8EA2BF, false);
    }
}
