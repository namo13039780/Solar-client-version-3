package com.solarclient.module.impl;

import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.Category;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Shows how many of each given item you carry (display only). */
public class ItemCounterHud extends HudModule {
    private final Item[] items;
    private ItemStack[] icons;
    private final int[] counts;
    private final List<Integer> shown = new ArrayList<>();
    private int textW;

    private final BoolSetting hideZero = add(new BoolSetting("Hide Zero", false));
    private final ModeSetting layoutMode = add(new ModeSetting("Layout", "Vertical", "Vertical", "Horizontal"));

    public ItemCounterHud(String name, String desc, float fx, float fy, boolean def, Item... items) {
        super(name, desc, Category.PVP, fx, fy, def);
        this.items = items;
        this.counts = new int[items.length];
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        if (icons == null) {
            icons = new ItemStack[items.length];
            for (int i = 0; i < items.length; i++) icons[i] = new ItemStack(items[i]);
        }
        java.util.Arrays.fill(counts, 0);
        if (mc.player != null) {
            PlayerInventory inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isEmpty()) continue;
                for (int j = 0; j < items.length; j++) if (s.isOf(items[j])) counts[j] += s.getCount();
            }
        } else if (editing) {
            java.util.Arrays.fill(counts, 16);
        }
        if (editing && mc.player != null) {
            boolean any = false;
            for (int c : counts) if (c > 0) any = true;
            if (!any) java.util.Arrays.fill(counts, 16);
        }
        shown.clear();
        for (int i = 0; i < items.length; i++) if (!hideZero.get() || counts[i] > 0) shown.add(i);
        if (shown.isEmpty()) {
            w = h = 0;
            return;
        }
        TextRenderer tr = mc.textRenderer;
        textW = 0;
        for (int i : shown) textW = Math.max(textW, tr.getWidth(String.valueOf(counts[i])));
        if (layoutMode.is("Vertical")) {
            w = 3 + 16 + 4 + textW + 5;
            h = shown.size() * 18 + 4;
        } else {
            int cell = Math.max(20, textW + 4);
            w = shown.size() * cell + 4;
            h = 30;
        }
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        panel(ctx, x, y, w, h);
        boolean sh = StyleModule.shadow();
        if (layoutMode.is("Vertical")) {
            int cy = y + 2;
            for (int i : shown) {
                ctx.drawItem(icons[i], x + 3, cy);
                ctx.drawText(tr, String.valueOf(counts[i]), x + 3 + 16 + 4, cy + 4, counts[i] == 0 ? 0xFFFF5555 : 0xFFFFFFFF, sh);
                cy += 18;
            }
        } else {
            int cell = Math.max(20, textW + 4);
            int cx = x + 2;
            for (int i : shown) {
                ctx.drawItem(icons[i], cx + (cell - 16) / 2, y + 2);
                String t = String.valueOf(counts[i]);
                ctx.drawText(tr, t, cx + (cell - tr.getWidth(t)) / 2, y + 20, counts[i] == 0 ? 0xFFFF5555 : 0xFFFFFFFF, sh);
                cx += cell;
            }
        }
    }
}
