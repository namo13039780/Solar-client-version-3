package com.solarclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.function.Function;

/** "LABEL value" style HUD box. */
public class SimpleTextHud extends HudModule {
    private final String label;
    private final Function<MinecraftClient, String> value;
    private String text = "";

    public SimpleTextHud(String name, String desc, float fx, float fy, boolean def,
                         String label, Function<MinecraftClient, String> value) {
        this(name, desc, Category.HUD, fx, fy, def, label, value);
    }

    public SimpleTextHud(String name, String desc, Category cat, float fx, float fy, boolean def,
                         String label, Function<MinecraftClient, String> value) {
        super(name, desc, cat, fx, fy, def);
        this.label = label;
        this.value = value;
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        String v;
        try {
            v = mc.player == null && !editing ? "-" : value.apply(mc);
        } catch (Exception e) {
            v = "-";
        }
        text = v == null ? "-" : v;
        TextRenderer tr = mc.textRenderer;
        w = 4 + tr.getWidth(label) + 5 + tr.getWidth(text) + 4;
        h = 13;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        panel(ctx, x, y, w, h);
        boolean sh = StyleModule.shadow();
        ctx.drawText(tr, label, x + 4, y + 3, StyleModule.accent(), sh);
        ctx.drawText(tr, text, x + 4 + tr.getWidth(label) + 5, y + 3, 0xFFFFFFFF, sh);
    }
}
