package com.solarclient.module.impl;

import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

import java.util.Locale;

/** Shows the health (hearts) of the entity you are looking at. Display only. */
public class TargetHealthHud extends HudModule {
    private final ModeSetting style = add(new ModeSetting("Style", "Hearts", "Hearts", "Bar"));
    private final BoolSetting showName = add(new BoolSetting("Show Name", true));
    private final BoolSetting smooth = add(new BoolSetting("Smooth Animation", false));

    private LivingEntity last;
    private long lastSeen;
    private float shown;
    private long lastFrame = System.nanoTime();

    private boolean visible;
    private String name = "";
    private float health, max, absorb;
    private LivingEntity shownFor;

    public TargetHealthHud() {
        super("Target Health", "Hearts of the player/mob you're looking at", 0.5f, 0.56f, true);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        long now = System.currentTimeMillis();
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) {
            last = le;
            lastSeen = now;
        }
        visible = false;
        if (editing) {
            visible = true;
            name = "Steve";
            health = 14.5f;
            max = 20f;
            absorb = 0f;
        } else if (last != null && now - lastSeen < 3000 && last.isAlive() && !last.isRemoved()) {
            visible = true;
            name = last.getName().getString();
            health = last.getHealth();
            max = Math.max(1f, last.getMaxHealth());
            absorb = last.getAbsorptionAmount();
        }
        if (!visible) {
            w = h = 0;
            return;
        }
        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - lastFrame) / 1e9f);
        lastFrame = n;
        // a different target (or first sighting) starts at its real health, never animating from the previous one
        if (editing || shownFor != last || !smooth.get()) {
            shown = health;
            shownFor = editing ? null : last;
        } else if (health < shown) {
            shown = health;                                   // damage shows instantly
        } else {
            shown += (health - shown) * Math.min(1f, dt * 14f);
            if (Math.abs(shown - health) < 0.05f) shown = health;
        }

        TextRenderer tr = mc.textRenderer;
        int hearts = Math.min(10, (int) Math.ceil(max / 2f));
        int gold = Math.min(5, (int) Math.ceil(absorb / 2f));
        int body = style.is("Hearts") ? (hearts + gold) * 8 : 90;
        int top = tr.getWidth((showName.get() ? name + "  " : "") + hpText());
        w = Math.max(body, top) + 10;
        h = 4 + 10 + 3 + 9 + 4;
    }

    private String hpText() {
        return String.format(Locale.ROOT, "%.1f/%.1f", health, max) + (absorb > 0.05f ? String.format(Locale.ROOT, " +%.0f", absorb) : "");
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        panel(ctx, x, y, w, h);
        boolean sh = StyleModule.shadow();
        int tx = x + 5;
        int ty = y + 4;
        if (showName.get()) {
            ctx.drawText(tr, name, tx, ty, 0xFFFFFFFF, sh);
            String hp = hpText();
            ctx.drawText(tr, hp, x + w - 5 - tr.getWidth(hp), ty, StyleModule.accent(), sh);
        } else {
            String hp = hpText();
            ctx.drawText(tr, hp, tx, ty, StyleModule.accent(), sh);
        }
        int ly = y + 4 + 10 + 3;
        float ratio = Math.max(0f, Math.min(1f, shown / max));
        if (style.is("Hearts")) {
            int hearts = Math.min(10, (int) Math.ceil(max / 2f));
            for (int i = 0; i < hearts; i++) {
                float fill = Math.max(0f, Math.min(1f, ratio * hearts - i));
                RenderUtil.heart(ctx, tx + i * 8, ly, fill, 0xFFFF3B4A, 0xFF3A1218);
            }
            int gold = Math.min(5, (int) Math.ceil(absorb / 2f));
            for (int i = 0; i < gold; i++) {
                float fill = Math.max(0f, Math.min(1f, absorb / 2f - i));
                RenderUtil.heart(ctx, tx + (hearts + i) * 8, ly, fill, 0xFFFFC857, 0xFF3A2A10);
            }
        } else {
            int bw = w - 10;
            int col = ratio > 0.5f ? RenderUtil.lerp(0xFFFFD54F, 0xFF4ADE80, (ratio - 0.5f) * 2f)
                    : RenderUtil.lerp(0xFFEF4444, 0xFFFFD54F, ratio * 2f);
            ctx.fill(tx, ly, tx + bw, ly + 6, 0xFF1B2230);
            ctx.fill(tx, ly, tx + Math.round(bw * ratio), ly + 6, col);
        }
    }
}
