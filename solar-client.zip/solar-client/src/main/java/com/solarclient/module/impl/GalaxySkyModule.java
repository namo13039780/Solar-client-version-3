package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;

/**
 * Procedural Milky Way and aurora painted over the upper part of the screen (where the sky is).
 * It is an overlay, anchored to the world direction you look at, not real sky geometry.
 */
public class GalaxySkyModule extends Module {
    public static GalaxySkyModule I;

    private final BoolSetting galaxy = add(new BoolSetting("Galaxy", true));
    private final ModeSetting galaxyColor = add(new ModeSetting("Galaxy Color", "Purple", "Purple", "Blue", "Pink", "Teal"));
    private final NumberSetting galaxyBright = add(new NumberSetting("Galaxy Brightness", 70, 10, 100, 5));
    private final BoolSetting aurora = add(new BoolSetting("Aurora", true));
    private final ModeSetting auroraColor = add(new ModeSetting("Aurora Color", "Green", "Green", "Purple", "Blue", "Rainbow"));
    private final NumberSetting auroraBright = add(new NumberSetting("Aurora Intensity", 70, 10, 100, 5));
    private final BoolSetting nightOnly = add(new BoolSetting("Night Only", true));
    private final ModeSetting quality = add(new ModeSetting("Quality", "Medium", "Low", "Medium", "High"));

    private static final double NX, NY, NZ, GX, GY, GZ;
    static {
        double l = Math.sqrt(0.30 * 0.30 + 0.85 * 0.85 + 0.43 * 0.43);
        NX = 0.30 / l; NY = 0.85 / l; NZ = 0.43 / l;
        double m = Math.sqrt(0.45 * 0.45 + 0.40 * 0.40 + 0.80 * 0.80);
        GX = -0.45 / m; GY = 0.40 / m; GZ = 0.80 / m;
    }
    private static final int[][] PAL = {
            {0x2A1E7A, 0x8E4FD6, 0xFFC0E8}, {0x13306E, 0x3F8CFF, 0xBFE6FF},
            {0x4A1A5E, 0xE05AB0, 0xFFD2E0}, {0x0F4A5E, 0x2FD0C0, 0xD0FFF0}};

    public GalaxySkyModule() {
        super("Galaxy Sky", "Milky Way and aurora in the night sky (screen overlay)", Category.VISUAL, false);
        I = this;
    }

    private static double smooth(double e0, double e1, double x) {
        double t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
        return t * t * (3 - 2 * t);
    }

    private static float hash(int x, int y, int z) {
        int h = x * 374761393 + y * 668265263 + z * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }

    private static float noise(float x, float y, float z) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y), zi = (int) Math.floor(z);
        float xf = x - xi, yf = y - yi, zf = z - zi;
        xf = xf * xf * (3 - 2 * xf);
        yf = yf * yf * (3 - 2 * yf);
        zf = zf * zf * (3 - 2 * zf);
        float a = hash(xi, yi, zi), b = hash(xi + 1, yi, zi), c = hash(xi, yi + 1, zi), d = hash(xi + 1, yi + 1, zi);
        float e = hash(xi, yi, zi + 1), f = hash(xi + 1, yi, zi + 1), g = hash(xi, yi + 1, zi + 1), h = hash(xi + 1, yi + 1, zi + 1);
        float x1 = a + (b - a) * xf, x2 = c + (d - c) * xf, x3 = e + (f - e) * xf, x4 = g + (h - g) * xf;
        float y1 = x1 + (x2 - x1) * yf, y2 = x3 + (x4 - x3) * yf;
        return y1 + (y2 - y1) * zf;
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;
        ClientWorld w = mc.world;
        if (w.getRegistryKey() != World.OVERWORLD) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        if (!w.isSkyVisible(mc.player.getBlockPos())) return;

        float night = 1f;
        if (nightOnly.get()) {
            long tod = w.getTimeOfDay() % 24000L;
            if (tod < 0) tod += 24000L;
            night = tod < 12000 ? 0f : tod < 13200 ? (tod - 12000) / 1200f : tod < 22800 ? 1f : (24000 - tod) / 1200f;
        }
        float vis = night * (1f - 0.85f * w.getRainGradient(1f));
        if (vis < 0.02f) return;

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        View v = View.of(mc, TickClock.progress(), sw, sh);
        int cell = quality.is("Low") ? 8 : quality.is("High") ? 4 : 6;
        double t = System.nanoTime() / 1e9;
        double rot = t * 0.004, cr = Math.cos(rot), sr = Math.sin(rot);
        boolean doG = galaxy.get(), doA = aurora.get();
        float gB = (float) galaxyBright.get() / 100f, aB = (float) auroraBright.get() / 100f;
        int[] pal = PAL[galaxyColor.is("Blue") ? 1 : galaxyColor.is("Pink") ? 2 : galaxyColor.is("Teal") ? 3 : 0];

        for (int j = 0; j < sh; j += cell) {
            double ndcY = 1 - (j + cell * 0.5) / sh * 2;
            for (int i = 0; i < sw; i += cell) {
                double ndcX = (i + cell * 0.5) / sw * 2 - 1;
                double dx = ndcX * v.aspect / v.f, dy = ndcY / v.f;
                double x = v.rx * dx + v.ux * dy + v.fx, y = v.ry * dx + v.uy * dy + v.fy, z = v.rz * dx + v.uz * dy + v.fz;
                double len = Math.sqrt(x * x + y * y + z * z);
                x /= len; y /= len; z /= len;
                if (y < 0.10) continue;
                float edge = (float) smooth(0.10, 0.30, y);

                if (doG) {
                    double gx = x * cr - z * sr, gz = x * sr + z * cr;
                    double lat = gx * NX + y * NY + gz * NZ;
                    double band = Math.exp(-(lat * lat) / 0.07);
                    if (band > 0.03) {
                        float n1 = noise((float) (gx * 3.4 + 11), (float) (y * 3.4), (float) (gz * 3.4 + 7));
                        float n2 = noise((float) (gx * 8.1), (float) (y * 8.1 + 3), (float) (gz * 8.1));
                        double cg = gx * GX + y * GY + gz * GZ;
                        double core = Math.exp(-(1 - cg) * 7);
                        double inten = Math.min(1, band * (0.35 + 0.95 * n1) * (0.75 + 0.5 * n2) * 0.7 + core * 0.55);
                        float a = (float) (inten * 0.62) * gB * edge * vis;
                        if (a > 0.012f) {
                            int col = RenderUtil.lerp(0xFF000000 | pal[0], 0xFF000000 | pal[1], (float) Math.min(1, inten * 1.6));
                            col = RenderUtil.lerp(col, 0xFF000000 | pal[2], (float) Math.min(1, core * 0.9));
                            ctx.fill(i, j, i + cell, j + cell, RenderUtil.withAlpha(col, a));
                        }
                    }
                }

                if (doA) {
                    double rel = Math.atan2(x, z) - Math.PI;
                    while (rel < -Math.PI) rel += Math.PI * 2;
                    while (rel > Math.PI) rel -= Math.PI * 2;
                    double mask = 1 - smooth(0.45, 1.25, Math.abs(rel));
                    if (mask > 0.02) {
                        double el = Math.asin(Math.min(1, y));
                        double vert = Math.exp(-Math.pow((el - 0.55) / 0.30, 2));
                        double ph = rel * 10 + 1.6 * Math.sin(rel * 3.7 + t * 0.35) + t * 0.4;
                        double ray = Math.pow(0.5 + 0.5 * Math.sin(ph), 2.2);
                        double fl = 0.75 + 0.25 * Math.sin(t * 1.7 + rel * 5);
                        double inten = ray * vert * mask * fl;
                        float a = (float) (inten * 0.55) * aB * edge * vis;
                        if (a > 0.012f) {
                            float u = (float) Math.max(0, Math.min(1, (el - 0.15) / 0.9));
                            int c0, c1;
                            if (auroraColor.is("Purple")) { c0 = 0xB05CFF; c1 = 0xFF5CC8; }
                            else if (auroraColor.is("Blue")) { c0 = 0x30C8FF; c1 = 0x6A5CFF; }
                            else if (auroraColor.is("Rainbow")) {
                                c0 = java.awt.Color.HSBtoRGB((float) ((rel * 0.3 + t * 0.05) % 1.0 + 1.0) % 1f, 0.7f, 1f) & 0xFFFFFF;
                                c1 = java.awt.Color.HSBtoRGB((float) ((rel * 0.3 + t * 0.05 + 0.3) % 1.0 + 1.0) % 1f, 0.7f, 1f) & 0xFFFFFF;
                            } else { c0 = 0x40FF8A; c1 = 0xB05CFF; }
                            int col = RenderUtil.lerp(0xFF000000 | c0, 0xFF000000 | c1, u);
                            ctx.fill(i, j, i + cell, j + cell, RenderUtil.withAlpha(col, a));
                        }
                    }
                }
            }
        }
    }
}
