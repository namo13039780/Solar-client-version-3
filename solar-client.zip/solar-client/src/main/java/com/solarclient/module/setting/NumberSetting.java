package com.solarclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(def);
    }

    public double get() { return value; }
    public int getInt() { return (int) Math.round(value); }

    public void set(double v) {
        double s = Math.round((v - min) / step) * step + min;
        value = Math.max(min, Math.min(max, s));
    }

    public void setFromFraction(double f) {
        set(min + (max - min) * Math.max(0, Math.min(1, f)));
    }

    public double fraction() { return (value - min) / (max - min); }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { set(e.getAsDouble()); }
}
