package com.solarclient.module.impl;

import com.solarclient.gui.ClickGuiScreen;
import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;

import java.util.Locale;
import java.util.Random;

/**
 * Anime-style "impact frame" shown when a mace smash actually damages a target.
 * Purely visual overlay: it never changes gameplay, sends nothing and automates nothing.
 */
public class MaceImpactModule extends Module {
    public static MaceImpactModule I;

    private final ModeSetting style = add(new ModeSetting("Style", "Full", "Full", "Soft"));
    private final ModeSetting triggerMode = add(new ModeSetting("Trigger", "Damage", "Damage", "Any Hit"));
    private final NumberSetting rays = add(new NumberSetting("Speed Lines", 28, 8, 48, 4));
    private final BoolSetting text = add(new BoolSetting("Show Text", true));
    private final BoolSetting bars = add(new BoolSetting("Cinema Bars", true));
    @SuppressWarnings("unused")
    private final ActionSetting preview = add(new ActionSetting("Preview Effect", () -> {
        setEnabled(true);
        previewPending = true;
    }));

    private double peakY;
    private double recentFall;
    private long recentFallAt;
    private boolean prevAttack;
    private LivingEntity target;
    private float hpBefore;
    private long armedAt;

    private long fxStart = -1;
    private float fxDamage;
    private long previewAt = -1;
    private boolean previewPending;
    private final float[] ang = new float[48], r0 = new float[48], len = new float[48], th = new float[48];

    public MaceImpactModule() {
        super("Mace Impact Frame", "Anime impact frame when your mace smash lands (visual only)", Category.PVP, false);
        I = this;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        detect(mc);
        if (previewPending) {
            previewPending = false;
            if (mc.currentScreen instanceof ClickGuiScreen g) g.close();
            previewAt = System.nanoTime() + 400_000_000L;
        }
    }


    /** Called every frame and every tick (edge based, so calling twice is harmless). */
    private void detect(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null) return;
        long now = System.nanoTime();
        if (p.isOnGround() || p.getY() > peakY) peakY = p.getY();
        double fall = Math.max(0, peakY - p.getY());
        // remember the biggest recent fall for a moment, so a hit on the landing tick still counts
        if (fall > recentFall || now - recentFallAt > 450_000_000L) {
            recentFall = fall;
            recentFallAt = now;
        }
        double eff = Math.max(fall, recentFall);

        boolean atk = mc.currentScreen == null && mc.options.attackKey.isPressed();
        if (atk && !prevAttack) {
            boolean mace = Registries.ITEM.getId(p.getMainHandStack().getItem()).getPath().equals("mace");
            if (mace && eff > 1.5 && mc.targetedEntity instanceof LivingEntity le && le != p) {
                if (triggerMode.is("Any Hit")) {
                    trigger(-1f);
                    target = null;
                } else {
                    target = le;
                    hpBefore = le.getHealth() + le.getAbsorptionAmount();
                    armedAt = now;
                }
            }
        }
        prevAttack = atk;

        if (target != null) {
            float hp = target.getHealth() + target.getAbsorptionAmount();
            if (hp < hpBefore - 0.1f || !target.isAlive()) {
                trigger(Math.max(0f, hpBefore - hp));
                target = null;
            } else if (now - armedAt > 1_200_000_000L) {
                target = null;
            }
        }
        if (previewAt > 0 && now >= previewAt) {
            previewAt = -1;
            trigger(12.5f);
        }
    }

    private void trigger(float damage) {
        fxStart = System.nanoTime();
        fxDamage = damage;
        Random r = new Random(fxStart);
        int n = rays.getInt();
        for (int i = 0; i < n; i++) {
            ang[i] = (float) ((i + r.nextFloat() * 0.8f) / n * Math.PI * 2);
            r0[i] = 0.10f + r.nextFloat() * 0.20f;
            len[i] = 0.55f + r.nextFloat() * 0.45f;
            th[i] = 2 + r.nextInt(3);
        }
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        detect(mc);
        if (fxStart < 0) return;
        long now = System.nanoTime();

        // ---- draw ----
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float t = (now - fxStart) / 1e9f;
        boolean soft = style.is("Soft");
        float D = soft ? 0.9f : 0.7f;
        if (t > D) {
            fxStart = -1;
            return;
        }
        float cx = sw / 2f, cy = sh / 2f;
        float minD = Math.min(sw, sh), diag = (float) Math.hypot(sw, sh);
        int n = rays.getInt();

        if (!soft && t < 0.17f) {
            if (t < 0.05f) {
                ctx.fill(0, 0, sw, sh, 0xFFFFFFFF);
            } else if (t < 0.11f) {
                ctx.fill(0, 0, sw, sh, 0xFF000000);
                drawRays(ctx, sw, sh, cx, cy, minD, diag, 0xFFFFFFFF, n, t);
            } else {
                ctx.fill(0, 0, sw, sh, 0xFFFFFFFF);
                drawRays(ctx, sw, sh, cx, cy, minD, diag, 0xFF000000, n, t);
            }
        } else {
            float k = soft ? t / D : (t - 0.17f) / (D - 0.17f);
            float fade = 1f - Math.min(1f, k);
            int s = Math.max(2, sh / 45);
            for (int i = 0; i < 14; i++) {
                int col = RenderUtil.withAlpha(0xFF000000, fade * 0.55f * (1f - i / 14f));
                ctx.fill(0, i * s, sw, (i + 1) * s, col);
                ctx.fill(0, sh - (i + 1) * s, sw, sh - i * s, col);
                ctx.fill(i * s, 0, (i + 1) * s, sh, col);
                ctx.fill(sw - (i + 1) * s, 0, sw - i * s, sh, col);
            }
            if (k < 0.6f || soft) {
                drawRays(ctx, sw, sh, cx, cy, minD, diag,
                        RenderUtil.withAlpha(RenderUtil.SKY_LIGHT, fade * (soft ? 0.35f : 0.7f)), n, t);
            }
            float rr = minD * (0.1f + 0.9f * Math.min(1f, k * 1.3f));
            int ringCol = RenderUtil.withAlpha(RenderUtil.SKY, fade * 0.9f);
            for (int j = 0; j < 110; j++) {
                double a = j * Math.PI * 2 / 110;
                int x = (int) (cx + Math.cos(a) * rr), y = (int) (cy + Math.sin(a) * rr);
                ctx.fill(x, y, x + 3, y + 3, ringCol);
            }
        }

        if (bars.get()) {
            float b = t < 0.1f ? t / 0.1f : (t > D - 0.2f ? Math.max(0f, (D - t) / 0.2f) : 1f);
            int bh = Math.round(sh * 0.12f * b);
            ctx.fill(0, 0, sw, bh, 0xFF000000);
            ctx.fill(0, sh - bh, sw, sh, 0xFF000000);
        }

        if (text.get() && t >= (soft ? 0.05f : 0.11f)) {
            float t0 = soft ? 0.05f : 0.11f;
            float e = Math.min(1f, (t - t0) / 0.25f);
            e = 1f - (1f - e) * (1f - e) * (1f - e);
            float scale = 4.5f - 1.5f * e;
            float alpha = Math.min(1f, Math.max(0f, (D - t) / 0.25f));
            String s = "SMASH!";
            var tr = mc.textRenderer;
            float tw = tr.getWidth(s) * scale;
            double time = t * 2;
            RenderUtil.gradientText(ctx, tr, s, cx - tw / 2f + 2, cy - 4 * scale + 2, scale, false,
                    f -> RenderUtil.withAlpha(0xFF000000, alpha));
            RenderUtil.gradientText(ctx, tr, s, cx - tw / 2f, cy - 4 * scale, scale, false,
                    f -> RenderUtil.withAlpha(RenderUtil.skyGradient(f, time), alpha));
            if (fxDamage < 0f) return;
            String d = String.format(Locale.ROOT, "-%.1f", fxDamage);
            float dw = tr.getWidth(d) * 2f;
            RenderUtil.gradientText(ctx, tr, d, cx - dw / 2f, cy + 4 * scale + 6, 2f, true,
                    f -> RenderUtil.withAlpha(0xFFFFFFFF, alpha));
        }
    }

    private void drawRays(DrawContext c, int sw, int sh, float cx, float cy, float minD, float diag, int col, int n, float t) {
        float grow = Math.min(1f, (t + 0.04f) / 0.08f);
        for (int i = 0; i < n; i++) {
            float cs = (float) Math.cos(ang[i]), sn = (float) Math.sin(ang[i]);
            float start = r0[i] * minD, end = len[i] * diag * grow;
            int sz = (int) th[i];
            for (float r = start; r < end; r += sz) {
                int x = (int) (cx + cs * r), y = (int) (cy + sn * r);
                if (x < -4 || y < -4 || x > sw || y > sh) break;
                c.fill(x, y, x + sz, y + sz, col);
            }
        }
    }
}
