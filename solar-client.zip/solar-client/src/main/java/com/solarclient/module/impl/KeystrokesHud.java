package com.solarclient.module.impl;

import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class KeystrokesHud extends HudModule {
    private static final int K = 18, G = 2;

    private final BoolSetting mouse = add(new BoolSetting("Mouse Buttons", true));
    private final BoolSetting space = add(new BoolSetting("Space Bar", true));
    private final float[] anim = new float[7];

    public KeystrokesHud() {
        super("Keystrokes", "Shows WASD, mouse and space presses", 0.01f, 0.72f, true);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        w = 3 * K + 2 * G;
        int next;
        if (mouse.get()) {
            h = 3 * K + 2 * G;
            next = h + G;
        } else {
            h = 2 * K + G;
            next = h + G;
        }
        if (space.get()) h = next + 10;
    }

    private void key(DrawContext ctx, TextRenderer tr, int i, int x, int y, int kw, int kh, String label, boolean down) {
        anim[i] += ((down ? 1f : 0f) - anim[i]) * 0.35f;
        int bg = RenderUtil.lerp(StyleModule.background() ? StyleModule.bgColor() | 0x80000000 : 0x80101822,
                RenderUtil.withAlpha(RenderUtil.SKY, 0.8f), anim[i]);
        RenderUtil.rrect(ctx, x, y, x + kw, y + kh, 2, bg);
        if (!label.isEmpty()) {
            ctx.drawText(tr, label, x + (kw - tr.getWidth(label)) / 2, y + (kh - 8) / 2 + 1,
                    RenderUtil.lerp(0xFFFFFFFF, 0xFF05121C, anim[i]), false);
        }
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        var o = mc.options;
        key(ctx, tr, 0, x + K + G, y, K, K, "W", o.forwardKey.isPressed());
        int r1 = y + K + G;
        key(ctx, tr, 1, x, r1, K, K, "A", o.leftKey.isPressed());
        key(ctx, tr, 2, x + K + G, r1, K, K, "S", o.backKey.isPressed());
        key(ctx, tr, 3, x + 2 * (K + G), r1, K, K, "D", o.rightKey.isPressed());
        int next = r1 + K + G;
        if (mouse.get()) {
            int bw = (w - G) / 2;
            key(ctx, tr, 4, x, next, bw, K, "LMB", o.attackKey.isPressed());
            key(ctx, tr, 5, x + bw + G, next, w - bw - G, K, "RMB", o.useKey.isPressed());
            next += K + G;
        }
        if (space.get()) key(ctx, tr, 6, x, next, w, 10, "", o.jumpKey.isPressed());
    }
}
