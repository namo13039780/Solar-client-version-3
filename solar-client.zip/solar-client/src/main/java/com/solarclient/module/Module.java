package com.solarclient.module;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.solarclient.module.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();

    protected boolean enabled;
    /** false = card with settings only (no on/off switch). */
    public boolean toggleable = true;

    // GUI state
    public boolean expanded;
    public float toggleAnim;
    public float expandAnim;

    protected Module(String name, String description, Category category, boolean defaultEnabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = defaultEnabled;
        this.toggleAnim = defaultEnabled ? 1f : 0f;
    }

    protected <S extends Setting> S add(S s) {
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean v) {
        if (enabled == v) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    protected void onEnable() { }
    protected void onDisable() { }
    /** Called every client tick while enabled. */
    public void onTick(MinecraftClient mc) { }

    public JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", enabled);
        for (Setting s : settings) {
            JsonElement e = s.save();
            if (e != null && !(e instanceof JsonNull)) o.add(s.name, e);
        }
        return o;
    }

    public void load(JsonObject o) {
        if (o.has("enabled") && toggleable) {
            enabled = o.get("enabled").getAsBoolean();
            toggleAnim = enabled ? 1f : 0f;
        }
        for (Setting s : settings) {
            if (o.has(s.name)) {
                try {
                    s.load(o.get(s.name));
                } catch (Exception ignored) { }
            }
        }
    }
}
