package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.music.Lyrics;
import com.solarclient.music.MusicPlayer;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Shows the current lyric line word by word, floating in the sky, around you, or on the screen.
 * Purely visual. Lyrics come from .lrc files or the LRCLIB community database.
 */
public class LyricsModule extends Module {
    public static LyricsModule I;

    private final ModeSetting placement = add(new ModeSetting("Placement", "Sky", "Sky", "Around You", "Screen"));
    private final ModeSetting anchor = add(new ModeSetting("Sky Direction", "Where I Look", "Where I Look", "North", "East", "South", "West"));
    private final NumberSetting height = add(new NumberSetting("Height Angle", 32, 0, 80, 2));
    private final NumberSetting size = add(new NumberSetting("Text Size", 120, 50, 300, 10));
    private final ModeSetting reveal = add(new ModeSetting("Reveal", "Word by Word", "Word by Word", "Whole Line"));
    private final BoolSetting upcoming = add(new BoolSetting("Dim Upcoming Words", false));
    private final ModeSetting color = add(new ModeSetting("Color", "Sky", "Sky", "White", "Pink", "Gold", "Rainbow"));
    private final BoolSetting shadow = add(new BoolSetting("Shadow", true));
    private final NumberSetting screenX = add(new NumberSetting("Screen X %", 50, 0, 100, 5));
    private final NumberSetting screenY = add(new NumberSetting("Screen Y %", 22, 0, 100, 2));
    private final NumberSetting sync = add(new NumberSetting("Sync Offset (ms)", 0, -1500, 1500, 50));
    public final BoolSetting autoDownload = add(new BoolSetting("Auto Download Lyrics", true));

    private Lyrics lastLy;
    private int lastIdx = -2;
    private float curAnchor, prevAnchor;

    public LyricsModule() {
        super("Lyrics", "Song lyrics in the sky, word by word (needs the Music Player)", Category.MUSIC, false);
        I = this;
    }

    private static float smooth(double x) {
        float t = (float) Math.max(0, Math.min(1, x));
        return t * t * (3 - 2 * t);
    }

    private int colorAt(float f, double time, int i) {
        switch (color.get()) {
            case "White": return 0xFFFFFFFF;
            case "Pink": return RenderUtil.lerp(0xFFFFD1F0, 0xFFFF7AC8, f);
            case "Gold": return RenderUtil.lerp(0xFFFFF0B8, 0xFFFFC857, f);
            case "Rainbow": return 0xFF000000 | (java.awt.Color.HSBtoRGB((float) ((f * 0.2 + time * 0.1 + i * 0.1) % 1.0), 0.55f, 1f) & 0xFFFFFF);
            default: return RenderUtil.lerp(0xFFFFFFFF, 0xFF7DD3FC, (float) (0.5 + 0.5 * Math.sin(f * 3 + time)));
        }
    }

    private float anchorNow(MinecraftClient mc) {
        if (anchor.is("North")) return 180f;
        if (anchor.is("East")) return -90f;
        if (anchor.is("South")) return 0f;
        if (anchor.is("West")) return 90f;
        return mc.player.getYaw();
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.player == null || mc.world == null) return;
        MusicPlayer mp = MusicPlayer.I;
        Lyrics ly = mp.lyrics;
        if (ly == null || ly.lines.isEmpty()) return;
        if (mp.state != MusicPlayer.State.PLAYING && mp.state != MusicPlayer.State.PAUSED) return;
        boolean screenMode = placement.is("Screen");
        if (!screenMode && !mc.options.getPerspective().isFirstPerson()) return;

        double t = mp.smoothPosition() + sync.get() / 1000.0;
        int idx = ly.indexAt(t);
        if (ly != lastLy) {
            lastLy = ly;
            lastIdx = -2;
        }
        if (idx != lastIdx) {
            prevAnchor = curAnchor;
            curAnchor = anchorNow(mc);
            lastIdx = idx;
        }
        if (idx < 0) return;

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        View v = screenMode ? null : View.of(mc, TickClock.progress(), sw, sh);
        double time = System.nanoTime() / 1e9;
        Lyrics.Line cur = ly.lines.get(idx);

        if (idx > 0) {
            double age = t - cur.t;
            if (age < 0.55) drawLine(ctx, mc, v, sw, sh, ly.lines.get(idx - 1), (float) ((1 - age / 0.55) * 0.5), prevAnchor, -1, t, time);
        }
        double lastWord = cur.words.isEmpty() ? cur.t : cur.words.get(cur.words.size() - 1).t;
        double showUntil = Math.max(cur.end, lastWord + 1.2);
        float la = t <= showUntil ? 1f : (float) Math.max(0, 1 - (t - showUntil) / 0.6);
        drawLine(ctx, mc, v, sw, sh, cur, la, curAnchor, 0, t, time);
    }

    private void drawLine(DrawContext ctx, MinecraftClient mc, View v, int sw, int sh, Lyrics.Line L, float la,
                          float anchorYaw, int lineOffset, double t, double time) {
        int n = L.words.size();
        if (n == 0 || la < 0.03f) return;
        TextRenderer tr = mc.textRenderer;
        float spaceW = L.spaced ? tr.getWidth(" ") : 0f;
        float[] w = new float[n];
        float total = 0;
        for (int i = 0; i < n; i++) {
            w[i] = tr.getWidth(L.words.get(i).s);
            total += w[i] + (i < n - 1 ? spaceW : 0);
        }
        double sizeF = size.get() / 100.0;
        final double D = 12.0;

        if (placement.is("Around You")) {
            double spread = Math.min(55, 320.0 / n);
            for (int i = 0; i < n; i++) {
                double psi = Math.toRadians(anchorYaw + i * spread + time * 2.0);
                double el = Math.toRadians(height.get() + 7 * Math.sin(i * 1.9));
                double[] s = v.project(-Math.sin(psi) * Math.cos(el) * D, Math.sin(el) * D, Math.cos(psi) * Math.cos(el) * D, sw, sh);
                if (s == null) continue;
                float scale = (float) (sizeF * 1.6 / 9.0 * v.f * (sh / 2.0) / s[2]);
                drawWord(ctx, tr, L, i, (float) s[0], (float) s[1], scale, la, t, time);
            }
            return;
        }

        float scale;
        float cx, cy;
        if (placement.is("Screen")) {
            scale = (float) (sizeF * 2.0);
            cx = sw * (float) screenX.get() / 100f;
            cy = sh * (float) screenY.get() / 100f + lineOffset * 11 * scale;
        } else {
            double psi = Math.toRadians(anchorYaw);
            double el = Math.toRadians(height.get() - lineOffset * 6 * sizeF);
            double[] s = v.project(-Math.sin(psi) * Math.cos(el) * D, Math.sin(el) * D, Math.cos(psi) * Math.cos(el) * D, sw, sh);
            if (s == null) return;
            scale = (float) (sizeF * 1.6 / 9.0 * v.f * (sh / 2.0) / s[2]);
            cx = (float) s[0];
            cy = (float) s[1];
        }
        float cum = 0;
        for (int i = 0; i < n; i++) {
            float wx = cx + (cum + w[i] / 2f - total / 2f) * scale;
            drawWord(ctx, tr, L, i, wx, cy, scale, la, t, time);
            cum += w[i] + spaceW;
        }
    }

    private void drawWord(DrawContext ctx, TextRenderer tr, Lyrics.Line L, int i, float cx, float cy, float scale,
                          float la, double t, double time) {
        Lyrics.Word word = L.words.get(i);
        float wa = reveal.is("Whole Line") ? smooth((t - L.t) / 0.4) : smooth((t - word.t) / 0.3);
        if (upcoming.get()) wa = Math.max(wa, 0.25f);
        final float a = wa * la;
        if (a < 0.05f) return;
        float sc = scale * (0.88f + 0.12f * wa);
        float rise = (1f - wa) * 5f * scale;
        float tw = tr.getWidth(word.s) * sc;
        final int idx = i;
        RenderUtil.gradientText(ctx, tr, word.s, cx - tw / 2f, cy - 4.5f * sc + rise, sc, shadow.get(),
                f -> RenderUtil.withAlpha(colorAt(f, time, idx), a));
    }
}
