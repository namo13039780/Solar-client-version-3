package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.music.Lyrics;
import com.solarclient.music.MusicPlayer;
import com.solarclient.music.SpotifyClient;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.List;

/**
 * Shows the current lyric line word by word, floating in the sky, around you, or on the screen.
 * Purely visual. Lyrics come from .lrc files or the LRCLIB community database.
 */
public class LyricsModule extends Module {
    public static LyricsModule I;

    private final ModeSetting placement = add(new ModeSetting("Placement", "Scatter", "Scatter", "Sky", "Around You", "Screen"));
    private final ModeSetting anchor = add(new ModeSetting("Sky Direction", "Where I Look", "Where I Look", "North", "East", "South", "West"));
    private final NumberSetting height = add(new NumberSetting("Height Angle", 32, 0, 80, 2));
    private final NumberSetting sideAngle = add(new NumberSetting("Side Angle", 45, 20, 80, 5));
    private final NumberSetting aroundDist = add(new NumberSetting("Around Distance", 7, 3, 16, 1));
    private final NumberSetting aroundHeight = add(new NumberSetting("Around Height", 1.5, -2, 8, 0.5));
    private final NumberSetting lead = add(new NumberSetting("Lead Time (s)", 1.5, 0, 4, 0.5));
    private final ModeSetting font = add(new ModeSetting("Font", "Poppins Bold Italic", "Poppins Bold Italic", "Poppins Bold", "Poppins Light Italic", "Lora Italic", "Pacifico", "Lobster", "Yellowtail", "Kaushan", "Courgette", "Damion", "Norican", "Dancing Script", "Caveat Brush", "Minecraft"));
    private final BoolSetting topBar = add(new BoolSetting("Top Bar", true));
    private final NumberSetting wordSpread = add(new NumberSetting("Word Spread", 100, 50, 200, 10));
    private final NumberSetting textOpacity = add(new NumberSetting("Text Opacity", 100, 10, 100, 5));
    private final NumberSetting barOpacity = add(new NumberSetting("Top Bar Opacity", 100, 10, 100, 5));
    private final NumberSetting barY = add(new NumberSetting("Top Bar Y %", 5, 0, 90, 1));
    private final NumberSetting fadeDist = add(new NumberSetting("Fade Distance", 5, 2, 12, 1));
    private final NumberSetting scatterHeight = add(new NumberSetting("Scatter Height", 8, -10, 40, 2));
    private final ModeSetting anim = add(new ModeSetting("Word Animation", "Auto", "Auto", "Fast", "Normal", "Slow"));
    private final NumberSetting antic = add(new NumberSetting("Early Start (ms)", 0, 0, 500, 20));
    private final NumberSetting size = add(new NumberSetting("Text Size", 120, 50, 300, 10));
    private final ModeSetting reveal = add(new ModeSetting("Reveal", "Word by Word", "Word by Word", "Whole Line"));
    private final BoolSetting upcoming = add(new BoolSetting("Dim Upcoming Words", false));
    private final ModeSetting color = add(new ModeSetting("Color", "White", "White", "Sky", "Pink", "Purple", "Gold", "Green", "Red", "Cyan", "Rainbow", "Custom"));
    private final NumberSetting red = add(new NumberSetting("Custom Red", 255, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Custom Green", 255, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Custom Blue", 255, 0, 255, 5));
    private final NumberSetting glow = add(new NumberSetting("Glow", 40, 0, 100, 10));
    private final BoolSetting shadow = add(new BoolSetting("Text Shadow", false));
    private final NumberSetting screenX = add(new NumberSetting("Screen X %", 50, 0, 100, 5));
    private final NumberSetting screenY = add(new NumberSetting("Screen Y %", 22, 0, 100, 2));
    private final NumberSetting sync = add(new NumberSetting("Sync Offset (ms)", 0, -1500, 1500, 50));
    public final BoolSetting autoDownload = add(new BoolSetting("Auto Download Lyrics", true));

    private Lyrics lastLy;
    private int lastIdx = -2;
    private float curAnchor, prevAnchor;
    private boolean flip, flipCloud;
    private final List<Anchor> anchors = new ArrayList<>();
    private final List<Cloud> clouds = new ArrayList<>();
    private Style fontStyle;
    private Boolean fontOk;

    private static final class Anchor {
        final Lyrics.Line line;
        final boolean right;
        Vec3d pos;

        Anchor(Lyrics.Line line, boolean right, Vec3d pos) {
            this.line = line;
            this.right = right;
            this.pos = pos;
        }
    }

    public LyricsModule() {
        super("Lyrics", "Song lyrics floating around you, word by word (Music Player or Spotify)", Category.MUSIC, false);
        I = this;
    }

    /** Fade-in progress of a word. Auto = quick for fast songs (short gaps), softer for slow ones. */
    private float wordProgress(Lyrics.Line L, int i, double t) {
        Lyrics.Word w = L.words.get(i);
        double next = i + 1 < L.words.size() ? L.words.get(i + 1).t : w.t + 0.7;
        double gap = Math.max(0.05, next - w.t);
        double dur;
        switch (anim.get()) {
            case "Fast": dur = 0.15; break;
            case "Normal": dur = 0.35; break;
            case "Slow": dur = 0.55; break;
            default: dur = Math.max(0.15, Math.min(0.45, gap * 1.4));
        }
        return smooth((t - (w.t - antic.get() / 1000.0)) / dur);
    }

    private static float smooth(double x) {
        float t = (float) Math.max(0, Math.min(1, x));
        return t * t * (3 - 2 * t);
    }

    private int colorAt(float f, double time, int i) {
        switch (color.get()) {
            case "Sky": return RenderUtil.lerp(0xFFFFFFFF, 0xFF7DD3FC, (float) (0.5 + 0.5 * Math.sin(f * 3 + time)));
            case "Pink": return 0xFFFF9AD5;
            case "Purple": return 0xFFC39BFF;
            case "Gold": return 0xFFFFD36B;
            case "Green": return 0xFF7CFFB0;
            case "Red": return 0xFFFF6B6B;
            case "Cyan": return 0xFF6BF0FF;
            case "Rainbow": return 0xFF000000 | (java.awt.Color.HSBtoRGB((float) ((f * 0.2 + time * 0.1 + i * 0.1) % 1.0), 0.55f, 1f) & 0xFFFFFF);
            case "Custom": return 0xFF000000 | (red.getInt() << 16) | (green.getInt() << 8) | blue.getInt();
            default: return 0xFFFFFFFF;
        }
    }

    private float anchorNow(MinecraftClient mc) {
        if (anchor.is("North")) return 180f;
        if (anchor.is("East")) return -90f;
        if (anchor.is("South")) return 0f;
        if (anchor.is("West")) return 90f;
        return mc.player.getYaw();
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.player == null || mc.world == null) return;
        Lyrics ly;
        double pos;
        boolean playingNow;
        SpotifyClient sp = SpotifyClient.I;
        if (sp.active() && sp.lyrics != null && !sp.lyrics.lines.isEmpty()) {
            ly = sp.lyrics;
            pos = sp.smoothPosition();
            playingNow = sp.playing;
        } else {
            MusicPlayer mp = MusicPlayer.I;
            ly = mp.lyrics;
            if (ly == null || ly.lines.isEmpty()) return;
            if (mp.state != MusicPlayer.State.PLAYING && mp.state != MusicPlayer.State.PAUSED) return;
            pos = mp.smoothPosition();
            playingNow = mp.state == MusicPlayer.State.PLAYING;
        }
        boolean screenMode = placement.is("Screen");
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();

        double t = pos + sync.get() / 1000.0;
        int idx = ly.indexAt(t);
        if (ly != lastLy) {
            lastLy = ly;
            lastIdx = -2;
            anchors.clear();
            clouds.clear();
        }
        if (idx != lastIdx) {
            if (idx < lastIdx) anchors.clear();
            clouds.clear();
            prevAnchor = curAnchor;
            curAnchor = anchorNow(mc);
            lastIdx = idx;
            if (idx >= 0 && !ly.lines.get(idx).words.isEmpty()) {
                addAnchor(mc, ly.lines.get(idx));
                addCloud(mc, ly.lines.get(idx));
            }
        }
        if (idx < 0) return;

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double time = System.nanoTime() / 1e9;
        if (topBar.get()) drawTopBar(ctx, mc, ly.lines.get(idx), t, time, sw, sh, playingNow);
        if (!screenMode && !firstPerson) return;
        View v = screenMode ? null : View.of(mc, TickClock.progress(), sw, sh);
        if (placement.is("Scatter") || placement.is("Around You")) {
            drawClouds(ctx, mc, v, sw, sh, t, time);
            return;
        }
        Lyrics.Line cur = ly.lines.get(idx);

        if (idx > 0) {
            double age = t - cur.t;
            if (age < 0.55) drawLine(ctx, mc, v, sw, sh, ly.lines.get(idx - 1), (float) ((1 - age / 0.55) * 0.5), prevAnchor, -1, t, time);
        }
        drawLine(ctx, mc, v, sw, sh, cur, nowAlpha(cur, t), curAnchor, 0, t, time);
    }

    private void drawLine(DrawContext ctx, MinecraftClient mc, View v, int sw, int sh, Lyrics.Line L, float la,
                          float anchorYaw, int lineOffset, double t, double time) {
        int n = L.words.size();
        if (n == 0 || la < 0.03f) return;
        TextRenderer tr = mc.textRenderer;
        float spaceW = L.spaced ? ww(tr, " ") : 0f;
        float[] w = new float[n];
        float total = 0;
        for (int i = 0; i < n; i++) {
            w[i] = ww(tr, L.words.get(i).s);
            total += w[i] + (i < n - 1 ? spaceW : 0);
        }
        double sizeF = size.get() / 100.0;
        final double D = 12.0;

        float scale;
        float cx, cy;
        if (placement.is("Screen")) {
            scale = (float) (sizeF * 2.0);
            cx = sw * (float) screenX.get() / 100f;
            cy = sh * (float) screenY.get() / 100f + lineOffset * 11 * scale;
        } else {
            double psi = Math.toRadians(anchorYaw);
            double el = Math.toRadians(height.get() - lineOffset * 6 * sizeF);
            double[] s = v.project(-Math.sin(psi) * Math.cos(el) * D, Math.sin(el) * D, Math.cos(psi) * Math.cos(el) * D, sw, sh);
            if (s == null) return;
            scale = (float) (sizeF * 1.6 / 9.0 * v.f * (sh / 2.0) / s[2]);
            cx = (float) s[0];
            cy = (float) s[1];
        }
        drawLayout(ctx, tr, L, la, cx, cy, scale, t, time);
    }

    private void drawLayout(DrawContext ctx, TextRenderer tr, Lyrics.Line L, float la, float cx, float cy, float scale,
                            double t, double time) {
        int n = L.words.size();
        float spaceW = L.spaced ? ww(tr, " ") : 0f;
        float total = 0;
        float[] w = new float[n];
        for (int i = 0; i < n; i++) {
            w[i] = ww(tr, L.words.get(i).s);
            total += w[i] + (i < n - 1 ? spaceW : 0);
        }
        float cum = 0;
        for (int i = 0; i < n; i++) {
            float wx = cx + (cum + w[i] / 2f - total / 2f) * scale;
            drawWord(ctx, tr, L, i, wx, cy, scale, la, t, time);
            cum += w[i] + spaceW;
        }
    }

    private float nowAlpha(Lyrics.Line L, double t) {
        double lastWord = L.words.isEmpty() ? L.t : L.words.get(L.words.size() - 1).t;
        double showUntil = Math.max(L.end, lastWord + 1.2);
        return t <= showUntil ? 1f : (float) Math.max(0, 1 - (t - showUntil) / 0.6);
    }

    /** Spot ahead of you on the given side. When you move, it is placed further along your path (Lead Time). */
    private Vec3d place(MinecraftClient mc, boolean right) {
        double side = right ? sideAngle.get() : -sideAngle.get();
        double a = Math.toRadians(mc.player.getYaw() + side);
        double d = aroundDist.get();
        Vec3d vel = mc.player.getVelocity();
        double lx = vel.x * 20 * lead.get(), lz = vel.z * 20 * lead.get();
        double ll = Math.hypot(lx, lz);
        if (ll > 25) {
            lx *= 25 / ll;
            lz *= 25 / ll;
        }
        return mc.player.getEyePos().add(-Math.sin(a) * d + lx, aroundHeight.get(), Math.cos(a) * d + lz);
    }

    /** New line = new spot in the world, alternating left / right. It stays put so you can walk past it. */
    private void addAnchor(MinecraftClient mc, Lyrics.Line line) {
        boolean right = flip;
        flip = !flip;
        anchors.add(new Anchor(line, right, place(mc, right)));
        while (anchors.size() > 3) anchors.remove(0);
    }

    private void drawAround(DrawContext ctx, MinecraftClient mc, View v, int sw, int sh, Lyrics ly, int idx, double t, double time) {
        Lyrics.Line cur = ly.lines.get(idx);
        if (anchors.isEmpty() && !cur.words.isEmpty()) addAnchor(mc, cur);
        float tp = TickClock.progress();
        Vec3d cam = mc.player.getLerpedPos(tp).add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);
        double sizeF = size.get() / 100.0;
        for (int k = 0; k < anchors.size(); k++) {
            Anchor an = anchors.get(k);
            float la;
            if (k == anchors.size() - 1) {
                la = nowAlpha(an.line, t);
            } else {
                double age = t - anchors.get(k + 1).line.t;
                la = (float) Math.max(0, 1 - age / 3.5);
            }
            if (la < 0.03f) continue;
            if (k == anchors.size() - 1) {
                // running fast: if the text is already behind you, move it ahead again
                Vec3d vel = mc.player.getVelocity();
                double hs = Math.hypot(vel.x, vel.z);
                if (hs * 20 > 3) {
                    Vec3d dd = an.pos.subtract(cam);
                    if ((dd.x * vel.x + dd.z * vel.z) / hs < 3) an.pos = place(mc, an.right);
                }
            }
            Vec3d d = an.pos.subtract(cam);
            double[] s = v.project(d.x, d.y, d.z, sw, sh);
            if (s == null) continue;
            la *= smooth((d.length() - 0.8) / 1.4);
            float scale = (float) (sizeF * 1.2 / 9.0 * v.f * (sh / 2.0) / s[2]);
            scale = Math.max(1.4f, Math.min(5f, scale));
            drawLayout(ctx, mc.textRenderer, an.line, la, (float) s[0], (float) s[1], scale, t, time);
        }
    }

    // ---------------- font + word drawing ----------------
    private static final java.util.Map<String, String> KEYS = new java.util.HashMap<>();
    static {
        KEYS.put("Poppins Bold Italic", "poppinsbi");
        KEYS.put("Poppins Bold", "poppinsb");
        KEYS.put("Poppins Light Italic", "poppinsli");
        KEYS.put("Lora Italic", "lora");
        KEYS.put("Pacifico", "pacifico");
        KEYS.put("Lobster", "lobster");
        KEYS.put("Yellowtail", "yellowtail");
        KEYS.put("Kaushan", "kaushan");
        KEYS.put("Courgette", "courgette");
        KEYS.put("Damion", "damion");
        KEYS.put("Norican", "norican");
        KEYS.put("Dancing Script", "dancing");
        KEYS.put("Caveat Brush", "caveat");
    }
    private final java.util.Map<String, Style> styles = new java.util.HashMap<>();
    private String cachedMode;
    private String cachedKey;

    /** Key of the font to use (falls back to Poppins if the chosen font file was not downloaded), or null for Minecraft's font. */
    private String fontKey(MinecraftClient mc) {
        String mode = font.get();
        if (mode.equals(cachedMode)) return cachedKey;
        cachedMode = mode;
        String key = KEYS.get(mode);
        if (key != null && mc.getResourceManager().getResource(Identifier.of("solarclient", "font/lyrics_" + key + ".json")).isEmpty()) {
            key = "poppinsbi";
        }
        cachedKey = key;
        return key;
    }

    private Text wordText(MinecraftClient mc, String s) {
        MutableText t = Text.literal(s);
        String key = fontKey(mc);
        if (key != null) {
            Style st = styles.get(key);
            if (st == null) {
                st = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("solarclient", "lyrics_" + key)));
                styles.put(key, st);
            }
            t.setStyle(st);
        }
        return t;
    }

    private float ww(TextRenderer tr, String s) {
        return tr.getWidth(wordText(MinecraftClient.getInstance(), s));
    }

    /** Draws one word centered at (cx, cy) with the chosen font, soft glow and shadow. */
    private void drawWordAt(DrawContext ctx, MinecraftClient mc, TextRenderer tr, String s, float cx, float cy,
                            float sc, float a, int rgb, float gradT, double time, int idx) {
        if (a < 0.05f) return;
        if (fontKey(mc) == null) {
            float tw = tr.getWidth(s) * sc;
            RenderUtil.gradientText(ctx, tr, s, cx - tw / 2f, cy - 4.5f * sc, sc, shadow.get(),
                    f -> RenderUtil.withAlpha(colorAt(f, time, idx), a));
            return;
        }
        Text tx = wordText(mc, s);
        float w = tr.getWidth(tx) * sc;
        var m = ctx.getMatrices();
        float gl = (float) glow.get() / 100f;
        if (a > 0.14f && gl > 0f) {
            int g = RenderUtil.withAlpha(0xFF000000 | (rgb & 0xFFFFFF), a * 0.44f * gl);
            float[][] off = {{-1.2f, 0}, {1.2f, 0}, {0, -1.2f}, {0, 1.2f}};
            for (float[] o : off) {
                m.pushMatrix();
                m.translate(cx - w / 2f + o[0] * sc * 0.6f, cy - 4.5f * sc + o[1] * sc * 0.6f);
                m.scale(sc, sc);
                ctx.drawText(tr, tx, 0, 0, g, false);
                m.popMatrix();
            }
        }
        m.pushMatrix();
        m.translate(cx - w / 2f, cy - 4.5f * sc);
        m.scale(sc, sc);
        ctx.drawText(tr, tx, 0, 0, RenderUtil.withAlpha(0xFF000000 | (rgb & 0xFFFFFF), a), shadow.get());
        m.popMatrix();
    }

    private void drawWord(DrawContext ctx, TextRenderer tr, Lyrics.Line L, int i, float cx, float cy, float scale,
                          float la, double t, double time) {
        Lyrics.Word word = L.words.get(i);
        float wa = reveal.is("Whole Line") ? smooth((t - (L.t - antic.get() / 1000.0)) / 0.4) : wordProgress(L, i, t);
        if (upcoming.get()) wa = Math.max(wa, 0.25f);
        float a = wa * la * (float) (textOpacity.get() / 100.0);
        if (a < 0.05f) return;
        float sc = scale * (0.88f + 0.12f * wa);
        float rise = (1f - wa) * 5f * scale;
        drawWordAt(ctx, MinecraftClient.getInstance(), tr, word.s, cx, cy + rise, sc, a, colorAt(0.5f, time, i), 0.5f, time, i);
    }

    // ---------------- Scatter mode (LyricsFlow style) ----------------
    private static final class Cloud {
        final Lyrics.Line line;
        final Vec3d[] rel, rgt, upv;
        final boolean[] placed;
        Vec3d base;

        Cloud(Lyrics.Line line, Vec3d base, Vec3d[] rel, Vec3d[] rgt, Vec3d[] upv, boolean[] placed) {
            this.line = line;
            this.base = base;
            this.rel = rel;
            this.rgt = rgt;
            this.upv = upv;
            this.placed = placed;
        }
    }

    private Vec3d leadBase(MinecraftClient mc) {
        Vec3d vel = mc.player.getVelocity();
        double lx = vel.x * 20 * lead.get(), lz = vel.z * 20 * lead.get();
        double ll = Math.hypot(lx, lz);
        if (ll > 25) {
            lx *= 25 / ll;
            lz *= 25 / ll;
        }
        return mc.player.getEyePos().add(lx, 0, lz);
    }

    private static boolean[] allTrue(int n) {
        boolean[] b = new boolean[n];
        java.util.Arrays.fill(b, true);
        return b;
    }

    private void trimClouds() {
        while (clouds.size() > 2) clouds.remove(0);
    }

    /**
     * Scatter: words are placed one by one, at the moment each is sung, in a random free spot in front of YOU.
     * So the text always appears where you are, even while you run. Around You: one readable line, placed at once.
     */
    private void addCloud(MinecraftClient mc, Lyrics.Line line) {
        int n = line.words.size();
        Vec3d[] rel = new Vec3d[n], rgt = new Vec3d[n], upv = new Vec3d[n];
        if (placement.is("Around You")) {
            double yaw0 = mc.player.getYaw();
            Vec3d eye = mc.player.getEyePos();
            Vec3d base = leadBase(mc);
            boolean right = flipCloud;
            flipCloud = !flipCloud;
            double az = Math.toRadians(yaw0 + (right ? sideAngle.get() : -sideAngle.get()));
            double el = Math.toRadians(height.get() * 0.25);
            double dd = aroundDist.get();
            Vec3d center = new Vec3d(-Math.sin(az) * Math.cos(el) * dd, Math.sin(el) * dd + aroundHeight.get() * 0.3, Math.cos(az) * Math.cos(el) * dd);
            Vec3d pc = base.add(center);
            double ang = Math.atan2(eye.z - pc.z, eye.x - pc.x);
            Vec3d R = new Vec3d(Math.sin(ang), 0, -Math.cos(ang));
            TextRenderer tr0 = mc.textRenderer;
            double wpp0 = size.get() / 100.0 * 1.2 / 9.0;
            float space0 = line.spaced ? ww(tr0, " ") : 0f;
            float[] w0 = new float[n];
            float total0 = 0;
            for (int i = 0; i < n; i++) {
                w0[i] = ww(tr0, line.words.get(i).s);
                total0 += w0[i] + (i < n - 1 ? space0 : 0);
            }
            float cum0 = 0;
            for (int i = 0; i < n; i++) {
                double off = (cum0 + w0[i] / 2f - total0 / 2f) * wpp0;
                rel[i] = center.add(R.multiply(off));
                rgt[i] = R;
                upv[i] = new Vec3d(0, 1, 0);
                cum0 += w0[i] + space0;
            }
            clouds.add(new Cloud(line, base, rel, rgt, upv, allTrue(n)));
        } else {
            clouds.add(new Cloud(line, Vec3d.ZERO, rel, rgt, upv, new boolean[n]));
        }
        trimClouds();
    }

    private static double wrap180(double a) {
        while (a < -180) a += 360;
        while (a > 180) a -= 360;
        return a;
    }

    /** Puts word i of the cloud in a free random spot in front of the player right now. */
    private void placeWord(MinecraftClient mc, Cloud c, int i) {
        TextRenderer trs = mc.textRenderer;
        java.util.Random r = new java.util.Random(Double.doubleToLongBits(c.line.t) + i * 7919L);
        double spread = wordSpread.get() / 100.0;
        double wpp = size.get() / 100.0 * 1.2 / 9.0;
        double D = aroundDist.get();
        double hAz = 30 * spread, hEl = 10 * spread;
        double yaw = mc.player.getYaw();
        double centerEl = Math.max(0, Math.min(20, -mc.player.getPitch())) * 0.6 + scatterHeight.get() * 0.7;
        Vec3d eye = mc.player.getEyePos();
        double myHalfAz = Math.toDegrees(ww(trs, c.line.words.get(i).s) * wpp / D) / 2 + 2.5;
        double myHalfEl = Math.toDegrees(9 * wpp / D) / 2 + 1.5;
        int n = c.line.words.size();
        double[] oAz = new double[n], oEl = new double[n], oHa = new double[n], oHe = new double[n];
        for (int j = 0; j < n; j++) {
            if (!c.placed[j]) continue;
            Vec3d v = c.rel[j].subtract(eye);
            double len = Math.max(0.5, v.length());
            oAz[j] = wrap180(Math.toDegrees(Math.atan2(-v.x, v.z)) - yaw);
            oEl[j] = Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, v.y / len))));
            oHa[j] = Math.toDegrees(ww(trs, c.line.words.get(j).s) * wpp / len) / 2 + 2.5;
            oHe[j] = Math.toDegrees(9 * wpp / len) / 2 + 1.5;
        }
        double bestAz = 0, bestEl = centerEl, bestScore = 1e9;
        for (int k = 0; k < 90; k++) {
            double sc = 1 + k * 0.012;
            double az = (r.nextDouble() * 2 - 1) * hAz * sc, el = centerEl + (r.nextDouble() * 2 - 1) * hEl * sc;
            double overlap = 0;
            for (int j = 0; j < n; j++) {
                if (!c.placed[j]) continue;
                double ox = myHalfAz + oHa[j] - Math.abs(az - oAz[j]);
                double oy = myHalfEl + oHe[j] - Math.abs(el - oEl[j]);
                if (ox > 0 && oy > 0) overlap += ox * oy;
            }
            if (overlap < bestScore) {
                bestScore = overlap;
                bestAz = az;
                bestEl = el;
            }
            if (overlap == 0) break;
        }
        double az = Math.toRadians(yaw + bestAz), el = Math.toRadians(bestEl);
        double d = D + (r.nextDouble() - 0.5) * 0.6;
        Vec3d pos = leadBase(mc).add(-Math.sin(az) * Math.cos(el) * d, Math.sin(el) * d + aroundHeight.get() * 0.3, Math.cos(az) * Math.cos(el) * d);
        double minY = mc.player.getY() + 0.5;
        if (pos.y < minY) pos = new Vec3d(pos.x, minY, pos.z);
        double nx = eye.x - pos.x, nz = eye.z - pos.z;
        double ang = Math.hypot(nx, nz) < 1e-3 ? Math.toRadians(yaw + 180) : Math.atan2(nz, nx);
        ang += (r.nextDouble() - 0.5) * 0.3;
        nx = Math.cos(ang);
        nz = Math.sin(ang);
        double rx = nz, rz = -nx;
        double phi = (r.nextDouble() - 0.5) * 0.08, cp = Math.cos(phi), sp = Math.sin(phi);
        c.rel[i] = pos;
        c.rgt[i] = new Vec3d(rx * cp, sp, rz * cp);
        c.upv[i] = new Vec3d(-rx * sp, cp, -rz * sp);
        c.placed[i] = true;
    }

    private double[] proj(View v, Vec3d d, int sw, int sh) {
        return v.project(d.x, d.y, d.z, sw, sh);
    }

    private void drawClouds(DrawContext ctx, MinecraftClient mc, View v, int sw, int sh, double t, double time) {
        TextRenderer tr = mc.textRenderer;
        float tp = TickClock.progress();
        Vec3d cam = mc.player.getLerpedPos(tp).add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);
        double sizeF = size.get() / 100.0;
        double wpp = sizeF * 1.2 / 9.0;
        for (int k = 0; k < clouds.size(); k++) {
            Cloud c = clouds.get(k);
            boolean newest = k == clouds.size() - 1;
            float la;
            if (newest) {
                double lastWord = c.line.words.get(c.line.words.size() - 1).t;
                double showUntil = Math.max(c.line.end, lastWord + 1.4);
                la = t <= showUntil ? 1f : (float) Math.max(0, 1 - (t - showUntil) / 0.9);
            } else {
                la = (float) Math.max(0, 1 - (t - clouds.get(k + 1).line.t) / 1.2);
            }
            if (la < 0.03f) continue;
            int n = c.line.words.size();
            for (int i = 0; i < n; i++) {
                Lyrics.Word w = c.line.words.get(i);
                float wa = reveal.is("Whole Line") ? smooth((t - (c.line.t - antic.get() / 1000.0)) / 0.4) : wordProgress(c.line, i, t);
                if (upcoming.get()) wa = Math.max(wa, 0.2f);
                if (!c.placed[i]) {
                    if (t < w.t && wa <= 0f) continue;
                    placeWord(mc, c, i);
                }
                float a = wa * la;
                if (a < 0.04f) continue;
                Vec3d p = c.base.add(c.rel[i]).add(0, (1 - wa) * 0.8 + Math.sin(time * 0.9 + i * 1.3) * 0.07, 0);
                Vec3d d = p.subtract(cam);
                double dist = d.length();
                a *= smooth((dist - fadeDist.get() * 0.45) / (fadeDist.get() * 0.55)) * (float) (textOpacity.get() / 100.0);
                if (a < 0.04f) continue;
                // facing: fade when seen edge-on
                Vec3d R = c.rgt[i], U = c.upv[i];
                Vec3d N = R.crossProduct(U);
                double facing = Math.abs(N.x * d.x + N.y * d.y + N.z * d.z) / Math.max(1e-6, dist);
                a *= smooth((facing - 0.10) / 0.25);
                if (a < 0.04f) continue;
                float wLocal = Math.max(1f, tr.getWidth(wordText(mc, w.s)));
                double halfW = wLocal * wpp / 2.0, halfH = 4.5 * wpp;
                double[] s0 = proj(v, d, sw, sh);
                double[] sl = proj(v, d.subtract(R.multiply(halfW)), sw, sh), sr = proj(v, d.add(R.multiply(halfW)), sw, sh);
                double[] st = proj(v, d.add(U.multiply(halfH)), sw, sh), sb = proj(v, d.subtract(U.multiply(halfH)), sw, sh);
                if (s0 == null || sl == null || sr == null || st == null || sb == null) continue;
                float ma = (float) ((sr[0] - sl[0]) / wLocal), mb = (float) ((sr[1] - sl[1]) / wLocal);
                float mc2 = (float) ((sb[0] - st[0]) / 9.0), md = (float) ((sb[1] - st[1]) / 9.0);
                if (ma * md - mb * mc2 < 0) {
                    ma = -ma;
                    mb = -mb;
                }
                // a word that gets huge on screen (you are right next to it) fades out so it can never block the view
                double wpx = Math.hypot(sr[0] - sl[0], sr[1] - sl[1]), hpx = Math.hypot(sb[0] - st[0], sb[1] - st[1]);
                a *= Math.min(smooth((sw * 0.6 - wpx) / (sw * 0.2)), smooth((sh * 0.34 - hpx) / (sh * 0.14)));
                if (a < 0.04f) continue;
                double nextT = i + 1 < n ? c.line.words.get(i + 1).t : c.line.end;
                float pulse = (t >= w.t && t < nextT) ? 1f + 0.1f * (float) Math.sin(Math.min(1, (t - w.t) / 0.35) * Math.PI) : 1f;
                float pop = (0.75f + 0.25f * wa) * pulse;
                drawPlaneWord(ctx, mc, tr, w.s, ma * pop, mb * pop, mc2 * pop, md * pop, (float) s0[0], (float) s0[1], a,
                        colorAt(0.5f, time, i));
            }
        }
    }

    /** Draws a word on a world-fixed plane using an affine map (text px -> screen) built from the projected plane axes. */
    private void drawPlaneWord(DrawContext ctx, MinecraftClient mc, TextRenderer tr, String s, float ma, float mb, float mc2,
                               float md, float ex, float ey, float a, int rgb) {
        Text tx = wordText(mc, s);
        float w = tr.getWidth(tx);
        var m = ctx.getMatrices();
        float gl = (float) glow.get() / 100f;
        if (a > 0.14f && gl > 0f) {
            int g = RenderUtil.withAlpha(0xFF000000 | (rgb & 0xFFFFFF), a * 0.35f * gl);
            float[][] off = {{-0.6f, 0}, {0.6f, 0}, {0, -0.6f}, {0, 0.6f}};
            for (float[] o : off) {
                m.pushMatrix();
                m.mul(new Matrix3x2f(ma, mb, mc2, md, ex, ey));
                m.translate(-w / 2f + o[0], -4.5f + o[1]);
                ctx.drawText(tr, tx, 0, 0, g, false);
                m.popMatrix();
            }
        }
        m.pushMatrix();
        m.mul(new Matrix3x2f(ma, mb, mc2, md, ex, ey));
        m.translate(-w / 2f, -4.5f);
        ctx.drawText(tr, tx, 0, 0, RenderUtil.withAlpha(0xFF000000 | (rgb & 0xFFFFFF), a), shadow.get());
        m.popMatrix();
    }

    // ---------------- top bar (current line, sung words highlighted) ----------------
    private void drawTopBar(DrawContext ctx, MinecraftClient mc, Lyrics.Line L, double t, double time, int sw, int sh, boolean playing) {
        int n = L.words.size();
        if (n == 0) return;
        float la = nowAlpha(L, t) * (float) (barOpacity.get() / 100.0);
        if (la < 0.03f) return;
        TextRenderer tr = mc.textRenderer;
        float space = L.spaced ? ww(tr, " ") : 0f;
        float[] w = new float[n];
        float total = 0;
        for (int i = 0; i < n; i++) {
            w[i] = ww(tr, L.words.get(i).s);
            total += w[i] + (i < n - 1 ? space : 0);
        }
        float sc = Math.min(1.1f, (sw * 0.62f) / Math.max(1f, total));
        int h = 22;
        int pillW = Math.round(total * sc) + 64;
        int x = (sw - pillW) / 2, y = Math.round(sh * (float) barY.get() / 100f);
        RenderUtil.rrect(ctx, x - 1, y - 1, x + pillW + 1, y + h + 1, h / 2 + 1, RenderUtil.withAlpha(RenderUtil.SKY, 0.35f * la));
        RenderUtil.rrect(ctx, x, y, x + pillW, y + h, h / 2, RenderUtil.withAlpha(0xFF0B0F18, 0.85f * la));
        // little spinning disc
        int dcx = x + 15, dcy = y + h / 2;
        RenderUtil.circle(ctx, dcx, dcy, 8, RenderUtil.withAlpha(0xFF123A6B, la));
        double sp = playing ? time * 2.4 : 0.5;
        ctx.fill(dcx + (int) Math.round(Math.cos(sp) * 4.5), dcy + (int) Math.round(Math.sin(sp) * 4.5),
                dcx + (int) Math.round(Math.cos(sp) * 4.5) + 2, dcy + (int) Math.round(Math.sin(sp) * 4.5) + 2, RenderUtil.withAlpha(0xFFFFFFFF, la));
        RenderUtil.circle(ctx, dcx, dcy, 2, RenderUtil.withAlpha(RenderUtil.SKY, la));
        // words
        float cx = x + 30;
        var m = ctx.getMatrices();
        for (int i = 0; i < n; i++) {
            Lyrics.Word word = L.words.get(i);
            boolean sung = t >= word.t;
            int col = sung ? 0xFF7DD3FC : 0xFFFFFFFF;
            float a = la * (sung ? 1f : 0.8f);
            if (a >= 0.05f) {
                m.pushMatrix();
                m.translate(cx, y + (h - 9 * sc) / 2f);
                m.scale(sc, sc);
                ctx.drawText(tr, wordText(mc, word.s), 0, 0, RenderUtil.withAlpha(col, a), false);
                m.popMatrix();
            }
            cx += (w[i] + space) * sc;
        }
        // equalizer
        int ex = x + pillW - 18;
        for (int b = 0; b < 3; b++) {
            double hh = playing ? 3 + 5 * (0.5 + 0.5 * Math.sin(time * (5 + b * 1.7) + b)) : 3;
            ctx.fill(ex + b * 4, (int) (y + h / 2 + hh / 2), ex + b * 4 + 2, (int) (y + h / 2 - hh / 2), RenderUtil.withAlpha(RenderUtil.SKY_LIGHT, la));
        }
    }
}
