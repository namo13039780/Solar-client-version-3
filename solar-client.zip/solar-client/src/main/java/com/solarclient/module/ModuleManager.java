package com.solarclient.module;

import com.solarclient.module.impl.ArmorHud;
import com.solarclient.module.impl.CooldownHud;
import com.solarclient.module.impl.FallTrackerHud;
import com.solarclient.module.impl.ItemCounterHud;
import com.solarclient.module.impl.HitboxModule;
import com.solarclient.module.impl.KeystrokesHud;
import com.solarclient.module.impl.MaceImpactModule;
import com.solarclient.module.impl.PotionHud;
import com.solarclient.module.impl.SmoothModeModule;
import com.solarclient.module.impl.TargetHealthHud;
import com.solarclient.module.impl.WatermarkHud;
import com.solarclient.util.CpsTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    public static void init() {
        if (!MODULES.isEmpty()) return;

        // ---- HUD ----
        add(new WatermarkHud());
        add(new SimpleTextHud("FPS", "Frames per second", 0.008f, 0.07f, true, "FPS",
                mc -> String.valueOf(mc.getCurrentFps())));
        add(new SimpleTextHud("CPS", "Clicks per second (left | right)", 0.008f, 0.12f, true, "CPS", mc -> {
            CpsTracker.update(mc);
            return CpsTracker.left() + " | " + CpsTracker.right();
        }));
        add(new SimpleTextHud("Ping", "Latency to the server", 0.008f, 0.17f, false, "Ping", mc -> {
            if (mc.getNetworkHandler() == null || mc.player == null) return "-";
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return e == null ? "-" : e.getLatency() + " ms";
        }));
        add(new SimpleTextHud("Coordinates", "Your XYZ position", 0.5f, 0.01f, false, "XYZ", mc ->
                String.format(Locale.ROOT, "%d %d %d", (int) Math.floor(mc.player.getX()),
                        (int) Math.floor(mc.player.getY()), (int) Math.floor(mc.player.getZ()))));
        add(new SimpleTextHud("Direction", "Compass direction you face", 0.5f, 0.06f, false, "Dir", mc -> {
            float yaw = MathHelper.wrapDegrees(mc.player.getYaw());
            int idx = ((int) Math.floor((yaw + 180f + 22.5f) / 45f)) % 8;
            return DIRS[idx] + " (" + Math.round(yaw) + ")";
        }));
        add(new SimpleTextHud("Speed", "Horizontal speed in blocks/s", 0.008f, 0.22f, false, "Speed", mc -> {
            var v = mc.player.getVelocity();
            return String.format(Locale.ROOT, "%.1f b/s", Math.hypot(v.x, v.z) * 20.0);
        }));
        add(new SimpleTextHud("Memory", "Java memory usage", 0.99f, 0.01f, false, "Mem", mc -> {
            Runtime r = Runtime.getRuntime();
            long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
            return used + "/" + (r.maxMemory() / 1048576L) + " MB";
        }));
        add(new SimpleTextHud("Clock", "Real-world time", 0.99f, 0.06f, false, "Time", mc ->
                LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
        add(new SimpleTextHud("Day", "In-game day counter", 0.99f, 0.11f, false, "Day", mc ->
                String.valueOf(mc.world.getTimeOfDay() / 24000L + 1)));
        add(new SimpleTextHud("Biome", "Biome you are standing in", 0.5f, 0.11f, false, "Biome", mc -> {
            var entry = mc.world.getBiome(mc.player.getBlockPos());
            String id = entry.getKey().map(k -> k.getValue().getPath()).orElse("unknown");
            return id.replace('_', ' ');
        }));
        add(new SimpleTextHud("Server IP", "Server you are playing on", 0.99f, 0.16f, false, "IP", mc ->
                mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Singleplayer"));
        add(new ArmorHud());
        add(new TargetHealthHud());
        add(new KeystrokesHud());
        add(new PotionHud());

        // ---- PvP (display only: no automation, no packets) ----
        add(new ItemCounterHud("Crystal PvP Kit", "Counts crystals, obsidian, totems, anchors, glowstone, pearls, gapples, XP",
                0.01f, 0.40f, false, Items.END_CRYSTAL, Items.OBSIDIAN, Items.TOTEM_OF_UNDYING, Items.RESPAWN_ANCHOR,
                Items.GLOWSTONE, Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.EXPERIENCE_BOTTLE));
        add(new ItemCounterHud("Mace PvP Kit", "Counts wind charges, totems, gapples, pearls, rockets, cobwebs, water",
                0.01f, 0.40f, false, Items.WIND_CHARGE, Items.TOTEM_OF_UNDYING, Items.GOLDEN_APPLE, Items.ENDER_PEARL,
                Items.FIREWORK_ROCKET, Items.COBWEB, Items.WATER_BUCKET));
        add(new ItemCounterHud("Spear PvP Kit", "Counts totems, gapples, pearls, shields, rockets",
                0.01f, 0.40f, false, Items.TOTEM_OF_UNDYING, Items.GOLDEN_APPLE, Items.ENDER_PEARL, Items.SHIELD,
                Items.FIREWORK_ROCKET));
        add(new FallTrackerHud());
        add(new CooldownHud());
        add(new MaceImpactModule());
        add(new SimpleTextHud("Target Distance", "Distance to the entity you are looking at", Category.PVP,
                0.5f, 0.62f, false, "Dist", mc -> mc.targetedEntity == null ? "-"
                : String.format(Locale.ROOT, "%.1f", mc.player.distanceTo(mc.targetedEntity))));

        // ---- Visual / Performance ----
        add(new HitboxModule());
        add(new SmoothModeModule());

        // ---- Settings ----
        add(new StyleModule());
    }

    private static void add(Module m) {
        MODULES.add(m);
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static List<HudModule> huds() {
        List<HudModule> out = new ArrayList<>();
        for (Module m : MODULES) if (m instanceof HudModule h) out.add(h);
        return out;
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }

    private ModuleManager() { }
}
