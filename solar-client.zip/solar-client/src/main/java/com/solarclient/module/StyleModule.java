package com.solarclient.module;

import com.solarclient.hud.HudManager;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;

/** Global HUD look (background, shadow, accent colour). Always on. */
public class StyleModule extends Module {
    public static StyleModule I;

    private final BoolSetting background = add(new BoolSetting("HUD Background", true));
    private final NumberSetting opacity = add(new NumberSetting("BG Opacity", 55, 0, 100, 5));
    private final BoolSetting shadow = add(new BoolSetting("Text Shadow", true));
    private final ModeSetting accent = add(new ModeSetting("Accent Color", "Sky", "Sky", "White", "Gold", "Rainbow"));
    @SuppressWarnings("unused")
    private final ActionSetting reset = add(new ActionSetting("Reset HUD Positions", HudManager::resetPositions));

    public StyleModule() {
        super("HUD Style", "Look of every HUD element", Category.SETTINGS, true);
        toggleable = false;
        I = this;
    }

    public static boolean background() { return I == null || I.background.get(); }
    public static boolean shadow() { return I == null || I.shadow.get(); }

    public static int bgColor() {
        double o = I == null ? 55 : I.opacity.get();
        return ((int) (o / 100.0 * 255) << 24) | 0x0A0F18;
    }

    public static int accent() {
        if (I == null) return RenderUtil.SKY;
        switch (I.accent.get()) {
            case "White": return 0xFFFFFFFF;
            case "Gold": return 0xFFFFC857;
            case "Rainbow":
                return 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 4000L) / 4000f, 0.55f, 1f);
            default: return RenderUtil.SKY;
        }
    }
}
