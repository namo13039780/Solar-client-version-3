package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Locale;

/** Weapon cooldown bar for timing sword / mace / spear hits. Display only. */
public class CooldownHud extends HudModule {
    private final BoolSetting percent = add(new BoolSetting("Show Percent", true));
    private float progress = 1f;

    public CooldownHud() {
        super("Attack Cooldown", "Bar showing your weapon cooldown", Category.PVP, 0.5f, 0.74f, false);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        progress = mc.player != null ? Math.max(0f, Math.min(1f, mc.player.getAttackCooldownProgress(0f))) : 0.7f;
        w = 84;
        h = 17;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        panel(ctx, x, y, w, h);
        int col = progress >= 1f ? 0xFF4ADE80 : RenderUtil.lerp(0xFFEF4444, 0xFFFFD54F, progress);
        ctx.fill(x + 4, y + 10, x + w - 4, y + 13, 0xFF1B2230);
        ctx.fill(x + 4, y + 10, x + 4 + Math.round((w - 8) * progress), y + 13, col);
        String t = progress >= 1f ? "READY" : (percent.get() ? String.format(Locale.ROOT, "%d%%", Math.round(progress * 100)) : "...");
        ctx.drawText(mc.textRenderer, t, x + 4, y + 1, progress >= 1f ? 0xFF4ADE80 : 0xFFFFFFFF, StyleModule.shadow());
    }
}
