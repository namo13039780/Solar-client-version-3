package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;

public class HitboxModule extends Module {
    public HitboxModule() {
        super("Hitboxes", "Use F3 + B for vanilla hitboxes (toggle coming soon)", Category.VISUAL, false);
    }
}
