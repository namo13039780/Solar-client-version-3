package com.solarclient.module.impl;

import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

public class PotionHud extends HudModule {
    private List<String> lines = new ArrayList<>();

    public PotionHud() {
        super("Potion Effects", "Lists your active potion effects", 0.01f, 0.30f, true);
    }

    private static String roman(int n) {
        String[] r = {"", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"};
        return n >= 0 && n < r.length ? r[n] : " " + (n + 1);
    }

    private static String time(int ticks) {
        int s = ticks / 20;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        lines = new ArrayList<>();
        if (mc.player != null) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String n = e.getEffectType().value().getName().getString() + roman(e.getAmplifier());
                lines.add(n + "  " + (e.isInfinite() ? "**" : time(e.getDuration())));
            }
        }
        if (lines.isEmpty() && editing) {
            lines.add("Speed II  3:20");
            lines.add("Strength  1:05");
        }
        if (lines.isEmpty()) {
            w = h = 0;
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int m = 0;
        for (String l : lines) m = Math.max(m, tr.getWidth(l));
        w = m + 10;
        h = lines.size() * 11 + 4;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        panel(ctx, x, y, w, h);
        int cy = y + 3;
        for (String l : lines) {
            ctx.drawText(mc.textRenderer, l, x + 5, cy, 0xFFFFFFFF, StyleModule.shadow());
            cy += 11;
        }
    }
}
