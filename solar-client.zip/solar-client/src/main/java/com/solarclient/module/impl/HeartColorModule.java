package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Re-colours YOUR OWN hearts (Christmas, Halloween, ...). It paints themed hearts exactly over the vanilla ones.
 * Cosmetic only.
 */
public class HeartColorModule extends Module {
    public static HeartColorModule I;

    private final ModeSetting theme = add(new ModeSetting("Theme", "Christmas", "Vanilla", "Christmas", "Halloween", "Valentine", "Ice", "Gold", "Purple", "Rainbow", "Custom"));
    private final NumberSetting red = add(new NumberSetting("Custom Red", 255, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Custom Green", 80, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Custom Blue", 120, 0, 255, 5));
    private final BoolSetting blink = add(new BoolSetting("Damage Blink", true));
    private final BoolSetting effects = add(new BoolSetting("Show Poison / Wither Colors", true));

    private static final String[] SHAPE = {" ## ## ", "#######", "#######", "#######", " ##### ", "  ###  ", "   #   "};

    private static final class Pal {
        final int fill, light, dark, outline, empty;

        Pal(int fill, int light, int dark, int outline, int empty) {
            this.fill = 0xFF000000 | fill;
            this.light = 0xFF000000 | light;
            this.dark = 0xFF000000 | dark;
            this.outline = 0xFF000000 | outline;
            this.empty = 0xFF000000 | empty;
        }
    }

    private float lastHp = -1f;
    private long blinkUntil;

    public HeartColorModule() {
        super("Heart Colors", "Christmas, Halloween... themes for your own hearts", Category.VISUAL, false);
        I = this;
    }

    private static int shade(int rgb, float k) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 0xFF) * k)), g = Math.min(255, Math.round(((rgb >> 8) & 0xFF) * k)), b = Math.min(255, Math.round((rgb & 0xFF) * k));
        return (r << 16) | (g << 8) | b;
    }

    private static Pal from(int rgb, int outline, int empty) {
        return new Pal(rgb, shade(rgb, 1.45f), shade(rgb, 0.72f), outline, empty);
    }

    private Pal palette(int idx, boolean gold, boolean poison, boolean wither, double time) {
        if (wither) return from(0x2B2B2B, 0x000000, 0x151515);
        if (poison) return from(0x7BA428, 0x1E2A08, 0x1F2A0C);
        if (gold) return from(0xFFC857, 0x4A3200, 0x2E2410);
        switch (theme.get()) {
            case "Christmas":
                return idx % 2 == 0 ? from(0xE53935, 0x3A0D0D, 0x2A1214) : from(0x2E9E4F, 0x0C2A16, 0x12261A);
            case "Halloween":
                return idx % 3 == 2 ? from(0x9B59B6, 0x1A0A2A, 0x1C1226) : from(0xFF8F1F, 0x1A0A2A, 0x24160E);
            case "Valentine":
                return from(0xFF5FA2, 0x4A0F2A, 0x2A1220);
            case "Ice":
                return from(0x4FC3F7, 0x0B2A44, 0x10202C);
            case "Gold":
                return from(0xFFC107, 0x4A3200, 0x2E2410);
            case "Purple":
                return from(0xAB47BC, 0x2A0E36, 0x201226);
            case "Rainbow":
                return from(java.awt.Color.HSBtoRGB((float) ((time * 0.2 + idx * 0.09) % 1.0), 0.75f, 1f) & 0xFFFFFF, 0x1A1A1A, 0x202020);
            default:
                return from((red.getInt() << 16) | (green.getInt() << 8) | blue.getInt(), 0x1A1A1A, 0x202020);
        }
    }

    private boolean filled(int cx, int cy) {
        return cx >= 0 && cx < 7 && cy >= 0 && cy < 7 && SHAPE[cy].charAt(cx) == '#';
    }

    private void heart(DrawContext c, int x, int y, float fill, Pal p, boolean flash, int idx) {
        for (int cy = -1; cy <= 7; cy++) {
            for (int cx = -1; cx <= 7; cx++) {
                int px = x + 1 + cx, py = y + 1 + cy;
                if (filled(cx, cy)) {
                    boolean on = fill >= 1f || (fill > 0f && cx <= 3);
                    int col;
                    if (!on) {
                        col = p.empty;
                    } else if (cy >= 4) {
                        col = p.dark;
                    } else if ((cx == 1 && (cy == 1 || cy == 2)) || (cx == 2 && cy == 1)) {
                        col = p.light;
                    } else {
                        col = p.fill;
                    }
                    if (on && theme.is("Christmas") && cy == 0 && !(idx < 0)) col = 0xFFF4F8FF;                // snow on top
                    if (on && theme.is("Halloween") && cy == 2 && (cx == 2 || cx == 4) && p.outline == 0xFF1A0A2A) col = 0xFF2A1000; // pumpkin eyes
                    c.fill(px, py, px + 1, py + 1, col);
                } else {
                    boolean edge = false;
                    for (int dy = -1; dy <= 1 && !edge; dy++) for (int dx = -1; dx <= 1; dx++) if (filled(cx + dx, cy + dy)) { edge = true; break; }
                    if (edge) c.fill(px, py, px + 1, py + 1, flash ? 0xFFFFFFFF : p.outline);
                }
            }
        }
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.player == null || theme.is("Vanilla")) return;
        PlayerEntity p = mc.player;
        if (p.isCreative() || p.isSpectator()) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        int baseX = sw / 2 - 91, baseY = sh - 39;
        float hp = p.getHealth(), max = p.getMaxHealth(), abs = p.getAbsorptionAmount();
        long now = System.nanoTime();
        if (lastHp >= 0 && hp < lastHp - 0.01f) blinkUntil = now + 500_000_000L;
        lastHp = hp;
        boolean flash = blink.get() && now < blinkUntil && ((now / 90_000_000L) % 2 == 0);
        boolean poison = false, wither = false;
        if (effects.get()) {
            try {
                poison = p.hasStatusEffect(StatusEffects.POISON);
                wither = p.hasStatusEffect(StatusEffects.WITHER);
            } catch (Throwable ignored) { }
        }
        double time = now / 1e9;
        int normal = (int) Math.ceil(Math.max(max, hp) / 2.0), absH = (int) Math.ceil(abs / 2.0), total = normal + absH;
        int rows = (int) Math.ceil(total / 10.0);
        int spacing = Math.max(10 - (rows - 2), 3);
        for (int idx = total - 1; idx >= 0; idx--) {
            int x = baseX + (idx % 10) * 8, y = baseY - (idx / 10) * spacing;
            boolean gold = idx >= normal;
            float fill;
            if (!gold) {
                fill = hp >= idx * 2 + 2 ? 1f : hp >= idx * 2 + 1 ? 0.5f : 0f;
            } else {
                float a = abs - (idx - normal) * 2f;
                fill = a >= 2 ? 1f : a >= 1 ? 0.5f : 0f;
            }
            heart(ctx, x, y, fill, palette(idx, gold, poison, wither, time), flash, idx);
        }
    }
}
