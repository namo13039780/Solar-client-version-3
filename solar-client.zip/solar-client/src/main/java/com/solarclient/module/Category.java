package com.solarclient.module;

public enum Category {
    HUD("HUD"),
    VISUAL("Visual"),
    PERFORMANCE("Performance"),
    SETTINGS("Settings");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
