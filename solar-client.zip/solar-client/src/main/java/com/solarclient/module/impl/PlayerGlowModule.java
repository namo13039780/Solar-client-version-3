package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Soft aura around other players so they are easier to spot.
 * Only players you can already see (line of sight) get one: never through walls, never invisible players.
 */
public class PlayerGlowModule extends Module {
    public static PlayerGlowModule I;

    private final ModeSetting color = add(new ModeSetting("Color", "Sky", "Sky", "White", "Red", "Green", "Purple", "Gold", "Rainbow", "Custom"));
    private final NumberSetting red = add(new NumberSetting("Red", 56, 0, 255, 5));
    private final NumberSetting green = add(new NumberSetting("Green", 189, 0, 255, 5));
    private final NumberSetting blue = add(new NumberSetting("Blue", 248, 0, 255, 5));
    private final NumberSetting intensity = add(new NumberSetting("Intensity", 70, 10, 100, 5));
    private final NumberSetting size = add(new NumberSetting("Size", 100, 50, 200, 10));
    private final NumberSetting range = add(new NumberSetting("Max Distance", 40, 8, 64, 4));
    private final BoolSetting pulse = add(new BoolSetting("Pulse", true));

    public PlayerGlowModule() {
        super("Player Glow", "Aura around players you can see (never through walls)", Category.VISUAL, false);
        I = this;
    }

    private int baseColor(double t, int idx) {
        switch (color.get()) {
            case "White": return 0xFFFFFF;
            case "Red": return 0xFF4040;
            case "Green": return 0x40FF70;
            case "Purple": return 0xB05CFF;
            case "Gold": return 0xFFC857;
            case "Rainbow": return java.awt.Color.HSBtoRGB((float) ((t * 0.15 + idx * 0.17) % 1.0), 0.6f, 1f) & 0xFFFFFF;
            case "Custom": return (red.getInt() << 16) | (green.getInt() << 8) | blue.getInt();
            default: return 0x38BDF8;
        }
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        PlayerEntity me = mc.player;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float tp = TickClock.progress();
        View v = View.of(mc, tp, sw, sh);
        Vec3d cam = me.getLerpedPos(tp).add(0, me.getEyeHeight(me.getPose()), 0);
        double maxSq = range.get() * range.get();
        double t = System.nanoTime() / 1e9;
        float inten = (float) intensity.get() / 100f * (pulse.get() ? (float) (0.85 + 0.15 * Math.sin(t * 3)) : 1f);
        float sz = (float) size.get() / 100f;
        int idx = 0;
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            idx++;
            if (p == me || p.isInvisible() || p.isSpectator() || !p.isAlive()) continue;
            if (me.squaredDistanceTo(p) > maxSq) continue;
            if (!me.canSee(p)) continue;
            Vec3d c = p.getLerpedPos(tp).add(0, p.getHeight() / 2.0, 0);
            double[] s = v.project(c.x - cam.x, c.y - cam.y, c.z - cam.z, sw, sh);
            if (s == null) continue;
            double scale = v.f * (sh / 2.0) / s[2];
            double ry = p.getHeight() * 0.5 * scale, rx = 0.45 * scale;
            if (s[0] < -rx * 2 || s[0] > sw + rx * 2 || s[1] < -ry * 2 || s[1] > sh + ry * 2) continue;
            int rgb = baseColor(t, idx);
            int pts = 56;
            for (int i = 0; i < 6; i++) {
                float k = 1f - i / 6f;
                float a = inten * 0.75f * k * k;
                int col = RenderUtil.withAlpha(0xFF000000 | rgb, a);
                double sc = 1.0 + (0.06 + i * 0.07) * sz;
                for (int j = 0; j < pts; j++) {
                    double ang = j * Math.PI * 2 / pts;
                    int x = (int) Math.round(s[0] + Math.cos(ang) * rx * sc), y = (int) Math.round(s[1] + Math.sin(ang) * ry * sc);
                    ctx.fill(x, y, x + 2, y + 2, col);
                }
            }
        }
    }
}
