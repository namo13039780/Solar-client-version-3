package com.solarclient.module;

import com.google.gson.JsonObject;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** A draggable HUD element. Position is stored as a 0..1 fraction of the free screen space. */
public abstract class HudModule extends Module {
    public final float defFx, defFy;
    public float fx, fy;
    public int x, y, w, h;

    protected HudModule(String name, String description, float fx, float fy, boolean defaultEnabled) {
        this(name, description, Category.HUD, fx, fy, defaultEnabled);
    }

    protected HudModule(String name, String description, Category cat, float fx, float fy, boolean defaultEnabled) {
        super(name, description, cat, defaultEnabled);
        this.defFx = fx;
        this.defFy = fy;
        this.fx = fx;
        this.fy = fy;
    }

    /** Compute w/h for this frame (set w=h=0 to hide). */
    protected abstract void layout(MinecraftClient mc, boolean editing);

    protected abstract void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing);

    public final void render(DrawContext ctx, MinecraftClient mc, boolean editing) {
        layout(mc, editing);
        if (w <= 0 || h <= 0) return;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        x = Math.round(fx * Math.max(0, sw - w));
        y = Math.round(fy * Math.max(0, sh - h));
        draw(ctx, mc, x, y, editing);
    }

    public void resetPosition() {
        fx = defFx;
        fy = defFy;
    }

    protected void panel(DrawContext ctx, int x, int y, int w, int h) {
        if (StyleModule.background()) RenderUtil.rrect(ctx, x, y, x + w, y + h, 2, StyleModule.bgColor());
    }

    @Override
    public JsonObject save() {
        JsonObject o = super.save();
        o.addProperty("x", fx);
        o.addProperty("y", fy);
        return o;
    }

    @Override
    public void load(JsonObject o) {
        super.load(o);
        if (o.has("x")) fx = Math.max(0f, Math.min(1f, o.get("x").getAsFloat()));
        if (o.has("y")) fy = Math.max(0f, Math.min(1f, o.get("y").getAsFloat()));
    }
}
