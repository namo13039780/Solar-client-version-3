package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.music.MusicPlayer;
import com.solarclient.util.RenderUtil;
import com.solarclient.util.TickClock;
import com.solarclient.util.View;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pastes a panorama picture onto the sky (a screen overlay, anchored to the direction you look).
 * Built-in pictures, your own files (solar_sky folder), or a direct image link copied to the clipboard.
 */
public class SkyImageModule extends Module {
    public static SkyImageModule I;

    private static final String[] BUILTIN = {"Galaxy", "Nebula", "Aurora", "Sunset", "Starfield"};

    private final ModeSetting image = add(new ModeSetting("Image", "Galaxy", "Galaxy", "Nebula", "Aurora", "Sunset", "Starfield", "Custom File", "Link"));
    @SuppressWarnings("unused")
    private final ActionSetting nextFile = add(new ActionSetting("Next Custom File", () -> nextCustom()));
    @SuppressWarnings("unused")
    private final ActionSetting fromLink = add(new ActionSetting("Use Link From Clipboard", () -> useClipboardLink()));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 85, 10, 100, 5));
    private final NumberSetting brightness = add(new NumberSetting("Brightness", 100, 40, 160, 5));
    private final NumberSetting rotate = add(new NumberSetting("Rotate Speed", 1, 0, 10, 1));
    private final BoolSetting nightOnly = add(new BoolSetting("Night Only", false));
    private final ModeSetting quality = add(new ModeSetting("Quality", "Medium", "Low", "Medium", "High"));

    private volatile int[] pix;
    private volatile int pw, ph;
    private volatile String loadedKey = "";
    private volatile String loadingKey = "";
    private int fileIdx = -1;
    private volatile String linkUrl = "";
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SolarSky-load");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });

    public SkyImageModule() {
        super("Sky Image", "Paste a picture (galaxy, your own file or a link) onto the sky", Category.VISUAL, false);
        I = this;
    }

    // ---------------- sources ----------------
    private static List<Path> skyDirs() {
        List<Path> l = new ArrayList<>();
        l.add(FabricLoader.getInstance().getGameDir().resolve("solar_sky"));
        l.add(Path.of("/storage/emulated/0/Pictures/solar_sky"));
        l.add(Path.of("/storage/emulated/0/Download/solar_sky"));
        return l;
    }

    private static List<Path> customFiles() {
        List<Path> out = new ArrayList<>();
        for (Path d : skyDirs()) {
            try {
                Files.createDirectories(d);
            } catch (Exception ignored) { }
            try (var s = Files.list(d)) {
                s.filter(p -> {
                    String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg");
                }).sorted().forEach(out::add);
            } catch (Exception ignored) { }
        }
        return out;
    }

    private static void say(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("Sky Image: " + msg), true);
    }

    private void nextCustom() {
        setEnabled(true);
        List<Path> files = customFiles();
        if (files.isEmpty()) {
            say("no pictures found. Put .png/.jpg in the solar_sky folder (Pictures/solar_sky)");
            return;
        }
        fileIdx = (fileIdx + 1) % files.size();
        while (!image.is("Custom File")) image.next();
        say(files.get(fileIdx).getFileName().toString());
    }

    private void useClipboardLink() {
        MinecraftClient mc = MinecraftClient.getInstance();
        String clip = mc.keyboard.getClipboard();
        if (clip == null || !clip.trim().toLowerCase(Locale.ROOT).startsWith("http")) {
            say("copy a direct image link (http...) first");
            return;
        }
        setEnabled(true);
        linkUrl = clip.trim();
        while (!image.is("Link")) image.next();
        say("loading link...");
    }

    private String wantedKey() {
        switch (image.get()) {
            case "Custom File": {
                List<Path> f = customFiles();
                if (f.isEmpty()) return "none";
                if (fileIdx < 0 || fileIdx >= f.size()) fileIdx = 0;
                return "f:" + f.get(fileIdx);
            }
            case "Link":
                return linkUrl.isEmpty() ? "none" : "l:" + linkUrl;
            default:
                return "b:" + image.get().toLowerCase(Locale.ROOT);
        }
    }

    // ---------------- loading ----------------
    private void ensureLoaded(MinecraftClient mc) {
        String key = wantedKey();
        if (key.equals(loadedKey) || key.equals(loadingKey) || key.equals("none")) return;
        loadingKey = key;
        io.submit(() -> {
            try {
                byte[] data;
                if (key.startsWith("b:")) {
                    var res = mc.getResourceManager().getResource(Identifier.of("solarclient", "sky/" + key.substring(2) + ".jpg"));
                    if (res.isEmpty()) throw new RuntimeException("missing picture");
                    try (InputStream in = res.get().getInputStream()) {
                        data = in.readAllBytes();
                    }
                } else if (key.startsWith("f:")) {
                    data = Files.readAllBytes(Path.of(key.substring(2)));
                } else {
                    data = download(key.substring(2));
                }
                int[] size = new int[2];
                int[] px = decode(data, size);
                if (px == null) throw new RuntimeException("cannot read picture");
                pw = size[0];
                ph = size[1];
                pix = px;
                loadedKey = key;
            } catch (Throwable e) {
                say("could not load picture (" + e.getClass().getSimpleName() + ")");
                loadedKey = key;
                pix = null;
            } finally {
                loadingKey = "";
            }
        });
    }

    private static byte[] download(String url) throws Exception {
        Path cache = FabricLoader.getInstance().getGameDir().resolve("solar_sky").resolve("cache");
        Files.createDirectories(cache);
        Path f = cache.resolve(Integer.toHexString(url.hashCode()) + ".img");
        if (Files.exists(f) && Files.size(f) > 0) return Files.readAllBytes(f);
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "SolarClient/1.0");
        if (c.getResponseCode() / 100 != 2) throw new RuntimeException("HTTP " + c.getResponseCode());
        byte[] data;
        try (InputStream in = c.getInputStream()) {
            data = in.readAllBytes();
        }
        Files.write(f, data);
        return data;
    }

    private static int[] decode(byte[] data, int[] size) {
        ByteBuffer buf = MemoryUtil.memAlloc(data.length);
        try (MemoryStack st = MemoryStack.stackPush()) {
            buf.put(data).flip();
            IntBuffer w = st.mallocInt(1), h = st.mallocInt(1), c = st.mallocInt(1);
            ByteBuffer img = STBImage.stbi_load_from_memory(buf, w, h, c, 4);
            if (img == null) return null;
            int iw = w.get(0), ih = h.get(0);
            int step = Math.max(1, (int) Math.ceil(iw / 1536.0));
            int ow = iw / step, oh = ih / step;
            int[] out = new int[ow * oh];
            for (int y = 0; y < oh; y++) {
                for (int x = 0; x < ow; x++) {
                    int i = ((y * step) * iw + x * step) * 4;
                    out[y * ow + x] = 0xFF000000 | ((img.get(i) & 0xFF) << 16) | ((img.get(i + 1) & 0xFF) << 8) | (img.get(i + 2) & 0xFF);
                }
            }
            STBImage.stbi_image_free(img);
            size[0] = ow;
            size[1] = oh;
            return out;
        } finally {
            MemoryUtil.memFree(buf);
        }
    }

    // ---------------- drawing ----------------
    private static double smooth(double e0, double e1, double x) {
        double t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
        return t * t * (3 - 2 * t);
    }

    public void renderFx(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;
        ClientWorld w = mc.world;
        if (w.getRegistryKey() != World.OVERWORLD) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        ensureLoaded(mc);
        int[] px = pix;
        if (px == null || px.length == 0) return;
        if (!w.isSkyVisible(mc.player.getBlockPos())) return;

        float vis = 1f;
        if (nightOnly.get()) {
            long tod = w.getTimeOfDay() % 24000L;
            if (tod < 0) tod += 24000L;
            vis = tod < 12000 ? 0f : tod < 13200 ? (tod - 12000) / 1200f : tod < 22800 ? 1f : (24000 - tod) / 1200f;
        }
        vis *= 1f - 0.5f * w.getRainGradient(1f);
        if (vis < 0.02f) return;

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        View v = View.of(mc, TickClock.progress(), sw, sh);
        int cell = quality.is("Low") ? 8 : quality.is("High") ? 4 : 6;
        double rot = System.nanoTime() / 1e9 * rotate.get() * 0.002;
        float op = (float) opacity.get() / 100f * vis;
        float br = (float) brightness.get() / 100f;
        int iw = pw, ih = ph;
        for (int j = 0; j < sh; j += cell) {
            double ndcY = 1 - (j + cell * 0.5) / sh * 2;
            for (int i = 0; i < sw; i += cell) {
                double ndcX = (i + cell * 0.5) / sw * 2 - 1;
                double dx = ndcX * v.aspect / v.f, dy = ndcY / v.f;
                double x = v.rx * dx + v.ux * dy + v.fx, y = v.ry * dx + v.uy * dy + v.fy, z = v.rz * dx + v.uz * dy + v.fz;
                double len = Math.sqrt(x * x + y * y + z * z);
                x /= len; y /= len; z /= len;
                if (y < 0.10) continue;
                float edge = (float) smooth(0.10, 0.30, y);
                double az = Math.atan2(x, z) + rot;
                double u = az / (Math.PI * 2);
                u -= Math.floor(u);
                double vv = 0.5 - Math.asin(Math.min(1, y)) / Math.PI;
                int sx = Math.min(iw - 1, (int) (u * iw)), sy = Math.max(0, Math.min(ih - 1, (int) (vv * ih)));
                int c = px[sy * iw + sx];
                int r = Math.min(255, Math.round(((c >> 16) & 0xFF) * br));
                int g = Math.min(255, Math.round(((c >> 8) & 0xFF) * br));
                int b = Math.min(255, Math.round((c & 0xFF) * br));
                ctx.fill(i, j, i + cell, j + cell, RenderUtil.withAlpha(0xFF000000 | (r << 16) | (g << 8) | b, op * edge));
            }
        }
    }
}
