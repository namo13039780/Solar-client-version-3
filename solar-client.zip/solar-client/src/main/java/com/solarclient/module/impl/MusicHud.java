package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.music.CoverArt;
import com.solarclient.music.MusicPlayer;
import com.solarclient.music.SpotifyClient;
import com.solarclient.music.Track;
import com.solarclient.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Compact now-playing card: cover frame on the left, title / artist / progress on the right, mini planet behind. */
public class MusicHud extends HudModule {
    private static final int[][] STARS = {{52, 6}, {72, 11}, {100, 5}, {118, 13}, {140, 7}, {166, 10}, {70, 41}, {96, 43}, {128, 42}, {156, 39}};

    private final BoolSetting planet = add(new BoolSetting("Planet Background", true));
    private final BoolSetting autoHide = add(new BoolSetting("Hide When Idle", false));

    public MusicHud() {
        super("Music HUD", "Now playing card with cover frame and mini planet", Category.MUSIC, 0.01f, 0.86f, true);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        MusicPlayer mp = MusicPlayer.I;
        if (autoHide.get() && !editing && mp.state == MusicPlayer.State.IDLE && !SpotifyClient.I.active()) {
            w = h = 0;
            return;
        }
        w = 200;
        h = 50;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        TextRenderer tr = mc.textRenderer;
        MusicPlayer mp = MusicPlayer.I;
        double t = System.nanoTime() / 1e9;
        SpotifyClient sp = SpotifyClient.I;
        boolean spo = sp.active();
        boolean playing = spo ? sp.playing : mp.state == MusicPlayer.State.PLAYING;
        boolean sh = StyleModule.shadow();

        RenderUtil.rrect(ctx, x - 1, y - 1, x + w + 1, y + h + 1, 6, RenderUtil.withAlpha(RenderUtil.SKY, 0.30f));
        RenderUtil.rrect(ctx, x, y, x + w, y + h, 5, 0xE0070B14);

        ctx.enableScissor(x, y, x + w, y + h);
        for (int i = 0; i < STARS.length; i++) {
            float a = 0.25f + 0.25f * (float) Math.sin(t * 2.0 + i * 1.7);
            ctx.fill(x + STARS[i][0], y + STARS[i][1], x + STARS[i][0] + 1, y + STARS[i][1] + 1, RenderUtil.withAlpha(0xFFFFFFFF, a));
        }
        if (planet.get()) drawPlanet(ctx, x + w - 22, y + h / 2 + 2, 19, t);
        ctx.disableScissor();

        // what is playing (Spotify first, then the in-game player)
        Track tr0 = mp.current();
        String title, sub, coverKey = null;
        int subCol = 0xFF8EA2BF;
        if (spo) {
            title = sp.title;
            sub = sp.artist;
            coverKey = sp.coverUrl;
        } else if (editing && tr0 == null) {
            title = "Superpowers";
            sub = "Daniel Caesar";
        } else if (tr0 != null) {
            title = tr0.title;
            sub = mp.state == MusicPlayer.State.LOADING ? "Loading..." : (tr0.artist.isEmpty() ? "Unknown artist" : tr0.artist);
            if (!mp.status.isEmpty()) {
                sub = mp.status;
                subCol = 0xFFFF7A7A;
            }
            if (tr0.file != null) coverKey = "file:" + tr0.file;
        } else {
            title = "Solar Music";
            sub = mp.tracks.isEmpty() ? "Put mp3/ogg in solar_music" : "Press \\ to play";
            if (!mp.status.isEmpty()) {
                sub = mp.status;
                subCol = 0xFFFF7A7A;
            }
        }

        // cover frame
        int fx = x + 9, fy = y + 9, fs = CoverArt.N;
        float glow = playing ? 0.40f + 0.18f * (float) Math.sin(t * 3) : 0.35f;
        RenderUtil.rrect(ctx, fx - 3, fy - 3, fx + fs + 3, fy + fs + 3, 4, RenderUtil.withAlpha(RenderUtil.SKY, glow));
        RenderUtil.rrect(ctx, fx - 1, fy - 1, fx + fs + 1, fy + fs + 1, 2, 0xFF05080F);
        int[] cov = CoverArt.get(coverKey);
        if (cov != null) {
            for (int yy = 0; yy < fs; yy++) {
                int xx = 0;
                while (xx < fs) {
                    int c = cov[yy * fs + xx], run = xx + 1;
                    while (run < fs && cov[yy * fs + run] == c) run++;
                    ctx.fill(fx + xx, fy + yy, fx + run, fy + yy + 1, c);
                    xx = run;
                }
            }
        } else {
            ctx.fill(fx, fy, fx + fs, fy + fs, 0xFF0B1424);
            int nc = RenderUtil.withAlpha(RenderUtil.SKY_LIGHT, 0.75f);
            RenderUtil.circle(ctx, fx + 12, fy + 22, 4.5, nc);
            ctx.fill(fx + 15, fy + 8, fx + 17, fy + 22, nc);
            ctx.fill(fx + 17, fy + 8, fx + 24, fy + 11, nc);
            ctx.fill(fx + 22, fy + 11, fx + 24, fy + 17, nc);
        }

        // text
        int tx = x + 52, avail = w - 52 - 10;
        ctx.enableScissor(tx, y + 3, x + w - 8, y + 17);
        int tw = tr.getWidth(title);
        if (tw <= avail) {
            ctx.drawText(tr, title, tx, y + 7, 0xFFFFFFFF, sh);
        } else {
            int gap = 28;
            int off = (int) ((t * 18) % (tw + gap));
            ctx.drawText(tr, title, tx - off, y + 7, 0xFFFFFFFF, sh);
            ctx.drawText(tr, title, tx - off + tw + gap, y + 7, 0xFFFFFFFF, sh);
        }
        ctx.disableScissor();
        ctx.drawText(tr, tr.trimToWidth(sub, avail), tx, y + 18, subCol, false);

        // progress
        double pos, dur;
        if (spo) {
            pos = sp.smoothPosition();
            dur = sp.duration;
        } else if (editing && tr0 == null) {
            pos = 83;
            dur = 225;
        } else {
            pos = mp.position;
            dur = mp.duration;
        }
        float f = dur > 0 ? (float) Math.min(1, pos / dur) : 0f;
        int bx1 = tx, bx2 = x + w - 10, by = y + h - 18;
        ctx.fill(bx1, by, bx2, by + 3, 0xFF26324A);
        ctx.fill(bx1, by, bx1 + Math.round((bx2 - bx1) * f), by + 3, RenderUtil.SKY);
        RenderUtil.circle(ctx, bx1 + (bx2 - bx1) * f, by + 1.5, 3, 0xFFFFFFFF);
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(bx1, y + h - 12);
        m.scale(0.7f, 0.7f);
        ctx.drawText(tr, MusicPlayer.fmt(pos), 0, 0, 0xFF9AA8BF, false);
        String d = MusicPlayer.fmt(dur);
        ctx.drawText(tr, d, (int) ((bx2 - bx1) / 0.7f) - tr.getWidth(d), 0, 0xFF9AA8BF, false);
        m.popMatrix();
    }

    private static void drawPlanet(DrawContext c, int cx, int cy, int r, double t) {
        RenderUtil.circle(c, cx, cy, r + 6, 0x0C38BDF8);
        RenderUtil.circle(c, cx, cy, r + 3, 0x0C38BDF8);
        ring(c, cx, cy, r, true);
        RenderUtil.circle(c, cx, cy, r, 0xFF10294D);
        RenderUtil.circle(c, cx - 3, cy - 3, r * 0.86, 0xFF1F5FA8);
        for (int dy = -9; dy <= 9; dy += 6) {
            int half = (int) Math.sqrt(Math.max(0, r * r - dy * dy)) - 2;
            c.fill(cx - half, cy + dy, cx + half, cy + dy + 1, 0x3CBFE3FF);
        }
        ring(c, cx, cy, r, false);
        double a = t * 0.9;
        int mx = (int) Math.round(cx + Math.cos(a) * (r * 1.9)), my = (int) Math.round(cy + Math.sin(a) * (r * 0.55));
        c.fill(mx, my, mx + 2, my + 2, 0xCCFFFFFF);
    }

    private static void ring(DrawContext c, int cx, int cy, int r, boolean back) {
        for (int k = 0; k < 64; k++) {
            double a = k * Math.PI * 2 / 64;
            if ((Math.sin(a) < 0) != back) continue;
            int x = (int) Math.round(cx + Math.cos(a) * r * 1.6), y = (int) Math.round(cy + Math.sin(a) * r * 0.42);
            c.fill(x, y, x + 1, y + 1, 0x99BFE3FF);
        }
    }
}
