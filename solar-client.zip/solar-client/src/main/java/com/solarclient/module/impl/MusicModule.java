package com.solarclient.module.impl;

import com.solarclient.gui.MusicScreen;
import com.solarclient.module.Category;
import com.solarclient.module.Module;
import com.solarclient.module.setting.ActionSetting;
import com.solarclient.module.setting.BoolSetting;
import com.solarclient.module.setting.ModeSetting;
import com.solarclient.module.setting.NumberSetting;
import com.solarclient.music.MusicPlayer;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Settings + keys for the built-in music player. Keys: [ prev, ] next, \ play/pause, ; open player. */
public class MusicModule extends Module {
    public static MusicModule I;

    public final NumberSetting volume = add(new NumberSetting("Volume", 60, 0, 100, 5));
    public final BoolSetting shuffle = add(new BoolSetting("Shuffle", false));
    public final ModeSetting repeat = add(new ModeSetting("Repeat", "All", "Off", "All", "One"));
    @SuppressWarnings("unused")
    private final ActionSetting open = add(new ActionSetting("Open Music Player", () -> {
        setEnabled(true);
        pendingOpen = true;
    }));
    @SuppressWarnings("unused")
    private final ActionSetting rescan = add(new ActionSetting("Rescan Music Folder", () -> MusicPlayer.I.rescan()));

    private boolean pendingOpen;
    private final boolean[] prev = new boolean[4];
    private static final int[] KEYS = {
            GLFW.GLFW_KEY_LEFT_BRACKET, GLFW.GLFW_KEY_RIGHT_BRACKET, GLFW.GLFW_KEY_BACKSLASH, GLFW.GLFW_KEY_SEMICOLON};

    public MusicModule() {
        super("Music Player", "Plays mp3/ogg from the solar_music folder. Keys: [ ] \\ ;", Category.MUSIC, true);
        I = this;
        MusicPlayer.I.start();
    }

    @Override
    protected void onDisable() {
        MusicPlayer.I.stop();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (pendingOpen) {
            pendingOpen = false;
            mc.setScreen(new MusicScreen(mc.currentScreen));
            return;
        }
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0) return;
        for (int i = 0; i < KEYS.length; i++) {
            boolean d = GLFW.glfwGetKey(w, KEYS[i]) == GLFW.GLFW_PRESS;
            boolean edge = d && !prev[i];
            prev[i] = d;
            if (!edge || mc.currentScreen != null) continue;
            switch (i) {
                case 0 -> MusicPlayer.I.prev();
                case 1 -> MusicPlayer.I.next();
                case 2 -> MusicPlayer.I.togglePause();
                default -> mc.setScreen(new MusicScreen(null));
            }
        }
    }
}
