package com.solarclient.module.impl;

import com.solarclient.module.Category;
import com.solarclient.module.HudModule;
import com.solarclient.module.StyleModule;
import com.solarclient.module.setting.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;

import java.util.Locale;

/** Mace PvP helper: shows how far you have fallen and the estimated smash bonus. Display only. */
public class FallTrackerHud extends HudModule {
    private final BoolSetting onlyMace = add(new BoolSetting("Only With Mace", false));
    private double peakY;
    private double fall;
    private boolean ready;
    private String line1 = "", line2 = "";

    public FallTrackerHud() {
        super("Mace Fall Tracker", "Fall distance and estimated mace smash bonus", Category.PVP, 0.5f, 0.68f, false);
    }

    @Override
    protected void layout(MinecraftClient mc, boolean editing) {
        PlayerEntity p = mc.player;
        boolean holdingMace = false;
        if (p != null) {
            if (p.isOnGround() || p.getY() > peakY) peakY = p.getY();
            fall = Math.max(0, peakY - p.getY());
            holdingMace = Registries.ITEM.getId(p.getMainHandStack().getItem()).getPath().equals("mace");
        }
        if (editing) {
            fall = 9.5;
            holdingMace = true;
        }
        if (onlyMace.get() && !holdingMace) {
            w = h = 0;
            return;
        }
        // Mace bonus: +4/block for first 3, +2/block for next 5, +1/block after (enchantments not included)
        double bonus = 4 * Math.min(fall, 3) + 2 * Math.max(0, Math.min(fall - 3, 5)) + Math.max(0, fall - 8);
        ready = fall > 1.5;
        line1 = String.format(Locale.ROOT, "Fall %.1f blocks", fall);
        line2 = ready ? String.format(Locale.ROOT, "Smash ~+%.1f dmg", bonus) : "Smash: not ready";
        TextRenderer tr = mc.textRenderer;
        w = Math.max(tr.getWidth(line1), tr.getWidth(line2)) + 10;
        h = 2 * 11 + 4;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, int x, int y, boolean editing) {
        panel(ctx, x, y, w, h);
        boolean sh = StyleModule.shadow();
        ctx.drawText(mc.textRenderer, line1, x + 5, y + 3, 0xFFFFFFFF, sh);
        ctx.drawText(mc.textRenderer, line2, x + 5, y + 14, ready ? 0xFF4ADE80 : 0xFF9AA8BF, sh);
    }
}
