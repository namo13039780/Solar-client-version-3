package com.solarclient.module.setting;

import com.google.gson.JsonElement;

public class ActionSetting extends Setting {
    private final Runnable action;

    public ActionSetting(String name, Runnable action) {
        super(name);
        this.action = action;
    }

    public void run() { action.run(); }

    @Override public JsonElement save() { return com.google.gson.JsonNull.INSTANCE; }
    @Override public void load(JsonElement e) { }
}
