package com.solarclient;

import com.solarclient.config.ConfigManager;
import com.solarclient.gui.ClickGuiScreen;
import com.solarclient.gui.HudEditorScreen;
import com.solarclient.gui.SolarTitleScreen;
import com.solarclient.gui.UiInput;
import com.solarclient.hud.HudManager;
import com.solarclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SolarClient implements ClientModInitializer {
    public static final String MOD_ID = "solarclient";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger("SolarClient");

    /** Set from render code, consumed on the next client tick (never open screens mid-render). */
    public static boolean pendingToggle;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(MOD_ID, "hud"),
                (context, tickCounter) -> HudManager.render(context));

        ClientTickEvents.END_CLIENT_TICK.register(SolarClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ConfigManager.save());
        LOGGER.info("Solar Client {} loaded", VERSION);
    }

    private static void tick(MinecraftClient mc) {
        // Replace the vanilla title screen with ours
        if (mc.currentScreen instanceof TitleScreen) {
            mc.setScreen(new SolarTitleScreen());
            return;
        }
        if (UiInput.pollToggleKey()) pendingToggle = true;
        if (pendingToggle) {
            pendingToggle = false;
            toggleGui(mc);
        }
        ModuleManager.tick(mc);
    }

    public static void toggleGui(MinecraftClient mc) {
        Screen s = mc.currentScreen;
        if (s instanceof ClickGuiScreen || s instanceof HudEditorScreen) {
            s.close();
        } else if (s == null || s instanceof SolarTitleScreen || s instanceof GameMenuScreen) {
            mc.setScreen(new ClickGuiScreen(s));
        }
    }
}
